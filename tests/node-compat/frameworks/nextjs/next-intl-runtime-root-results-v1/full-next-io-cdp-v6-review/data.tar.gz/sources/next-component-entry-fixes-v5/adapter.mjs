// Production-shaped guest adapter. No diagnostic app, event log or host service.
// `types` is the genuine selected wasi:http/types@0.2.10 namespace.
const drop=value=>{if(value)value[Symbol.dispose]();};
function text(value){let out='';for(const byte of value)out+=String.fromCharCode(byte);return out;}
function bytes(value){
  const out=new Uint8Array(value.length);
  for(let i=0;i<value.length;i++){const code=value.charCodeAt(i);if(code>255)throw new TypeError('HTTP header values must be ByteStrings');out[i]=code;}
  return out;
}
function ownData(value,key){
  if(value===null||(typeof value!=='object'&&typeof value!=='function'))return undefined;
  const descriptor=Object.getOwnPropertyDescriptor(value,key);
  return descriptor&&Object.prototype.hasOwnProperty.call(descriptor,'value')?descriptor.value:undefined;
}
function streamError(value){
  const payload=ownData(value,'payload'),variant=payload===undefined?value:payload,tag=ownData(variant,'tag');
  if(tag==='closed')return{tag};
  if(tag==='last-operation-failed'){
    const resource=ownData(variant,'val');
    if(resource!==null&&(typeof resource==='object'||typeof resource==='function'))return{tag,val:resource};
  }
  return undefined;
}
function diagnosticMethod(resource,name){
  for(let object=resource,depth=0;object!==null&&depth<4;object=Object.getPrototypeOf(object),depth++){
    const descriptor=Object.getOwnPropertyDescriptor(object,name);
    if(descriptor){
      if(Object.prototype.hasOwnProperty.call(descriptor,'value')&&typeof descriptor.value==='function')return descriptor.value;
      throw new TypeError('WASI diagnostic method must be a DATA function');
    }
  }
  throw new TypeError('WASI diagnostic method missing');
}
function streamFailure(value){
  const variant=streamError(value);
  if(variant?.tag==='last-operation-failed'){
    const resource=variant.val;let message;
    try{message=Reflect.apply(diagnosticMethod(resource,'toDebugString'),resource,[]);
      if(typeof message!=='string')throw new TypeError('WASI diagnostic must return a synchronous string');}
    finally{drop(resource);}
    const error=new Error(message);Object.defineProperty(error,'cause',{value,configurable:true,writable:true});return error;
  }
  return value;
}
function isObservedClosedOutput({observed,raw,caught,tag,responseSet}){
  return observed===true&&raw===caught&&tag==='closed'&&responseSet===true;
}
function mayReturnHandledClosed({classified,cancelReturned,readerReleased,cleanupReturned,requestAborted,fatalSet}){
  return classified===true&&cancelReturned===true&&readerReleased===true&&cleanupReturned===true&&requestAborted===true&&fatalSet===false;
}
export function createWasiHttpHandler(webHandler,types,runFreshRequest){
  if(typeof runFreshRequest!=='function')throw new TypeError('Native request entry is required');
  const{Fields,IncomingBody,OutgoingBody,OutgoingResponse,ResponseOutparam}=types;
  async function handleResources(incoming,outparam){
    let inputBody,inputStream,outgoingResponse,outputBody,outputStream,responseReader,ioAbort,request;
    let incomingEnded=false,responseTransferred=false,responseSet=false,outputFinished=false;
    let headerChildUncertain=false,inputChildUncertain=false,inputBodyUncertain=false,outputChildUncertain=false,outputBodyUncertain=false;
    let primarySet=false,primaryValue,observedIo=false,firstIoReason;
    let outputFailureObserved=false,outputFailureRaw,outputFailureTag;
    let handledClosed=false,cancelReturned=false,readerReleased=false,cleanupReturned=false;
    function rememberFailure(error){if(!primarySet){primarySet=true;primaryValue=error;}}
    function abortObservedIo(reason){
      if(!observedIo){observedIo=true;firstIoReason=reason;}
      try{
        ioAbort.abort(reason);
        const signal=request===undefined?ioAbort.signal:request.signal;
        if(!signal.aborted||signal.reason!==firstIoReason)throw new Error('Observed I/O abort did not propagate');
      }catch(error){rememberFailure(error);}
    }
    function releaseInput(){
      const stream=inputStream;inputStream=undefined;
      if(stream)try{drop(stream);}catch(error){inputChildUncertain=true;rememberFailure(error);}
      // A failed child disposal leaves ownership uncertain; do not then dispose
      // its parent. The export must fail, never claim completed cleanup.
      if(inputChildUncertain)return;
      const body=inputBody;inputBody=undefined;
      if(body)try{
        if(incomingEnded)drop(IncomingBody.finish(body)); // Future intentionally uninspected.
        else drop(body);
      }catch(error){inputBodyUncertain=true;rememberFailure(error);}
    }
    try{
      // Allocation is inside the guard after incoming/outparam ownership entry.
      ioAbort=new AbortController();
      const headers=new Headers(),fieldResource=incoming.headers();
      try{for(const[name,value]of fieldResource.entries())headers.append(name,text(value));}
      catch(error){rememberFailure(error);}
      try{drop(fieldResource);}catch(error){headerChildUncertain=true;rememberFailure(error);}
      if(primarySet)throw primaryValue;
      const scheme=incoming.scheme(),protocol=scheme?.tag==='other'?scheme.val:scheme?.tag??'http';
      const authority=incoming.authority()??headers.get('host')??'localhost';
      const methodValue=incoming.method(),method=methodValue.tag==='other'?methodValue.val:methodValue.tag.toUpperCase();
      const url=protocol+'://'+authority+(incoming.pathWithQuery()??'/');
      inputBody=incoming.consume();let body;
      if(!['GET','HEAD'].includes(method)){
        inputStream=inputBody.stream();
        body=new ReadableStream({
          pull(controller){
            let chunk;
            try{chunk=inputStream.blockingRead(64n*1024n);}
            catch(error){
              const variant=streamError(error);
              if(variant?.tag==='closed'){
                incomingEnded=true;releaseInput();
                if(primarySet)controller.error(primaryValue);else controller.close();
              }else{
                let primary;
                try{primary=streamFailure(error);}catch(conversionError){rememberFailure(conversionError);primary=conversionError;}
                releaseInput();
                controller.error(primary);
                if(variant?.tag==='last-operation-failed')abortObservedIo(primary);
              }
              return;
            }
            if(chunk.length)controller.enqueue(chunk);
          },
          cancel(){releaseInput();if(primarySet)throw primaryValue;},
        });
      }
      request=new Request(url,{method,headers,signal:ioAbort.signal,...(body?{body,duplex:'half'}:{})});
      const response=await webHandler(request);
      if(primarySet)throw primaryValue;
      const fields=[];
      for(const[name,value]of response.headers)if(name!=='set-cookie')fields.push([name,bytes(value)]);
      const cookies=response.headers.getSetCookie?.()??(response.headers.get('set-cookie')?[response.headers.get('set-cookie')]:[]);
      for(const value of cookies)fields.push(['set-cookie',bytes(value)]);
      outgoingResponse=new OutgoingResponse(Fields.fromList(fields));outgoingResponse.setStatusCode(response.status);
      outputBody=outgoingResponse.body();
      const outgoing=outgoingResponse;outgoingResponse=undefined;responseTransferred=true;
      ResponseOutparam.set(outparam,{tag:'ok',val:outgoing});responseSet=true;
      outputStream=outputBody.write();
      if(response.body){
        responseReader=response.body.getReader();
        for(;;){
          const part=await responseReader.read();if(part.done)break;
          for(let offset=0;offset<part.value.byteLength;offset+=4096){
            try{outputStream.blockingWriteAndFlush(part.value.subarray(offset,offset+4096));}
            catch(error){outputFailureObserved=true;outputFailureRaw=error;outputFailureTag=streamError(error)?.tag;throw error;}
          }
        }
      }
      const stream=outputStream;outputStream=undefined;
      try{drop(stream);}catch(error){outputChildUncertain=true;throw error;}
      const finishedBody=outputBody;outputBody=undefined;outputFinished=true;
      OutgoingBody.finish(finishedBody,undefined);
    }catch(error){
      const observedOutput=outputFailureObserved&&outputFailureRaw===error;
      const variant=observedOutput?streamError(error):undefined;
      let primary=error;
      if(observedOutput)try{primary=streamFailure(error);}catch(conversionError){primary=conversionError;}
      if(observedOutput&&responseSet&&['closed','last-operation-failed'].includes(variant?.tag))abortObservedIo(primary);
      if(isObservedClosedOutput({observed:outputFailureObserved,raw:outputFailureRaw,caught:error,tag:outputFailureTag,responseSet})&&!primarySet){
        if(!responseReader)rememberFailure(new Error('Closed output has no response reader'));
        else{
          try{await responseReader.cancel(primary);cancelReturned=true;}catch(cancelError){rememberFailure(cancelError);}
          try{responseReader.releaseLock();responseReader=undefined;readerReleased=true;}catch(lockError){rememberFailure(lockError);}
          if(!primarySet)handledClosed=true;
        }
      }else{
        // Preserve the exact first unknown/falsy primary through later cleanup.
        rememberFailure(primary);
        if(responseReader)try{await responseReader.cancel(primary);}catch(cancelError){rememberFailure(cancelError);}
      }
    }finally{
      if(responseReader)try{responseReader.releaseLock();responseReader=undefined;}catch(error){rememberFailure(error);}
      releaseInput();
      const stream=outputStream;outputStream=undefined;
      if(stream)try{drop(stream);}catch(error){outputChildUncertain=true;rememberFailure(error);}
      const body=outputBody;outputBody=undefined;
      if(body&&!outputFinished&&!outputChildUncertain)try{drop(body);}catch(error){outputBodyUncertain=true;rememberFailure(error);}
      if(outgoingResponse&&!outputChildUncertain&&!outputBodyUncertain)try{drop(outgoingResponse);}catch(error){rememberFailure(error);}
      if(!responseTransferred)try{drop(outparam);}catch(error){rememberFailure(error);}
      if(!headerChildUncertain&&!inputChildUncertain&&!inputBodyUncertain)try{drop(incoming);}catch(error){rememberFailure(error);}
      cleanupReturned=!primarySet&&!headerChildUncertain&&!inputChildUncertain&&!inputBodyUncertain&&!outputChildUncertain&&!outputBodyUncertain;
    }
    if(primarySet)throw primaryValue;
    if(handledClosed&&!mayReturnHandledClosed({classified:handledClosed,cancelReturned,readerReleased,cleanupReturned,
      requestAborted:request?.signal.aborted===true,fatalSet:primarySet}))throw new Error('Known output close cleanup incomplete');
  }
  return{handle(incoming,outparam){
    let entered=false;
    try{return runFreshRequest((...args)=>{entered=true;return handleResources(...args);},undefined,incoming,outparam);}
    catch(error){if(!entered)disposeBeforeEntry(incoming,outparam);throw error;}
  }};
}

// Same pre-entry ownership contract as V4; preserve the original entry error.
export function disposeBeforeEntry(incoming,outparam){
  let failures=0;
  for(const value of[incoming,outparam])try{drop(value);}catch{failures++;}
  if(failures)try{console.error('NEXT_COMPONENT_PRE_ENTRY_DISPOSAL_FAILURE',failures);}catch{}
}
