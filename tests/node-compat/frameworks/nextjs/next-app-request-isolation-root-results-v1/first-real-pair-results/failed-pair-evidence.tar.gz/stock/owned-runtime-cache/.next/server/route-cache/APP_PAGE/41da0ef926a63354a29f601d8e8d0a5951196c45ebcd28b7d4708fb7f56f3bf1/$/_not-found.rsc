1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
7:I[484,[],"OutletBoundary"]
8:"$Sreact.suspense"
a:"ViewportBoundary"
b:I[484,[],"$a"]
d:"MetadataBoundary"
e:I[484,[],"$d"]
10:I[7123,[],"default",1]
:HL["/_next/static/css/672d82054fb4d95a.css","style"]
5:X
6:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","section",null,{"children":[["$","h1",null,{"children":"NEXT_NOT_FOUND"}],["$","p",null,{"children":"Fixture route intentionally missing."}]]}],null,["$","$L7",null,{"children":["$","$8",null,{"name":"Next.MetadataOutlet","children":"$@9"}]}]]}],"p":false,"v":null}}]]
4:[["children",{"s":"_not-found","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$5"},"c":"$Q6"}]]
0:{"P":null,"c":["","_not-found"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/672d82054fb4d95a.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"children":[["$","header",null,{"data-testid":"root-layout","children":"NEXT_ROOT_LAYOUT"}],["$","nav",null,{"children":[["$","a",null,{"href":"/","children":"Home"}],["$","a",null,{"href":"/nested/leaf","children":"Nested"}],["$","a",null,{"href":"/actions","children":"Action"}],["$","a",null,{"href":"/client","children":"Counter"}],["$","a",null,{"href":"/stream","children":"Stream"}]]}],["$","main",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","section",null,{"children":[["$","h1",null,{"children":"NEXT_NOT_FOUND"}],["$","p",null,{"children":"Fixture route intentionally missing."}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]}]]}],"p":false,"v":null},"c":"$Q4"},"h":{"r":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$Lb",null,{"children":"$Lc"}],["$","$Le",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$8",null,{"name":"Next.Metadata","children":"$Lf"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$10",[]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"c2R8ovhEoFinJh6IvlO5M"}
5:C
c:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
11:I[6869,[],"IconMark"]
9:null
f:[["$","title","0",{"children":"Starling Next Runtime Fixture"}],["$","meta","1",{"name":"description","content":"Deterministic App Router runtime compatibility fixture"}],["$","link","2",{"rel":"icon","href":"data:,"}],["$","$L11","3",{}]]
