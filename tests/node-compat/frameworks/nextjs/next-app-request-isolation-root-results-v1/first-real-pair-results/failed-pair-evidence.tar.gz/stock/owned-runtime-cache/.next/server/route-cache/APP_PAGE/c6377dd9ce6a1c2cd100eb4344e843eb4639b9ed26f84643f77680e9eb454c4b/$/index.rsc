1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
5:I[484,[],"OutletBoundary"]
6:"$Sreact.suspense"
8:"ViewportBoundary"
9:I[484,[],"$8"]
b:"MetadataBoundary"
c:I[484,[],"$b"]
e:I[7123,[],"default",1]
:HL["/_next/static/css/672d82054fb4d95a.css","style"]
4:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","section",null,{"data-testid":"home","children":[["$","h1",null,{"children":"NEXT_HOME_STATIC"}],["$","p",null,{"children":"Deterministic static App Router page."}]]}],null,["$","$L5",null,{"children":["$","$6",null,{"name":"Next.MetadataOutlet","children":"$@7"}]}]]}],"p":false,"v":null}}]]
0:{"P":null,"c":["",""],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/672d82054fb4d95a.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"children":[["$","header",null,{"data-testid":"root-layout","children":"NEXT_ROOT_LAYOUT"}],["$","nav",null,{"children":[["$","a",null,{"href":"/","children":"Home"}],["$","a",null,{"href":"/nested/leaf","children":"Nested"}],["$","a",null,{"href":"/actions","children":"Action"}],["$","a",null,{"href":"/client","children":"Counter"}],["$","a",null,{"href":"/stream","children":"Stream"}]]}],["$","main",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","section",null,{"children":[["$","h1",null,{"children":"NEXT_NOT_FOUND"}],["$","p",null,{"children":"Fixture route intentionally missing."}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]}]]}],"p":false,"v":null},"c":"$Q4"},"h":{"r":["$","$1","h",{"children":[null,["$","$L9",null,{"children":"$La"}],["$","$Lc",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$6",null,{"name":"Next.Metadata","children":"$Ld"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$e",[]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"c2R8ovhEoFinJh6IvlO5M"}
a:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
f:I[6869,[],"IconMark"]
7:null
d:[["$","title","0",{"children":"Starling Next Runtime Fixture"}],["$","meta","1",{"name":"description","content":"Deterministic App Router runtime compatibility fixture"}],["$","link","2",{"rel":"icon","href":"data:,"}],["$","$Lf","3",{}]]
