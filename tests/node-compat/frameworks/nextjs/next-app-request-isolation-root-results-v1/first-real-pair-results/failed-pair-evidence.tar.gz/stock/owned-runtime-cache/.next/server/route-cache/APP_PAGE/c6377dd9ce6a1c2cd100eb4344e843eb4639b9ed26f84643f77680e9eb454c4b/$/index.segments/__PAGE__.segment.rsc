1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
7:I[484,[],"OutletBoundary"]
8:"$Sreact.suspense"
b:"ViewportBoundary"
c:I[484,[],"$b"]
d:"MetadataBoundary"
e:I[484,[],"$d"]
f:I[6869,[],"IconMark"]
:HL["/_next/static/css/672d82054fb4d95a.css","style"]
5:X
6:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[["$","section",null,{"data-testid":"home","children":[["$","h1",null,{"children":"NEXT_HOME_STATIC"}],["$","p",null,{"children":"Deterministic static App Router page."}]]}],null,["$","$L7",null,{"children":["$","$8",null,{"name":"Next.MetadataOutlet","children":"$@9"}]}]]}],"p":"$@a","v":null,"s":"$5"}}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/672d82054fb4d95a.css","precedence":"next"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"children":[["$","header",null,{"data-testid":"root-layout","children":"NEXT_ROOT_LAYOUT"}],["$","nav",null,{"children":[["$","a",null,{"href":"/","children":"Home"}],["$","a",null,{"href":"/nested/leaf","children":"Nested"}],["$","a",null,{"href":"/actions","children":"Action"}],["$","a",null,{"href":"/client","children":"Counter"}],["$","a",null,{"href":"/stream","children":"Stream"}]]}],["$","main",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}],"notFound":[["$","section",null,{"children":[["$","h1",null,{"children":"NEXT_NOT_FOUND"}],["$","p",null,{"children":"Fixture route intentionally missing."}]]}],[]]}]}]]}]}]]}],"p":"$@4","v":null,"s":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$Lc",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$Le",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$8",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Starling Next Runtime Fixture"}],["$","meta","1",{"name":"description","content":"Deterministic App Router runtime compatibility fixture"}],["$","link","2",{"rel":"icon","href":"data:,"}],["$","$Lf","3",{}]]}]}],null]}],null]}],"p":"$@10","v":null,"s":"$5"}},"a":"$@11","u":"$@12","b":"c2R8ovhEoFinJh6IvlO5M"}
9:null
5:300
12:true
5:C
11:0
4:"$undefined"
10:"$undefined"
a:"$undefined"
