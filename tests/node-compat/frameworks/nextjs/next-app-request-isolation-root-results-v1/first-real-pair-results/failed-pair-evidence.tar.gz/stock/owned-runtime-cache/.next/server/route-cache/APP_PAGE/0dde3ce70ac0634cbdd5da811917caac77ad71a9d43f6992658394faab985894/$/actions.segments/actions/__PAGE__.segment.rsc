1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
b:I[484,[],"OutletBoundary"]
c:"$Sreact.suspense"
f:"ViewportBoundary"
10:I[484,[],"$f"]
11:"MetadataBoundary"
12:I[484,[],"$11"]
13:I[6869,[],"IconMark"]
:HL["/_next/static/css/672d82054fb4d95a.css","style"]
5:X
8:X
8:C
a:{"id":"40ca0bda6c41d5a4ff46cda3035ad9babb89d96900","bound":null}
9:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[["$","section",null,{"children":[["$","h1",null,{"children":"NEXT_SERVER_ACTION_FORM"}],["$","form",null,{"action":"$ha","data-testid":"server-action","children":[["$","label",null,{"children":["Value ",["$","input",null,{"name":"value","defaultValue":"fixture-action","maxLength":64}]]}],["$","button",null,{"type":"submit","children":"Submit action"}]]}]]}],null,["$","$Lb",null,{"children":["$","$c",null,{"name":"Next.MetadataOutlet","children":"$@d"}]}]]}],"p":"$@e","v":null,"s":"$5"}}]]
6:[["children",{"s":"actions","h":96,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"p":"$@7","v":"$8","s":"$5"},"c":"$Q9"}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/672d82054fb4d95a.css","precedence":"next"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"children":[["$","header",null,{"data-testid":"root-layout","children":"NEXT_ROOT_LAYOUT"}],["$","nav",null,{"children":[["$","a",null,{"href":"/","children":"Home"}],["$","a",null,{"href":"/nested/leaf","children":"Nested"}],["$","a",null,{"href":"/actions","children":"Action"}],["$","a",null,{"href":"/client","children":"Counter"}],["$","a",null,{"href":"/stream","children":"Stream"}]]}],["$","main",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}],"notFound":[["$","section",null,{"children":[["$","h1",null,{"children":"NEXT_NOT_FOUND"}],["$","p",null,{"children":"Fixture route intentionally missing."}]]}],[]]}]}]]}]}]]}],"p":"$@4","v":null,"s":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L10",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L12",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$c",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Starling Next Runtime Fixture"}],["$","meta","1",{"name":"description","content":"Deterministic App Router runtime compatibility fixture"}],["$","link","2",{"rel":"icon","href":"data:,"}],["$","$L13","3",{}]]}]}],null]}],null]}],"p":"$@14","v":null,"s":"$5"}},"a":"$@15","u":"$@16","b":"c2R8ovhEoFinJh6IvlO5M"}
d:null
5:300
16:true
5:C
15:0
7:"$undefined"
4:"$undefined"
14:"$undefined"
e:"$undefined"
