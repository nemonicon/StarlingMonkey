1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
8:I[484,[],"OutletBoundary"]
9:"$Sreact.suspense"
b:"ViewportBoundary"
c:I[484,[],"$b"]
e:"MetadataBoundary"
f:I[484,[],"$e"]
11:I[7123,[],"default",1]
:HL["/_next/static/css/672d82054fb4d95a.css","style"]
5:X
7:{"id":"40ca0bda6c41d5a4ff46cda3035ad9babb89d96900","bound":null}
6:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","section",null,{"children":[["$","h1",null,{"children":"NEXT_SERVER_ACTION_FORM"}],["$","form",null,{"action":"$h7","data-testid":"server-action","children":[["$","label",null,{"children":["Value ",["$","input",null,{"name":"value","defaultValue":"fixture-action","maxLength":64}]]}],["$","button",null,{"type":"submit","children":"Submit action"}]]}]]}],null,["$","$L8",null,{"children":["$","$9",null,{"name":"Next.MetadataOutlet","children":"$@a"}]}]]}],"p":false,"v":null}}]]
4:[["children",{"s":"actions","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$5"},"c":"$Q6"}]]
0:{"P":null,"c":["","actions"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/672d82054fb4d95a.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"children":[["$","header",null,{"data-testid":"root-layout","children":"NEXT_ROOT_LAYOUT"}],["$","nav",null,{"children":[["$","a",null,{"href":"/","children":"Home"}],["$","a",null,{"href":"/nested/leaf","children":"Nested"}],["$","a",null,{"href":"/actions","children":"Action"}],["$","a",null,{"href":"/client","children":"Counter"}],["$","a",null,{"href":"/stream","children":"Stream"}]]}],["$","main",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","section",null,{"children":[["$","h1",null,{"children":"NEXT_NOT_FOUND"}],["$","p",null,{"children":"Fixture route intentionally missing."}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]}]]}],"p":false,"v":null},"c":"$Q4"},"h":{"r":["$","$1","h",{"children":[null,["$","$Lc",null,{"children":"$Ld"}],["$","$Lf",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$9",null,{"name":"Next.Metadata","children":"$L10"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$11",[]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"c2R8ovhEoFinJh6IvlO5M"}
5:C
d:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
12:I[6869,[],"IconMark"]
a:null
10:[["$","title","0",{"children":"Starling Next Runtime Fixture"}],["$","meta","1",{"name":"description","content":"Deterministic App Router runtime compatibility fixture"}],["$","link","2",{"rel":"icon","href":"data:,"}],["$","$L12","3",{}]]
