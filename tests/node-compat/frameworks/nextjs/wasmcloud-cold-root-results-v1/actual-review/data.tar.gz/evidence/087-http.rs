//! HTTP server plugin for handling incoming HTTP requests.
//!
//! This plugin implements the `wasi:http/incoming-handler` interface, allowing
//! WebAssembly components to handle HTTP requests. It provides a complete HTTP
//! server implementation with support for:
//!
//! - Virtual hosting based on Host headers
//! - TLS/HTTPS connections
//! - Component isolation per request
//! - Graceful shutdown capabilities
//!
//! # Architecture
//!
//! The HTTP server plugin works by:
//! 1. Binding to a TCP socket and listening for connections
//! 2. Routing requests to components based on the Host header
//! 3. Creating isolated component instances for each request
//! 4. Managing the request/response lifecycle through WASI-HTTP
//! ```

use std::sync::atomic::AtomicBool;
use std::{
    collections::HashMap,
    net::SocketAddr,
    path::Path,
    sync::{Arc, OnceLock},
    time::Duration,
};

use crate::engine::abandon::{AbandonFlag, AbandonOnDrop, DispatchedCall};
use crate::host::allowed_hosts::AllowedHost;
use crate::host::trigger_service::{BrokerMessage, MessagingJob};
use crate::observability::rate_limit::RateLimitedWarn;
use crate::{
    engine::ctx::SharedCtx,
    observability::{MeterKind, Meters},
};
use url::Url;

use crate::{engine::workload::ResolvedWorkload, observability::GuestMeter};
use anyhow::{Context, ensure};
use http_body_util::BodyExt;
use hyper::client::conn::http2;
use hyper_util::{
    rt::{TokioExecutor, TokioTimer},
    server::conn::auto,
};
use opentelemetry::KeyValue;
use opentelemetry::context::FutureExt;
use opentelemetry_semantic_conventions::attribute::{
    ERROR_TYPE, HTTP_REQUEST_METHOD, HTTP_RESPONSE_BODY_SIZE, HTTP_RESPONSE_STATUS_CODE,
    OTEL_STATUS_CODE, RPC_GRPC_STATUS_CODE, SERVER_ADDRESS, SERVER_PORT, URL_FULL, URL_PATH,
};
use tokio::net::{TcpListener, TcpStream};
use tokio::task::JoinHandle;
use tracing::{Instrument, debug, error, info, instrument, warn};
use wasmtime::Store;
use wasmtime::component::InstancePre;
use wasmtime_wasi_http::{
    RequestOptions, WasiBody, WasiHttpView,
    io::TokioIo,
    p2::bindings::{ProxyPre, http::types::Scheme},
};

use rustls::ServerConfig;
use rustls::pki_types::{CertificateDer, PrivateKeyDer, pem::PemObject};
use tokio::sync::{RwLock, Semaphore, mpsc};
use tokio_rustls::TlsAcceptor;

/// Validates a hostname according to RFC 1123.
fn is_valid_hostname(host: &str) -> bool {
    !host.is_empty()
        && host.len() <= 253
        && host.split('.').all(|label| {
            !label.is_empty()
                && label.len() <= 63
                && label
                    .bytes()
                    .all(|b| b.is_ascii_alphanumeric() || b == b'-')
                && !label.starts_with('-')
                && !label.ends_with('-')
        })
}

/// A URL path prefix in the single form the routing table stores: no trailing
/// slash, and a leading slash supplied if the author omitted one. An absent,
/// empty or `"/"` value is the empty prefix, a catch-all matching every path.
///
/// A newtype rather than a bare `String` because registration and lookup have
/// to normalize identically: a route registered as `hello` that never matches
/// a request for `/hello` is silent, and a value that can only be built through
/// [`Self::new`] makes agreement a property of the type instead of a
/// convention two call sites have to keep.
///
/// The derived `Ord` is plain lexicographic. Most-specific-first is a property
/// of a *bucket*, not of a path, and lives on [`PathBucket`].
#[derive(Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct NormalizedPathPrefix(String);

impl NormalizedPathPrefix {
    /// Normalize `path` into the stored form.
    pub fn new(path: impl AsRef<str>) -> Self {
        let path = path.as_ref().trim().trim_end_matches('/');
        if path.is_empty() {
            Self(String::new())
        } else if path.starts_with('/') {
            Self(path.to_string())
        } else {
            Self(format!("/{path}"))
        }
    }

    /// The prefix as it is stored, `""` for the catch-all.
    pub fn as_str(&self) -> &str {
        &self.0
    }

    /// Whether this is the catch-all, matching every path.
    pub fn is_catch_all(&self) -> bool {
        self.0.is_empty()
    }

    /// Whether `path` falls under this prefix, matching on `/` segment
    /// boundaries so `/fn` covers `/fn` and `/fn/x` but not `/fnord`. The
    /// catch-all matches everything.
    pub fn matches(&self, path: &str) -> bool {
        if self.is_catch_all() {
            return true;
        }
        match path.strip_prefix(self.as_str()) {
            Some(rest) => rest.is_empty() || rest.starts_with('/'),
            None => false,
        }
    }
}

impl std::fmt::Display for NormalizedPathPrefix {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.0)
    }
}

/// Who may reach a route.
///
/// The two are a partition, not a hierarchy: a name reachable over the network
/// is not automatically reachable in-memory, and vice versa. That is the whole
/// point of [`RouteScope::Local`] — a workload opts a name into the same-host
/// short-circuit deliberately, and the host must also have local routing
/// enabled, so neither the workload author nor the operator can open that door
/// alone (the same two-key shape as `allowedHostLoopback` +
/// `--allow-host-loopback`).
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum RouteScope {
    /// Declared by `host`/`host-aliases`: served for requests arriving on the
    /// host's HTTP listener. Never short-circuits a co-located caller's egress.
    Ingress,
    /// Declared by `localRoute`: served only to a co-located workload's
    /// outgoing request, in-memory, and only when the host runs with local
    /// routing enabled. Never reachable from the network, so a name that exists
    /// nowhere in DNS cannot be reached by anyone dialling the host's port with
    /// a forged `Host` header.
    Local,
}

/// One route a workload's HTTP handler serves: a hostname, optionally scoped to
/// a path prefix, reachable by one [`RouteScope`].
///
/// The inbound path ([`Router::route_incoming_request`]) and the same-host
/// egress short-circuit ([`Router::route_local_egress`]) resolve against one
/// table of these through one matcher, differing only in the scope they ask
/// for — so the two directions cannot drift apart in how they match, only in
/// what they are allowed to see.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct IngressRoute {
    /// RFC 1123 hostname, stored lowercased and without any port.
    pub host: String,
    /// Path prefix scoping this route; the catch-all serves every path.
    pub path_prefix: NormalizedPathPrefix,
    /// Who may reach this route.
    pub scope: RouteScope,
}

impl IngressRoute {
    /// A network-reachable route serving every path on `host`.
    pub fn ingress(host: impl AsRef<str>) -> Self {
        Self::new(host, "", RouteScope::Ingress)
    }

    /// A same-host-only route serving `path_prefix` and below on `host`. An
    /// empty prefix serves every path.
    pub fn local(host: impl AsRef<str>, path_prefix: impl AsRef<str>) -> Self {
        Self::new(host, path_prefix, RouteScope::Local)
    }

    fn new(host: impl AsRef<str>, path_prefix: impl AsRef<str>, scope: RouteScope) -> Self {
        Self {
            // Hostnames are case-insensitive (RFC 1123) and the host serves one
            // HTTP port, so neither case nor port carries routing information.
            // Normalizing here means every lookup can normalize the same way and
            // the two sides are guaranteed to agree.
            //
            // `split_host_port` rather than `Url`, deliberately: the value this
            // has to agree with is a raw `Host` header, split by
            // `select_workload` on the per-request path, and a header is an
            // authority rather than a URL. Parsing the two sides with two
            // grammars is how a name registered one way stops matching a
            // request spelled the other. `localRoute` entries, which are
            // authored rather than received, go through `Url` in
            // `parse_local_route` before they reach here.
            host: split_host_port(host.as_ref()).0.to_ascii_lowercase(),
            path_prefix: NormalizedPathPrefix::new(path_prefix),
            scope,
        }
    }
}

/// Parse one comma-separated `localRoute` entry: either a bare hostname
/// (`functiona.internal`, serving every path on it) or a hostname with a path
/// prefix (`functiona.internal/hello`, serving that prefix and below).
///
/// Returns `None` for anything whose authority is not a valid RFC 1123
/// hostname, including a bare path — a `localRoute` always names a host,
/// because "every authority, this path" would let one workload intercept a
/// co-located caller's traffic to any destination.
///
/// Public so a host front-end can validate `localRoute` entries at
/// configuration time rather than discovering a typo when the router silently
/// drops it, such as when using with `wash dev`.
pub fn parse_local_route(entry: &str) -> Option<IngressRoute> {
    let entry = entry.trim();
    if entry.is_empty() {
        return None;
    }
    // Anything that already parses on its own carries a scheme, and a scheme
    // has no meaning here: dispatch is in-memory, so there is nothing for
    // `http://` or `https://` to select. Splitting such an entry by hand reads
    // the scheme as the hostname (`http://svc/x` -> host `http`, path
    // `/svc/x`), a route that looks perfectly valid and matches nothing, so
    // refuse it rather than register the misparse. A ported entry
    // (`svc.internal:8080/x`) lands here too — the URL parser reads
    // `svc.internal` as the scheme — which is the right answer for the reason
    // below.
    if Url::parse(entry).is_ok() {
        return None;
    }
    // A bare path names no authority, and "any authority, this path" would let
    // one workload intercept a co-located caller's traffic to any destination.
    // Checked before the parse below rather than after it, because the URL
    // grammar is tolerant of extra leading slashes for a special scheme: it
    // reads `http:///hello` as the authority `hello`, which is the opposite of
    // what `/hello` says.
    if entry.starts_with('/') {
        return None;
    }
    // Parsed under a scheme the entry does not have, so the authority is read
    // by the same URL grammar a request URI is read by: IPv6 brackets,
    // percent-encoding, userinfo and an empty host are all the parser's
    // problem rather than this function's.
    let url = Url::parse(&format!("http://{entry}")).ok()?;
    // A port is not part of the contract. A local route is served in-memory,
    // where no port is listened on, and matching one against a request's port
    // would promise a distinction dispatch cannot honour.
    if url.port().is_some() {
        return None;
    }
    // Credentials, a query or a fragment carry no routing meaning, and
    // accepting them would quietly discard whatever the author meant by them.
    if !url.username().is_empty()
        || url.password().is_some()
        || url.query().is_some()
        || url.fragment().is_some()
    {
        return None;
    }
    // `Url` also accepts IP literals and IDN, which the route table does not:
    // it is keyed by the RFC 1123 names `host`/`host-aliases` register, and a
    // name it cannot hold is better refused loudly than stored unmatched.
    let host = url.host_str()?;
    is_valid_hostname(host).then(|| IngressRoute::local(host, url.path()))
}

/// Collect the routes a workload's HTTP handler serves:
///
/// - `host` plus any comma-separated `host-aliases` become
///   [`RouteScope::Ingress`] routes serving every path.
/// - Any comma-separated `localRoute` entries become [`RouteScope::Local`]
///   routes, each optionally scoped to a path prefix (`host` or `host/path`).
///
/// `host` and `host-aliases` entries that are not valid RFC 1123 hostnames are
/// skipped with a warning — a discarded alias should be visible, but it must
/// not take a serving workload down. An invalid `localRoute` entry is an error
/// instead: dropping it would quietly send co-located callers to the network
/// for a name its author meant to keep on the host.
///
/// Unlike [`DynamicRouter::on_workload_resolved`], which fails a component
/// workload that declares no valid host, this is lenient: it returns whatever
/// valid routes exist (possibly none). Service workloads call it from their
/// startup path, where a missing host must not abort the service. It simply
/// won't be reachable via a hostname router (matching how the host-agnostic
/// `DevRouter` ignores hostnames entirely).
pub(crate) fn http_ingress_routes(
    interfaces: &[crate::wit::WitInterface],
) -> anyhow::Result<Vec<IngressRoute>> {
    let Some(http_iface) = interfaces
        .iter()
        .find(|iface| iface.is_incoming_http_handler())
    else {
        return Ok(Vec::new());
    };

    let mut routes = Vec::new();
    if let Some(primary) = http_iface.config.get("host") {
        if is_valid_hostname(primary) {
            routes.push(IngressRoute::ingress(primary));
        } else {
            warn!(host = %primary, "ignoring `host`: not a valid RFC 1123 hostname");
        }
    }
    routes.extend(ingress_aliases(http_iface));
    routes.extend(local_routes(http_iface)?);
    Ok(routes)
}

/// The [`RouteScope::Ingress`] routes from a handler's `host-aliases` config,
/// warning about (and skipping) entries that are not valid hostnames.
fn ingress_aliases(http_iface: &crate::wit::WitInterface) -> Vec<IngressRoute> {
    let Some(aliases) = http_iface.config.get("host-aliases") else {
        return Vec::new();
    };
    aliases
        .split(',')
        .map(str::trim)
        .filter(|entry| !entry.is_empty())
        .filter_map(|entry| {
            if is_valid_hostname(entry) {
                Some(IngressRoute::ingress(entry))
            } else {
                // Silently dropping this is how a workload ends up unreachable
                // at a name its manifest plainly lists — say so.
                warn!(
                    alias = entry,
                    "ignoring `host-aliases` entry: not a valid RFC 1123 hostname \
                     (a path belongs in `localRoute`, not in an alias)"
                );
                None
            }
        })
        .collect()
}

/// The [`RouteScope::Local`] routes from a handler's `localRoute` config,
/// failing on the first entry that does not parse.
fn local_routes(http_iface: &crate::wit::WitInterface) -> anyhow::Result<Vec<IngressRoute>> {
    let Some(declared) = http_iface.config.get("localRoute") else {
        return Ok(Vec::new());
    };
    declared
        .split(',')
        .map(str::trim)
        .filter(|entry| !entry.is_empty())
        .map(|entry| {
            parse_local_route(entry).ok_or_else(|| {
                anyhow::anyhow!(
                    "invalid `localRoute` entry {entry:?}: expected `host` or `host/path` with a \
                     valid RFC 1123 hostname, and no scheme or port"
                )
            })
        })
        .collect()
}

/// Why a request could not be routed to a workload.
#[derive(Debug)]
pub enum RouteError {
    /// Request had no `Host` header which is a genuinely malformed client
    /// request. Maps to 400.
    MissingHost,
    /// No workload is currently bound to the host.
    /// `DynamicRouter` passes the offending host header; `DevRouter` is
    /// host-agnostic and passes an empty string. Maps to 404.
    NoWorkloadForHost(String),
    /// The host is served, but no workload claims a path prefix covering this
    /// request's path. Distinct from [`Self::NoWorkloadForHost`] because the
    /// two have different causes — an unrouted hostname versus a hostname
    /// whose routes are all path-scoped more narrowly. Maps to 404.
    NoWorkloadForPath { host: String, path: String },
    /// Router is momentarily unable to read its routing table (lock
    /// contention under heavy load). Retrying should succeed. Maps to 503.
    Unavailable,
}

impl RouteError {
    /// HTTP status code for this routing failure.
    pub fn status(&self) -> u16 {
        match self {
            Self::MissingHost => 400,
            Self::NoWorkloadForHost(_) | Self::NoWorkloadForPath { .. } => 404,
            Self::Unavailable => 503,
        }
    }
}

impl std::fmt::Display for RouteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::MissingHost => write!(f, "request has no Host header or :authority"),
            // Empty host means the router is DevRouter and
            // simply has no workload registered so the host header is
            // irrelevant to the failure.
            Self::NoWorkloadForHost(host) if host.is_empty() => {
                write!(f, "no workload registered")
            }
            Self::NoWorkloadForHost(host) => write!(f, "no workload bound to host {host:?}"),
            Self::NoWorkloadForPath { host, path } => write!(
                f,
                "host {host:?} is served, but no workload's path prefix covers {path:?}"
            ),
            Self::Unavailable => write!(f, "router is temporarily unavailable"),
        }
    }
}

impl std::error::Error for RouteError {}

/// Trait defining the routing behavior for HTTP requests
/// Allows for custom routing logic based on workload IDs and requests
/// Use this trait to implement custom routing strategies with the default HTTP Extension
#[async_trait::async_trait]
pub trait Router: Send + Sync + 'static {
    /// Register a workload that has been resolved
    /// and is guaranteed to be available for handling requests
    async fn on_workload_resolved(
        &self,
        resolved_handle: &ResolvedWorkload,
        component_id: &str,
    ) -> anyhow::Result<()>;

    /// Unregister a workload that is being stopped
    async fn on_workload_unbind(&self, workload_id: &str) -> anyhow::Result<()>;

    /// Register a workload whose long-lived service handles HTTP ingress (the
    /// service exports `wasi:http/handler`). `routes` are the ingress routes the
    /// service serves (see [`http_ingress_routes`]); a hostname-keyed router
    /// registers the workload under each so requests resolve to it.
    /// Default: no-op.
    async fn on_service_http_resolved(
        &self,
        _workload_id: &str,
        _routes: &[IngressRoute],
    ) -> anyhow::Result<()> {
        Ok(())
    }

    /// Determine if the outgoing request is allowed
    fn allow_outgoing_request(
        &self,
        workload_id: &str,
        request: &hyper::Request<WasiBody>,
        options: Option<RequestOptions>,
        allowed_hosts: &[AllowedHost],
    ) -> anyhow::Result<()>;

    /// Pick a workload ID based on the incoming request.
    ///
    /// On failure, the returned [`RouteError`] determines the HTTP status
    /// code surfaced to the client (see [`RouteError::status`]).
    fn route_incoming_request(
        &self,
        req: &hyper::Request<hyper::body::Incoming>,
    ) -> Result<String, RouteError>;

    /// Match an outgoing request's authority *and path* against the
    /// [`RouteScope::Local`] routes this ingress serves — the `localRoute`
    /// entries co-located workloads declared — returning the workload ID to
    /// dispatch to in-memory, or `None` to egress over the network as usual.
    ///
    /// Resolves through the same matcher as [`Self::route_incoming_request`],
    /// differing only in the scope it asks for: a name published to the network
    /// via `host`/`host-aliases` is not short-circuited, and a `localRoute` name
    /// is not reachable from the network.
    ///
    /// `can_serve` reports whether the ingress can dispatch to a workload right
    /// now. Only return a workload it accepted, so one unready replica does not
    /// send callers to the network while a ready one is registered.
    ///
    /// Only consulted when same-host local routing is enabled on the ingress
    /// (see [`IngressBuilder::local_routing`]). Default: never route locally.
    fn route_local_egress(
        &self,
        _uri: &hyper::Uri,
        _can_serve: &mut dyn FnMut(&str) -> bool,
    ) -> Option<String> {
        None
    }
}

/// Router that routes requests by 'Host' header, configured via WitInterface config
///
/// Requests read an ArcSwap snapshot without taking the writers' mutex.
/// Persistent maps and replica sets share unchanged nodes between snapshots,
/// so an update copies paths through those structures instead of the entire
/// touched shard or replica set. Path buckets remain a small ordered vector.
pub struct DynamicRouter {
    /// Maps a hostname to the path-scoped buckets registered under it, split
    /// across shards by hostname. Updates copy persistent tree paths.
    hosts: Box<[RouteShard; ROUTE_SHARDS]>,
    /// Maps workload_id -> every route (primary + aliases, each with its path
    /// prefix) registered for it, so `on_workload_unbind` can remove all
    /// entries cleanly. Writers hold it across their whole update, which keeps
    /// it and `hosts` in step and serializes writers, so a writer's
    /// load-copy-store of a shard never races another; requests never take it.
    workload_to_host: std::sync::Mutex<HashMap<String, Vec<IngressRoute>>>,
}

/// One shard of [`DynamicRouter`]'s hostname table.
///
/// A hostname's buckets are held longest-prefix-first so a lookup is an
/// ordered scan that stops at the first match. One hostname carries few
/// prefixes in practice, so this stays cheaper than a trie.
///
/// Cloning a shard shares its root. Mutations copy tree paths and the edited
/// hostname's bucket vector; replica sets share their unchanged tree nodes.
type HostBuckets = imbl::HashMap<Arc<str>, Arc<Vec<PathBucket>>>;

/// A shard on its own cache line pair, so a writer storing one shard does not
/// invalidate the line readers of its neighbours load from.
#[repr(align(128))]
#[derive(Default)]
struct RouteShard(arc_swap::ArcSwap<HostBuckets>);

/// Bound each snapshot publication to one hostname shard.
///
/// An edit copies one persistent-tree path whatever the shard count, so the
/// shards no longer bound how much a write copies. They keep a writer's store
/// off the `ArcSwap` and cache lines that requests for other hostnames load,
/// and keep each shard's tree a level or two shallower. 256 keeps an empty
/// router small: 32 KiB of 128-byte shards, plus one ~48-byte `Arc` per shard
/// for its empty map (an empty `imbl::HashMap` allocates no root node).
const ROUTE_SHARDS: usize = 256;

impl Default for DynamicRouter {
    fn default() -> Self {
        Self {
            hosts: Box::new(std::array::from_fn(|_| RouteShard::default())),
            workload_to_host: Default::default(),
        }
    }
}

/// Every workload replica serving one `(hostname, path_prefix, scope)` triple.
/// A persistent ordered set keeps membership deterministic; a request picks one
/// replica at random (see [`DynamicRouter::select_workload`]).
///
/// `scope` is part of the key, not a property of the bucket: the same
/// `host/path` may be declared both network-reachable and same-host-reachable,
/// by the same workload or by different ones, and those are different routes.
#[derive(Clone)]
struct PathBucket {
    prefix: NormalizedPathPrefix,
    scope: RouteScope,
    workloads: imbl::OrdSet<String>,
}

/// Most-specific-first: a longer prefix sorts before a shorter one, and the
/// catch-all sorts last, which is what makes it a fallback rather than a shadow
/// over every scoped route registered under the same hostname.
/// [`DynamicRouter::select_workload`] relies on that order, so it lives here
/// rather than in a `sort_by` closure a later edit would have to keep in step.
///
/// `workloads` is deliberately outside the ordering: it is mutated in place as
/// replicas come and go, and an order that shifted underneath a container would
/// be a bug in any container holding one. That is also why the buckets stay in
/// a sorted `Vec` rather than the `BTreeSet` this `Ord` would otherwise allow —
/// a `BTreeSet` hands out no `&mut` to its elements, so every register and
/// unbind would have to remove the bucket and reinsert it just to add or drop
/// one replica.
impl Ord for PathBucket {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        other
            .prefix
            .as_str()
            .len()
            .cmp(&self.prefix.as_str().len())
            .then_with(|| self.prefix.cmp(&other.prefix))
            .then_with(|| self.scope.cmp(&other.scope))
    }
}

impl PartialOrd for PathBucket {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

/// Two buckets are the same bucket when they key the same route, whatever
/// replicas each currently holds — the same identity `Ord` compares on.
impl PartialEq for PathBucket {
    fn eq(&self, other: &Self) -> bool {
        self.prefix == other.prefix && self.scope == other.scope
    }
}

impl Eq for PathBucket {}

/// Take the writers' lock whether or not a writer panicked holding it: no
/// snapshots already published remain valid. An interrupted multi-shard update
/// can be partial; poisoning alone must not make unrelated routes unavailable.
fn lock_routes<G>(result: std::sync::LockResult<G>) -> G {
    result.unwrap_or_else(std::sync::PoisonError::into_inner)
}

/// The shard `host` lives in. FNV-1a rather than the maps' SipHash: it runs on
/// every request, the shard index needs spread rather than DoS resistance (a
/// probe cannot change which shard a registered name lives in), and it folds
/// ASCII case so a request's mixed-case Host needs no lowercased copy to pick
/// its shard.
fn shard_index(host: &str) -> usize {
    let hash = host.bytes().fold(0xcbf2_9ce4_8422_2325_u64, |hash, byte| {
        (hash ^ u64::from(byte.to_ascii_lowercase())).wrapping_mul(0x0100_0000_01b3)
    });
    // `usize` is at least 32 bits wide, plenty to pick one of 256 shards.
    (hash % ROUTE_SHARDS as u64) as usize
}

impl DynamicRouter {
    fn shard(&self, index: usize) -> &arc_swap::ArcSwap<HostBuckets> {
        let [first, ..] = &*self.hosts;
        &self.hosts.get(index).unwrap_or(first).0
    }

    /// Apply `edit` to every route in `routes`, copying each touched shard
    /// once and publishing it with one store. Callers hold `workload_to_host`,
    /// which serializes writers, so nothing can store a shard between this
    /// load and store.
    fn edit_shards(
        &self,
        routes: &[IngressRoute],
        mut edit: impl FnMut(&mut HostBuckets, &IngressRoute),
    ) {
        let mut by_shard: Vec<(usize, &IngressRoute)> =
            routes.iter().map(|r| (shard_index(&r.host), r)).collect();
        by_shard.sort_by_key(|(index, _)| *index);
        for group in by_shard.chunk_by(|(a, _), (b, _)| a == b) {
            let Some((index, _)) = group.first() else {
                continue;
            };
            let shard = self.shard(*index);
            let mut table = HostBuckets::clone(&shard.load());
            for (_, route) in group {
                edit(&mut table, route);
            }
            shard.store(Arc::new(table));
        }
    }

    /// Register `workload_id` under every route in `routes`, updating both the
    /// forward (host -> path buckets -> replicas) and reverse (workload ->
    /// routes) maps so [`Router::on_workload_unbind`] can later remove every
    /// entry cleanly. Idempotent: re-registering the same workload (e.g. a
    /// service restart) leaves the tables unchanged.
    fn register_routes(&self, workload_id: &str, routes: &[IngressRoute]) {
        let mut workloads = lock_routes(self.workload_to_host.lock());
        workloads.insert(workload_id.to_string(), routes.to_vec());
        self.edit_shards(routes, |table, route| {
            let buckets = Arc::make_mut(table.entry(Arc::from(route.host.as_str())).or_default());
            match buckets
                .iter_mut()
                .find(|b| b.prefix == route.path_prefix && b.scope == route.scope)
            {
                Some(bucket) => {
                    bucket.workloads.insert(workload_id.to_string());
                }
                None => {
                    buckets.push(PathBucket {
                        prefix: route.path_prefix.clone(),
                        scope: route.scope,
                        workloads: imbl::OrdSet::unit(workload_id.to_string()),
                    });
                    // Most specific first — see `PathBucket`'s `Ord`.
                    buckets.sort();
                }
            }
        });
    }

    /// Remove every route `workload_id` registered, dropping emptied buckets
    /// and hostnames. A no-op for a workload that registered none.
    fn unregister_routes(&self, workload_id: &str) {
        let mut workloads = lock_routes(self.workload_to_host.lock());
        let Some(routes) = workloads.remove(workload_id) else {
            return;
        };
        self.edit_shards(&routes, |table, route| {
            let Some(buckets) = table.get_mut(route.host.as_str()) else {
                return;
            };
            let buckets = Arc::make_mut(buckets);
            if let Some(bucket) = buckets
                .iter_mut()
                .find(|b| b.prefix == route.path_prefix && b.scope == route.scope)
            {
                bucket.workloads.remove(workload_id);
            }
            // Drop emptied buckets, and the hostname itself once its last
            // route is gone, so an unbound workload leaves nothing behind for
            // `select_workload` to walk past.
            buckets.retain(|b| !b.workloads.is_empty());
            if buckets.is_empty() {
                table.remove(route.host.as_str());
            }
        });
    }

    /// The buckets registered under `host`, as a snapshot that outlives later
    /// writes.
    #[cfg(test)]
    fn host_buckets(&self, host: &str) -> Option<Arc<Vec<PathBucket>>> {
        self.shard(shard_index(host)).load().get(host).cloned()
    }

    /// Resolve `(host, path)` to one workload reachable at `scope`, spreading
    /// load at random across every replica bound to the matching route.
    ///
    /// `scope` is what separates the two directions: an inbound request asks for
    /// [`RouteScope::Ingress`] and can never land on a `localRoute`, while a
    /// co-located caller's egress asks for [`RouteScope::Local`] and can never
    /// short-circuit to a name that was only published to the network. Both go
    /// through this one function, so the matching rules cannot drift apart.
    ///
    /// A per-thread PRNG ([`fastrand`]) avoids the cross-core cache-line
    /// contention a shared atomic cursor would incur under concurrent load, and
    /// spreads load just as evenly in aggregate. Split out from
    /// [`Router::route_incoming_request`] so the selection logic is
    /// unit-testable without constructing a [`hyper::body::Incoming`].
    fn select_workload(
        &self,
        host: &str,
        path: &str,
        scope: RouteScope,
    ) -> Result<String, RouteError> {
        self.select_serving_workload(host, path, scope, &mut |_| true)
    }

    /// [`Self::select_workload`], skipping replicas `can_serve` rejects. The walk
    /// starts at a random replica and wraps, so load still spreads across the
    /// ready ones; the replica after an unready one takes its share.
    fn select_serving_workload(
        &self,
        host: &str,
        path: &str,
        scope: RouteScope,
        can_serve: &mut dyn FnMut(&str) -> bool,
    ) -> Result<String, RouteError> {
        // A Host header may carry the port the client connected on
        // (`example.com:8080`), and whether it does is up to the client: a
        // browser omits it for the scheme's default port, an OCI client
        // pushing to `127.0.0.1:5000` does not. The host serves one HTTP port,
        // so the port carries no routing information; match on the name alone
        // rather than making callers register every port they might be reached
        // on. Hostnames are also case-insensitive per RFC 1123. Registration
        // normalizes both the same way (see [`IngressRoute::new`]).
        //
        // Lowercase only when needed: nearly every client sends a lowercase
        // Host, and the copy would be the lookup's only allocation.
        let host = split_host_port(host).0;
        let host: std::borrow::Cow<'_, str> = if host.bytes().any(|b| b.is_ascii_uppercase()) {
            host.to_ascii_lowercase().into()
        } else {
            host.into()
        };
        // Keep the ArcSwap guard while matching to avoid an explicit Arc clone
        // for the common lookup path.
        let table = self.shard(shard_index(&host)).load();
        let Some(buckets) = table.get(&*host) else {
            return Err(RouteError::NoWorkloadForHost(host.into_owned()));
        };
        // Only buckets this caller may see. A hostname serving `localRoute`
        // entries is invisible to the network, and vice versa, so "visible"
        // has to be decided before "does the hostname exist" is answered.
        let mut visible = buckets
            .iter()
            .filter(|b| b.scope == scope && !b.workloads.is_empty())
            .peekable();
        if visible.peek().is_none() {
            return Err(RouteError::NoWorkloadForHost(host.into_owned()));
        }
        // Buckets are sorted longest-prefix-first, so the first match is the
        // most specific one.
        let Some(bucket) = visible.find(|b| b.prefix.matches(path)) else {
            // The hostname is served at this scope, but only under prefixes that
            // do not cover this path — a routing-config mistake worth naming
            // separately from an entirely unserved hostname.
            return Err(RouteError::NoWorkloadForPath {
                host: host.into_owned(),
                path: path.to_string(),
            });
        };
        let start = fastrand::usize(..bucket.workloads.len());
        bucket
            .workloads
            .iter()
            .skip(start)
            .chain(bucket.workloads.iter().take(start))
            .find(|id| can_serve(id))
            .cloned()
            .ok_or_else(|| RouteError::NoWorkloadForHost(host.into_owned()))
    }
}

/// Implementation of Router that maps Host headers to workload IDs
/// based on the 'host' config in the wasi:http/incoming-handler interface
#[async_trait::async_trait]
impl Router for DynamicRouter {
    async fn on_workload_resolved(
        &self,
        resolved_handle: &ResolvedWorkload,
        _component_id: &str,
    ) -> anyhow::Result<()> {
        let Some(http_iface) = resolved_handle
            .host_interfaces()
            .iter()
            .find(|iface| iface.is_incoming_http_handler())
        else {
            anyhow::bail!(
                "workload did not request wasi:http/incoming-handler or wasi:http/handler interface"
            );
        };

        let primary_host = http_iface
            .config
            .get("host")
            .cloned()
            .context("no host header found")?;

        anyhow::ensure!(
            is_valid_hostname(&primary_host),
            "primary host {primary_host:?} is not a valid RFC 1123 hostname"
        );

        // Primary hostname plus any DNS aliases injected by the operator.
        // Aliases are a comma-separated list of Service DNS names (e.g.
        // "my-svc,my-svc.default,my-svc.default.svc,my-svc.default.svc.cluster.local")
        // that allow cluster-internal callers to reach this workload via Service DNS.
        let mut routes = vec![IngressRoute::ingress(&primary_host)];
        routes.extend(ingress_aliases(http_iface));
        // Same-host routes are a separate, opt-in declaration: `localRoute`
        // entries are reachable only in-memory from a co-located workload, and
        // only when the host runs with local routing enabled.
        routes.extend(local_routes(http_iface)?);

        self.register_routes(resolved_handle.id(), &routes);

        Ok(())
    }

    async fn on_service_http_resolved(
        &self,
        workload_id: &str,
        routes: &[IngressRoute],
    ) -> anyhow::Result<()> {
        // A service-only workload (a p3 trigger service serving HTTP) reaches
        // routing here rather than through `on_workload_resolved`. Register its
        // routes exactly like a component workload so requests resolve to it.
        if routes.is_empty() {
            // debug, not warn: a service restart re-resolves, so a misconfigured one would spam.
            debug!(
                workload_id,
                "service has no valid ingress hostnames; not routable by the hostname router"
            );
            return Ok(());
        }
        self.register_routes(workload_id, routes);
        Ok(())
    }

    async fn on_workload_unbind(&self, workload_id: &str) -> anyhow::Result<()> {
        self.unregister_routes(workload_id);
        Ok(())
    }

    fn allow_outgoing_request(
        &self,
        _workload_id: &str,
        request: &hyper::Request<WasiBody>,
        _options: Option<RequestOptions>,
        allowed_hosts: &[AllowedHost],
    ) -> anyhow::Result<()> {
        check_allowed_hosts(request, allowed_hosts)
    }

    /// Pick a workload ID based on the incoming request's `Host` and path,
    /// spreading load at random across every replica bound to the matching
    /// route.
    fn route_incoming_request(
        &self,
        req: &hyper::Request<hyper::body::Incoming>,
    ) -> Result<String, RouteError> {
        let workload_host = req
            .headers()
            .get(hyper::header::HOST)
            .and_then(|h| h.to_str().ok())
            .or_else(|| req.uri().authority().map(|a| a.as_str()))
            .ok_or(RouteError::MissingHost)?;
        // `select_workload` takes no lock and never awaits, so it runs inline
        // on the async worker — no `block_in_place` needed (and routing works
        // on any runtime flavor).
        self.select_workload(workload_host, req.uri().path(), RouteScope::Ingress)
    }

    /// Match an outgoing request against the `localRoute` entries co-located
    /// workloads declared, picking a replica at random exactly like
    /// [`Self::route_incoming_request`] so locally routed calls spread across
    /// co-located replicas too.
    ///
    /// Asks for [`RouteScope::Local`], so a hostname a workload only published
    /// to the network is *not* short-circuited: a workload opts into being
    /// reachable in-memory by declaring `localRoute`, and nothing else.
    fn route_local_egress(
        &self,
        uri: &hyper::Uri,
        can_serve: &mut dyn FnMut(&str) -> bool,
    ) -> Option<String> {
        // Only HTTP(S) is served in-memory. `wasi:http` lets a guest name any
        // scheme it likes, and a request for one the incoming path does not
        // speak (`ws://`, an invented one) has to reach the network, where
        // whatever does speak it lives — answering it here with an HTTP handler
        // would be a protocol swap the caller never asked for. An absent scheme
        // is the outgoing default of `http`.
        if !matches!(uri.scheme_str(), None | Some("http") | Some("https")) {
            return None;
        }
        // A local route names no port (see `parse_local_route`), so a request
        // asking for one other than the scheme's default is asking for
        // something in-memory dispatch cannot promise — a sidecar on :9187, say.
        // Let it egress rather than answering for a port nobody declared.
        if let Some(port) = uri.port_u16()
            && port != default_port_for_scheme(uri.scheme_str())
        {
            return None;
        }
        self.select_serving_workload(uri.host()?, uri.path(), RouteScope::Local, can_serve)
            .ok()
    }
}

/// A request's I/O outcome once its response head has been returned: the
/// request body upload, or the connection carrying the response body. wasmtime
/// keeps it alive while the response body is read and reports its error to the
/// guest.
pub type RequestIoFuture =
    Box<dyn std::future::Future<Output = Result<(), wasmtime_wasi_http::Error>> + Send>;

/// The outcome of an outgoing send: the response and its [`RequestIoFuture`].
pub type SendResult =
    Result<(hyper::Response<WasiBody>, RequestIoFuture), wasmtime_wasi_http::Error>;

/// Future returned by [`OutgoingHandler::send_request`].
pub type SendFuture = Box<dyn std::future::Future<Output = SendResult> + Send>;

/// Trait for custom outgoing HTTP egress. gRPC requests are handled by the
/// runtime before this trait is called.
///
/// # `workload_id` is a trust boundary
///
/// The `workload_id` passed to `send_request` must be the host-assigned
/// identifier of the workload instance making the request — never empty, never
/// derived from guest-controllable data, and never shared between workloads.
/// Implementations (the default one included) key per-workload state on it:
/// connection pools, TLS session-resumption stores, and connection quotas. Two
/// callers presenting the same `workload_id` collapse into one identity and
/// inherit each other's keep-alive connections and TLS session tickets.
pub trait OutgoingHandler: Send + Sync + 'static {
    /// Send an outgoing HTTP request for the given `workload_id`, from a
    /// `wasi:http` 0.2 or 0.3 guest.
    ///
    /// `fut` is a future provided by the WASI runtime to communicate
    /// request-side processing errors back to the guest (for example, a
    /// connection reset that occurs while the request body is being uploaded,
    /// before or while the response arrives). Most implementations can ignore
    /// it (`_fut`). It is provided so that custom transports with out-of-band
    /// error channels can still deliver upload errors to the component after
    /// the response has been returned.
    fn send_request(
        &self,
        workload_id: &str,
        request: hyper::Request<WasiBody>,
        options: Option<RequestOptions>,
        fut: RequestIoFuture,
    ) -> SendFuture;

    /// TLS configuration used for host-mediated egress that bypasses
    /// `send_request` (currently the gRPC fast path).
    /// `None` (the default) means the process-wide default trust roots.
    ///
    /// Host-wide, so it carries no per-workload client identity. Only
    /// handlers that return `None` from [`Self::grpc_transport`] reach it;
    /// one that pools per workload answers gRPC from that workload's own
    /// client and keeps its identity.
    fn client_tls_config(&self) -> Option<Arc<rustls::ClientConfig>> {
        None
    }

    /// Pooled HTTP/2 transport for `workload_id`'s gRPC egress.
    ///
    /// gRPC requests never reach `send_request` — the
    /// runtime routes them itself, because the protocol requires HTTP/2 — but
    /// a handler that pools can serve them here instead, so they reuse
    /// connections and draw on the same quota as the workload's
    /// ordinary egress. `None` (the default) leaves the runtime to open one
    /// HTTP/2 connection per request.
    fn grpc_transport(&self, _workload_id: &str) -> Option<crate::host::http_client::PooledClient> {
        None
    }

    /// Called when a workload binds, before it serves anything, with the
    /// guest calls it may run at once (`pool_size` × `max_concurrency` for a
    /// component keeping instances warm, one otherwise).
    ///
    /// A workload's concurrent outbound requests scale with that, so an
    /// implementation that pools can size itself for the burst instead of
    /// guessing. The default is a no-op.
    fn on_workload_bind(&self, _workload_id: &str, _call_concurrency: usize) {}

    /// Called when a workload is stopped (unbound from the host).
    ///
    /// Implementations holding per-workload state — connection pools, TLS
    /// session stores, quota slots — should release it now
    /// rather than letting it linger until idle expiry: a stopped workload's
    /// pooled connections would otherwise stay open (pinning host-wide
    /// connection permits) for up to the pool idle timeout after the workload
    /// is gone. The default is a no-op for stateless implementations.
    fn on_workload_unbind(&self, _workload_id: &str) {}
}

/// Default [`OutgoingHandler`] — sends requests through per-workload
/// keep-alive connection pools ([`crate::host::http_client::WorkloadClients`])
/// so a workload's repeated and concurrent requests to the same authority
/// reuse connections instead of exhausting ephemeral ports, while components
/// never share a TCP connection with each other. TLS trust roots are
/// configurable (see [`crate::host::http_client::ClientTlsOptions`]).
///
/// Construction does no I/O: unless a configuration is supplied up front, the
/// TLS configuration (and any trust-store read) is built lazily on first use.
pub struct DefaultOutgoingHandler {
    /// Set eagerly by [`Self::with_tls_config`]; populated lazily with the
    /// process-wide default roots otherwise.
    clients: OnceLock<crate::host::http_client::WorkloadClients>,
    /// Where each workload's HTTP allowance comes from; applied when `clients`
    /// is built. See [`Self::with_quotas`].
    quotas: Arc<crate::host::quota::QuotaRegistry>,
}

impl Default for DefaultOutgoingHandler {
    /// A handler with a private quota registry of default size.
    ///
    /// A host that wants a workload's HTTP pool bounded by the *same*
    /// allowance as its raw sockets passes its own registry to
    /// [`DefaultOutgoingHandler::with_quotas`].
    fn default() -> Self {
        Self {
            clients: OnceLock::new(),
            quotas: crate::host::quota::QuotaRegistry::new(Default::default(), None),
        }
    }
}

impl DefaultOutgoingHandler {
    /// Create a handler that verifies outbound TLS against `tls`, and
    /// presents whatever client identity it carries (see
    /// [`crate::host::http_client::ClientTlsOptions`] for building one with
    /// extra CA bundles or a client certificate).
    pub fn with_tls_config(tls: Arc<rustls::ClientConfig>) -> Self {
        Self::with_tls_config_resolver(Arc::new(tls))
    }

    /// Create a handler that resolves outbound TLS per workload, so each can
    /// present its own client identity.
    ///
    /// Otherwise identical to [`Self::with_tls_config`], which is this with a
    /// resolver that answers every workload the same way.
    pub fn with_tls_config_resolver(
        tls: Arc<dyn crate::host::http_client::ClientTlsConfigResolver>,
    ) -> Self {
        let quotas = crate::host::quota::QuotaRegistry::new(Default::default(), None);
        let cell = OnceLock::new();
        let _ = cell.set(
            crate::host::http_client::WorkloadClients::with_tls_config_resolver(
                tls,
                Arc::clone(&quotas),
            ),
        );
        Self {
            clients: cell,
            quotas,
        }
    }

    /// Build a handler from [`ClientTlsOptions`] — the shared wiring for CLI
    /// call sites. Default options defer to the lazily built process-wide
    /// configuration; anything else is built (and validated) eagerly so a bad
    /// CA path fails at startup rather than on the first outbound request.
    ///
    /// [`ClientTlsOptions`]: crate::host::http_client::ClientTlsOptions
    pub fn from_tls_options(
        options: crate::host::http_client::ClientTlsOptions,
    ) -> anyhow::Result<Self> {
        if options == crate::host::http_client::ClientTlsOptions::default() {
            Ok(Self::default())
        } else {
            Ok(Self::with_tls_config(options.build()?))
        }
    }

    /// Draw connections from `quotas` rather than a private registry.
    ///
    /// Pass the host's one registry so a workload's HTTP pool, its raw
    /// sockets, and its inbound published ports share the allowance an
    /// operator configured. Call at construction time, before the handler
    /// serves requests: a client cache that was already built eagerly is
    /// rebuilt, dropping any pooled connections.
    #[must_use]
    pub fn with_quotas(self, quotas: Arc<crate::host::quota::QuotaRegistry>) -> Self {
        let cell = OnceLock::new();
        if let Some(clients) = self.clients.into_inner() {
            // The resolver, not `tls_config()`: taking the host-wide
            // configuration here would collapse every workload's identity
            // onto it.
            let _ = cell.set(
                crate::host::http_client::WorkloadClients::with_tls_config_resolver(
                    clients.tls_config_resolver(),
                    Arc::clone(&quotas),
                ),
            );
        }
        Self {
            clients: cell,
            quotas,
        }
    }

    fn clients(&self) -> &crate::host::http_client::WorkloadClients {
        self.clients.get_or_init(|| {
            crate::host::http_client::WorkloadClients::with_quotas(
                crate::host::http_client::default_client_tls_config(),
                Arc::clone(&self.quotas),
            )
        })
    }
}

impl OutgoingHandler for DefaultOutgoingHandler {
    fn send_request(
        &self,
        workload_id: &str,
        request: hyper::Request<WasiBody>,
        options: Option<RequestOptions>,
        _fut: RequestIoFuture,
    ) -> SendFuture {
        let client = self.clients().client(workload_id);
        Box::new(async move { client.send_request(request, options).await })
    }

    fn client_tls_config(&self) -> Option<Arc<rustls::ClientConfig>> {
        Some(self.clients().tls_config())
    }

    fn grpc_transport(&self, workload_id: &str) -> Option<crate::host::http_client::PooledClient> {
        Some(self.clients().client(workload_id))
    }

    fn on_workload_bind(&self, workload_id: &str, call_concurrency: usize) {
        self.clients()
            .set_call_concurrency(workload_id, call_concurrency);
    }

    fn on_workload_unbind(&self, workload_id: &str) {
        // `get()`, not `clients()`: if no request ever ran there is no cache
        // to clean and nothing to lazily build for the purpose.
        if let Some(clients) = self.clients.get() {
            clients.invalidate(workload_id);
        }
    }
}

/// Development router that routes all requests to the last resolved workload
#[derive(Default)]
pub struct DevRouter {
    last_workload_id: std::sync::RwLock<Option<String>>,
}

#[async_trait::async_trait]
impl Router for DevRouter {
    async fn on_workload_resolved(
        &self,
        resolved_handle: &ResolvedWorkload,
        _component_id: &str,
    ) -> anyhow::Result<()> {
        let mut lock = self
            .last_workload_id
            .write()
            .map_err(|e| anyhow::anyhow!("DevRouter write lock poisoned: {e}"))?;
        lock.replace(resolved_handle.id().to_string());
        Ok(())
    }

    async fn on_workload_unbind(&self, workload_id: &str) -> anyhow::Result<()> {
        let mut lock = self
            .last_workload_id
            .write()
            .map_err(|e| anyhow::anyhow!("DevRouter write lock poisoned: {e}"))?;
        if let Some(current_id) = &*lock
            && current_id == workload_id
        {
            let _ = lock.take();
        }
        Ok(())
    }

    async fn on_service_http_resolved(
        &self,
        workload_id: &str,
        _routes: &[IngressRoute],
    ) -> anyhow::Result<()> {
        // A service-handled workload routes the same way as a component one:
        // DevRouter sends all requests to the most-recently resolved workload,
        // so it ignores hostnames and paths alike.
        let mut lock = self
            .last_workload_id
            .write()
            .map_err(|e| anyhow::anyhow!("DevRouter write lock poisoned: {e}"))?;
        lock.replace(workload_id.to_string());
        Ok(())
    }

    fn allow_outgoing_request(
        &self,
        _workload_id: &str,
        request: &hyper::Request<WasiBody>,
        _options: Option<RequestOptions>,
        allowed_hosts: &[AllowedHost],
    ) -> anyhow::Result<()> {
        check_allowed_hosts(request, allowed_hosts)
    }

    /// Pick a workload ID based on the incoming request
    fn route_incoming_request(
        &self,
        _req: &hyper::Request<hyper::body::Incoming>,
    ) -> Result<String, RouteError> {
        let lock = self
            .last_workload_id
            .try_read()
            .map_err(|_| RouteError::Unavailable)?;
        match &*lock {
            Some(id) => Ok(id.clone()),
            // DevRouter is host-agnostic; signal "nothing registered" via an
            // empty host string (see RouteError::NoWorkloadForHost docs).
            None => Err(RouteError::NoWorkloadForHost(String::new())),
        }
    }
}

/// Take a live handle on a handler that something the handler owns holds
/// weakly, and the one error they all report when it is gone.
///
/// An ingress keeps every routable workload so an inbound request can find one,
/// so anything reachable from a workload holds the handler back weakly or the
/// two pin each other: the workload itself, an ephemeral linked call (which
/// lives in a linker closure, hence in the `InstancePre` the ingress keeps), a
/// service's store recipe, a store's egress hooks, and a bound host component
/// plugin. Strong handles exist for the length of one call and are taken here.
///
/// Callers split two ways, deliberately. A path that cannot proceed without a
/// handler propagates this error; a teardown path asks the `Weak` directly and
/// skips, because a handler that is already gone has nothing left to unbind.
pub(crate) fn live_handler(host: &crate::host::HostRef) -> anyhow::Result<Arc<dyn HostHandler>> {
    host.handler()
        .ok_or_else(|| anyhow::anyhow!("host HTTP handler is no longer available"))
}

/// Trait defining the behavior of a Host HTTP Extension
/// Allows for custom handling of incoming and outgoing HTTP requests
/// Use this trait to implement custom HTTP server transport
#[async_trait::async_trait]
pub trait HostHandler: Send + Sync + 'static {
    /// Inject meters into the handler
    async fn inject_meters(&self, _meters: &Meters) {}
    /// Start the HTTP server
    async fn start(&self) -> anyhow::Result<()>;
    /// Stop the HTTP server
    async fn stop(&self) -> anyhow::Result<()>;

    /// Resolves once this handler's accept loop has stopped and will not run
    /// again — whether it returned an error, returned cleanly, or panicked.
    ///
    /// The loop is spawned detached, so without this its exit is one log line:
    /// the host keeps every workload it was given, keeps answering its control
    /// plane, and serves no HTTP for as long as it runs. Whoever owns the host
    /// watches this so the failure is acted on rather than only recorded; see
    /// [`crate::washlet::ClusterHost`], which ends the host on it.
    ///
    /// Default: pending forever, which is right for a handler with no accept
    /// loop to lose ([`NullServer`]).
    async fn stopped(&self) {
        std::future::pending().await
    }

    /// Get the port on which the HTTP server is listening
    fn port(&self) -> u16;

    /// Register a workload
    async fn on_workload_resolved(
        &self,
        resolved_handle: &ResolvedWorkload,
        component_id: &str,
    ) -> anyhow::Result<()>;
    /// Unregister a workload. Called once for every workload that stops,
    /// including one that never registered here, so an unknown id is not an
    /// error. A start that fails or is cancelled calls it too, without knowing
    /// how far registration got, and holds the workload's id until it succeeds:
    /// an error here is retried rather than skipped.
    async fn on_workload_unbind(&self, workload_id: &str) -> anyhow::Result<()>;

    /// Register a long-lived service instance that serves HTTP ingress: inbound
    /// requests for `workload_id` are delivered over `sender` instead of
    /// instantiating a component per request. `routes` are the ingress routes
    /// the service serves, forwarded to the router so a hostname-keyed router
    /// can resolve requests to this workload. Default: no-op (the workload keeps
    /// the per-request path).
    async fn on_service_http_resolved(
        &self,
        _workload_id: &str,
        _routes: &[IngressRoute],
        _sender: tokio::sync::mpsc::Sender<ServiceHttpJob>,
    ) -> anyhow::Result<()> {
        Ok(())
    }
    /// Unregister a service HTTP instance. As with
    /// [`HostHandler::on_workload_unbind`], an unknown id is not an error.
    /// Default: no-op.
    async fn on_service_http_unbind(&self, _workload_id: &str) -> anyhow::Result<()> {
        Ok(())
    }

    /// Register a long-lived trigger service instance that handles inbound messages:
    /// messages for `workload_id` are delivered over `sender` instead of
    /// instantiating a component per message. Default: no-op.
    async fn on_trigger_service_messaging_resolved(
        &self,
        _workload_id: &str,
        _sender: tokio::sync::mpsc::Sender<MessagingJob>,
    ) -> anyhow::Result<()> {
        Ok(())
    }
    /// Unregister a trigger service messaging instance. As with
    /// [`HostHandler::on_workload_unbind`], an unknown id is not an error.
    /// Default: no-op.
    async fn on_trigger_service_messaging_unbind(&self, _workload_id: &str) -> anyhow::Result<()> {
        Ok(())
    }
    /// Deliver a message to a workload's registered messaging trigger service, returning
    /// the handler's `result<_, string>`. `attributes` is what the delivery is
    /// measured under, built by the backend — the layer that knows which
    /// messaging plugin drove it. Default: no messaging support.
    async fn deliver_trigger_service_message(
        &self,
        _workload_id: &str,
        _msg: BrokerMessage,
        _attributes: std::sync::Arc<[opentelemetry::KeyValue]>,
    ) -> anyhow::Result<Result<(), String>> {
        anyhow::bail!("this host does not support trigger service messaging delivery")
    }
    /// Whether a long-lived trigger service is registered to handle messages for
    /// `workload_id` (so a host ingress can deliver to it instead of
    /// instantiating per message). Default: false.
    async fn has_trigger_service_messaging(&self, _workload_id: &str) -> bool {
        false
    }

    /// Handle an outgoing HTTP request from a workload, enforcing its
    /// `allowed_hosts`. `fut` is as described on
    /// [`OutgoingHandler::send_request`].
    fn outgoing_request(
        &self,
        workload_id: &str,
        request: hyper::Request<WasiBody>,
        options: Option<RequestOptions>,
        fut: RequestIoFuture,
        allowed_hosts: &[AllowedHost],
    ) -> SendFuture;
}

impl std::fmt::Debug for dyn HostHandler {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("HostHandler").finish()
    }
}

#[derive(Default)]
pub struct NullServer {}

#[async_trait::async_trait]
impl HostHandler for NullServer {
    async fn start(&self) -> anyhow::Result<()> {
        Ok(())
    }

    async fn stop(&self) -> anyhow::Result<()> {
        Ok(())
    }

    fn port(&self) -> u16 {
        0
    }

    async fn on_workload_resolved(
        &self,
        _resolved_handle: &ResolvedWorkload,
        _component_id: &str,
    ) -> anyhow::Result<()> {
        Ok(())
    }

    async fn on_workload_unbind(&self, _workload_id: &str) -> anyhow::Result<()> {
        Ok(())
    }

    fn outgoing_request(
        &self,
        _workload_id: &str,
        _request: hyper::Request<WasiBody>,
        _options: Option<RequestOptions>,
        _fut: RequestIoFuture,
        _allowed_hosts: &[AllowedHost],
    ) -> SendFuture {
        Box::new(async {
            Err(wasmtime_wasi_http::Error::InternalError(Some(
                "http client not available".to_string(),
            )))
        })
    }
}

/// An HTTP response body that keeps its dispatched call condemned-on-drop while
/// it streams: dropped mid-stream (the client disconnected), the wrapped
/// [`AbandonOnDrop`] abandons the call; ended cleanly, it disarms. Extends the
/// deadline enforcement of [`DispatchedCall::await_head`] across the body phase,
/// so a guest that produces a response head and then wedges mid-body is still
/// reachable.
struct WatchedBody<B> {
    inner: B,
    /// `None` once end-of-stream disarmed it.
    watch: Option<AbandonOnDrop>,
}

impl<B: hyper::body::Body + Unpin> hyper::body::Body for WatchedBody<B> {
    type Data = B::Data;
    type Error = B::Error;

    fn poll_frame(
        self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Result<hyper::body::Frame<Self::Data>, Self::Error>>> {
        let this = self.get_mut();
        let poll = std::pin::Pin::new(&mut this.inner).poll_frame(cx);
        // Clean end of stream: the response was delivered whole, so nothing is
        // abandoned. An *error* frame deliberately does not disarm — the
        // exchange broke off, and if the guest is wedged behind it, the armed
        // flag is what ends it (a completed call deregisters, so arming a
        // healthy one is harmless).
        // `is_end_stream` too, since hyper stops polling once a declared
        // `content-length` is written and never delivers that final `None`.
        let ended = matches!(poll, std::task::Poll::Ready(None)) || this.inner.is_end_stream();
        if ended && let Some(watch) = this.watch.take() {
            watch.disarm();
        }
        poll
    }

    // Forwarded, not defaulted: hyper frames the response from these, so
    // defaulting them sends a fixed-length body chunked and close-delimits a
    // HEAD or 204/304 that would otherwise keep its connection alive.
    fn is_end_stream(&self) -> bool {
        self.inner.is_end_stream()
    }

    fn size_hint(&self) -> hyper::body::SizeHint {
        self.inner.size_hint()
    }
}

/// Wrap `resp`'s body so the dispatched call behind it stays condemned-on-drop
/// until the body finishes streaming.
///
/// An already-complete body is left unwrapped and disarmed: hyper never polls
/// one, so a wrapper would be dropped un-disarmed and arm the flag on a
/// response that was delivered whole.
fn watch_body(resp: hyper::Response<WasiBody>, watch: AbandonOnDrop) -> hyper::Response<WasiBody> {
    if hyper::body::Body::is_end_stream(resp.body()) {
        watch.disarm();
        return resp;
    }
    resp.map(|inner| {
        WatchedBody {
            inner,
            watch: Some(watch),
        }
        .boxed_unsync()
    })
}

/// A map from workload id to the component serving its HTTP requests.
pub type WorkloadHandles = Arc<RwLock<HashMap<String, Arc<ComponentHandle>>>>;

/// What serving a request on a workload's HTTP component needs, settled when
/// the component is bound so a request only reads it: the pre-linked
/// component, the identity its calls are measured under, which `wasi:http`
/// it speaks and the warm set it runs on. Behind an `Arc` in
/// [`WorkloadHandles`], so a request takes it with one reference count.
pub struct ComponentHandle {
    workload: ResolvedWorkload,
    instance_pre: InstancePre<SharedCtx>,
    component_id: String,
    identity: crate::observability::WorkloadIdentity,
    /// Whether the component targets `wasi:http@0.3`, which walks its imports
    /// and exports to answer.
    targets_p3: bool,
    /// The warm set its calls run on, if it keeps one. See
    /// [`crate::engine::instance_pool::poolable`].
    pool: Option<Arc<crate::engine::instance_pool::InstancePool>>,
}

/// An inbound HTTP request routed to a long-lived service instance, paired with
/// a oneshot for its response and the abandonment flag of the [`DispatchedCall`]
/// enforcing its deadline (see [`crate::engine::abandon`]).
///
/// The request body is pre-boxed into [`WasiBody`] so both real network
/// ingress (`hyper::body::Incoming`, boxed in [`handle_http_request`]) and
/// locally short-circuited outgoing requests (see
/// [`IngressBuilder::local_routing`]) can be delivered on the same channel.
pub struct ServiceHttpJob {
    pub req: hyper::Request<WasiBody>,
    pub resp_tx: tokio::sync::oneshot::Sender<anyhow::Result<hyper::Response<WasiBody>>>,
    pub abandoned: Arc<AbandonFlag>,
}

/// The attribute set an inbound HTTP call is measured under: the shared scheme
/// plus the request method, which is bounded by the HTTP spec. The URI and Host
/// header are deliberately absent — a caller invents those, and a label a
/// caller can invent mints a permanent time series per distinct value.
pub(crate) fn http_attributes(
    identity: &crate::observability::WorkloadIdentity,
    method: &hyper::Method,
    operation: &'static str,
) -> Arc<[opentelemetry::KeyValue]> {
    identity.attributes_with(
        "wasi-http",
        operation,
        opentelemetry::KeyValue::new(HTTP_REQUEST_METHOD, known_method(method)),
    )
}

/// What a call on an already-built store is measured under, taken from the
/// store rather than from whoever dispatched to it.
///
/// A service's HTTP ingress has no workload handle to resolve an identity from
/// — `workload_handles` holds only components that export `wasi:http` — and it
/// does not need one: the store it runs on was stamped when it was built.
///
/// Empty when nothing is measuring this store, which is one lookup: the store
/// is stamped only by a host that meters, so an absent stamp answers both
/// "whose is this" and "is anyone recording it". Building it regardless would
/// cost a `Vec`, an `Arc` and four `String`s per request for a value that is
/// dropped.
pub(crate) fn stored_http_attributes(
    executed: &crate::engine::abandon::GuestExecution,
    method: &hyper::Method,
) -> Arc<[opentelemetry::KeyValue]> {
    let Some(identity) = executed.identity() else {
        return Arc::from([]);
    };
    identity.attributes_with(
        "wasi-http",
        HTTP_OPERATION_P3,
        opentelemetry::KeyValue::new(HTTP_REQUEST_METHOD, known_method(method)),
    )
}

/// The request method, or `_OTHER` for anything outside the registered set.
///
/// `hyper::Method` accepts an arbitrary extension token, so the method a client
/// sends is caller-invented like the URI is. Folding the unregistered ones into
/// one bucket is what keeps it usable as an attribute; the exact token stays on
/// the span. This is the treatment the OTel HTTP semconv prescribes, and it is
/// recorded under the semconv's own key — the same `http.request.method` the
/// spans here carry, so a histogram and a trace join on it without a relabel,
/// and so `_OTHER` means what a reader of that convention expects.
fn known_method(method: &hyper::Method) -> &'static str {
    match *method {
        hyper::Method::GET => "GET",
        hyper::Method::HEAD => "HEAD",
        hyper::Method::POST => "POST",
        hyper::Method::PUT => "PUT",
        hyper::Method::DELETE => "DELETE",
        hyper::Method::CONNECT => "CONNECT",
        hyper::Method::OPTIONS => "OPTIONS",
        hyper::Method::TRACE => "TRACE",
        hyper::Method::PATCH => "PATCH",
        _ => "_OTHER",
    }
}

/// The WIT exports an inbound request can invoke, and what its measurements
/// are grouped by. Bounded by the interface, unlike the request's URI.
///
/// Two of them, because the p2 per-request path and the p3 pooled path call
/// different exports; merging them would group calls under an export one of the
/// two never invokes.
pub(crate) const HTTP_OPERATION_P2: &str = "wasi:http/incoming-handler#handle";
pub(crate) const HTTP_OPERATION_P3: &str = "wasi:http/handler#handle";

/// A map from workload id to the channel of its HTTP-serving service instance.
/// Empty unless a workload's service opts into HTTP ingress (a p3 feature).
pub type ServiceHandlers = Arc<RwLock<HashMap<String, tokio::sync::mpsc::Sender<ServiceHttpJob>>>>;

/// A map from workload id to the channel of a trigger service's messaging handler
/// instance. Empty unless a workload's service exports a messaging handler.
pub type MessagingHandlers = Arc<RwLock<HashMap<String, tokio::sync::mpsc::Sender<MessagingJob>>>>;

/// The host's HTTP ingress: it owns the listening socket and routes each
/// inbound request to a workload by virtual host — either to a per-request
/// `wasi:http/incoming-handler` instance or, when the workload runs a
/// long-lived trigger service, to that service's live instance. HTTP and HTTPS
/// are both supported, with optional mutual TLS.
///
/// It also holds the registries through which other host-side ingresses reach a
/// trigger service's live instance: [`deliver_trigger_service_message`] hands a
/// message received by a messaging plugin to that workload's
/// `wasmcloud:messaging/handler` on the same instance.
///
/// Use [`IngressBuilder`] to construct an instance:
///
/// ```rust,ignore
/// let ingress = Ingress::builder(router, "127.0.0.1:8080".parse()?)
///     .outgoing_handler(my_handler)
///     .tls(TlsConfig::new(cert_path, key_path))
///     .build()
///     .await?;
/// ```
///
/// [`deliver_trigger_service_message`]: HostHandler::deliver_trigger_service_message
pub struct Ingress<T: Router, O: OutgoingHandler = DefaultOutgoingHandler> {
    router: Arc<T>,
    outgoing_handler: O,
    addr: SocketAddr,
    workload_handles: WorkloadHandles,
    /// Workloads whose long-lived service serves HTTP ingress directly.
    service_handlers: ServiceHandlers,
    /// Workloads whose long-lived trigger service serves messaging ingress directly.
    messaging_handlers: MessagingHandlers,
    shutdown_tx: Arc<RwLock<Option<mpsc::Sender<()>>>>,
    tls_acceptor: Option<TlsAcceptor>,
    listener: Arc<tokio::sync::Mutex<Option<TcpListener>>>,
    /// Ceiling on the TCP connections this ingress holds at once, and the
    /// permits enforcing it. Sized from the process's descriptor budget unless
    /// the operator names a number: see
    /// [`crate::host::quota::default_max_http_ingress_connections`].
    connections: ConnectionLimit,
    meters: RwLock<Meters>,
    /// h2 (ALPN) variant of the outgoing handler's client TLS configuration,
    /// derived once on the first gRPC request; see [`Ingress::grpc_tls`].
    grpc_tls: OnceLock<Arc<rustls::ClientConfig>>,
    /// Same-host local routing: when enabled, outgoing requests whose
    /// authority matches a hostname this ingress serves are dispatched
    /// in-memory to the co-located workload instead of egressing to the
    /// network. Off by default.
    local_routing: bool,
    /// Where a locally dispatched call draws its outbound allowance from, so a
    /// workload's in-memory fan-out is bounded by the same number as its
    /// network fan-out. Always present: an ingress the builder was given no
    /// registry for gets one on the default limits, because an unbounded local
    /// path is also an unbounded cycle (see [`Self::take_local_slot`]).
    quotas: Arc<crate::host::quota::QuotaRegistry>,
}

impl<T: Router, O: OutgoingHandler> std::fmt::Debug for Ingress<T, O> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Ingress").field("addr", &self.addr).finish()
    }
}

/// TLS configuration for [`IngressBuilder::tls`] / [`Ingress::new_with_tls`].
#[derive(Debug, Clone)]
pub struct TlsConfig {
    cert_path: std::path::PathBuf,
    key_path: std::path::PathBuf,
    ca_path: Option<std::path::PathBuf>,
}

impl TlsConfig {
    pub fn new(
        cert_path: impl Into<std::path::PathBuf>,
        key_path: impl Into<std::path::PathBuf>,
    ) -> Self {
        Self {
            cert_path: cert_path.into(),
            key_path: key_path.into(),
            ca_path: None,
        }
    }

    pub fn with_ca(mut self, ca_path: impl Into<std::path::PathBuf>) -> Self {
        self.ca_path = Some(ca_path.into());
        self
    }
}

/// Builder for [`Ingress`].
///
/// # Required
/// - `router` and `addr` — set via [`Ingress::builder`].
///
/// # Optional
/// - [`outgoing_handler`](Self::outgoing_handler) — defaults to [`DefaultOutgoingHandler`].
/// - [`tls`](Self::tls) — enables HTTPS.
/// - [`local_routing`](Self::local_routing) — serve outgoing requests to
///   co-located workloads in-memory. Off by default.
///
/// # Example
/// ```rust,ignore
/// // Minimal — plain HTTP, default outgoing handler
/// let ingress = Ingress::builder(DevRouter::default(), addr)
///     .build()
///     .await?;
///
/// // Full — HTTPS with custom egress
/// let ingress = Ingress::builder(DynamicRouter::default(), addr)
///     .outgoing_handler(custom_handler)
///     .tls(TlsConfig::new(cert, key).with_ca(ca))
///     .build()
///     .await?;
/// ```
pub struct IngressBuilder<T: Router, O: OutgoingHandler = DefaultOutgoingHandler> {
    router: T,
    outgoing_handler: O,
    addr: SocketAddr,
    tls: Option<TlsConfig>,
    max_connections: Option<usize>,
    local_routing: bool,
    quotas: Option<Arc<crate::host::quota::QuotaRegistry>>,
}

impl<T: Router> IngressBuilder<T, DefaultOutgoingHandler> {
    fn new(router: T, addr: SocketAddr) -> Self {
        Self {
            router,
            outgoing_handler: DefaultOutgoingHandler::default(),
            addr,
            tls: None,
            max_connections: None,
            local_routing: false,
            quotas: None,
        }
    }
}

impl<T: Router, O: OutgoingHandler> IngressBuilder<T, O> {
    /// Set a custom [`OutgoingHandler`], changing the builder's handler type.
    /// The same handler serves both P2 and P3 outgoing requests.
    pub fn outgoing_handler<O2: OutgoingHandler>(self, handler: O2) -> IngressBuilder<T, O2> {
        IngressBuilder {
            router: self.router,
            outgoing_handler: handler,
            addr: self.addr,
            tls: self.tls,
            max_connections: self.max_connections,
            local_routing: self.local_routing,
            quotas: self.quotas,
        }
    }

    /// Enable TLS using the given [`TlsConfig`].
    pub fn tls(mut self, tls: TlsConfig) -> Self {
        self.tls = Some(tls);
        self
    }

    /// Cap the TCP connections this ingress holds at once, in place of the
    /// ceiling derived from the process's descriptor budget.
    pub fn max_connections(mut self, max: usize) -> Self {
        self.max_connections = Some(max.clamp(1, Semaphore::MAX_PERMITS));
        self
    }

    /// Enable same-host local routing: outgoing requests matching a
    /// [`RouteScope::Local`] route — a co-located workload's `localRoute`
    /// interface config, either `host` or `host/path` — are dispatched to that
    /// workload in-memory instead of egressing to the network.
    ///
    /// This is one of two keys. The host enabling it does not make any workload
    /// locally reachable; a workload declaring `localRoute` does nothing unless
    /// the host enables it here. Names published only via `host`/`host-aliases`
    /// are never short-circuited.
    ///
    /// # Security
    ///
    /// A `localRoute` is a claim, not a proof of ownership. Any workload on this
    /// host may claim any hostname — including a public one it has nothing to do
    /// with — and will then receive its neighbours' requests to that name. Two
    /// workloads claiming the same name share one bucket and split the traffic
    /// at random. Dispatch is in-memory, so there is no TLS: an `https://`
    /// request to a claimed name is handed over in plaintext with the
    /// certificate never checked, and the caller's `allowed_hosts` does not
    /// help, because the caller legitimately lists the name it means to reach.
    ///
    /// Enable only where every workload on the host is equally trusted. Locally
    /// routed calls also bypass anything on the network path (ingress
    /// middleware, mesh mTLS, NetworkPolicy); `allowed_hosts` is still enforced
    /// first. Off by default.
    pub fn local_routing(mut self, enabled: bool) -> Self {
        self.local_routing = enabled;
        self
    }

    /// Draw locally routed calls on `quotas`, so a workload's in-memory
    /// fan-out is bounded by the same per-workload allowance an operator set
    /// for its network egress.
    ///
    /// Pass the host's one registry — the same one given to
    /// [`DefaultOutgoingHandler::with_quotas`] — or local dispatch and pooled
    /// HTTP will each enforce a private ceiling. Without it, local dispatch
    /// falls back to a registry of its own on the default limits: the ceiling
    /// is then unrelated to the one an operator set for network egress, but it
    /// exists, which is what keeps a cycle of locally routed calls from
    /// growing without bound (see [`Ingress::take_local_slot`]).
    #[must_use]
    pub fn quotas(mut self, quotas: Arc<crate::host::quota::QuotaRegistry>) -> Self {
        self.quotas = Some(quotas);
        self
    }

    /// Bind to the address and build the [`Ingress`].
    pub async fn build(self) -> anyhow::Result<Ingress<T, O>> {
        crate::init_crypto();
        let tls_acceptor = match &self.tls {
            Some(tls) => {
                let config =
                    load_tls_config(&tls.cert_path, &tls.key_path, tls.ca_path.as_deref()).await?;
                Some(TlsAcceptor::from(Arc::new(config)))
            }
            None => None,
        };

        let listener = TcpListener::bind(self.addr).await?;
        let addr = listener.local_addr()?;
        let max_connections = self
            .max_connections
            .unwrap_or_else(crate::host::quota::default_max_http_ingress_connections);

        Ok(Ingress {
            router: Arc::new(self.router),
            outgoing_handler: self.outgoing_handler,
            addr,
            workload_handles: Arc::default(),
            service_handlers: Arc::default(),
            messaging_handlers: Arc::default(),
            shutdown_tx: Arc::new(RwLock::new(None)),
            tls_acceptor,
            listener: Arc::new(tokio::sync::Mutex::new(Some(listener))),
            connections: ConnectionLimit::new(max_connections),
            meters: RwLock::new(Meters::new(MeterKind::Off)),
            grpc_tls: OnceLock::new(),
            local_routing: self.local_routing,
            // Always a registry: see `take_local_slot` for why an unbounded
            // local-dispatch path is not an option.
            quotas: self.quotas.unwrap_or_else(|| {
                crate::host::quota::QuotaRegistry::new(Default::default(), None)
            }),
        })
    }
}

impl<T: Router> Ingress<T, DefaultOutgoingHandler> {
    /// Returns a new [`IngressBuilder`] with the default [`DefaultOutgoingHandler`].
    pub fn builder(router: T, addr: SocketAddr) -> IngressBuilder<T, DefaultOutgoingHandler> {
        IngressBuilder::new(router, addr)
    }

    /// Creates a new ingress listening on `addr` with the default outgoing handler.
    pub async fn new(router: T, addr: SocketAddr) -> anyhow::Result<Self> {
        IngressBuilder::new(router, addr).build().await
    }

    /// Creates a new ingress listening on `addr` over TLS, with the default
    /// outgoing handler.
    pub async fn new_with_tls(router: T, addr: SocketAddr, tls: TlsConfig) -> anyhow::Result<Self> {
        IngressBuilder::new(router, addr).tls(tls).build().await
    }
}

impl<T: Router, O: OutgoingHandler> Ingress<T, O> {
    /// Empty the routing tables once this ingress has drained, so a host that
    /// is stopped but still held lets go of the workloads it routed. Detached
    /// because a drain outlasts this call, bounded by
    /// [`crate::timeouts::ingress_drain`] because it may never finish, and
    /// holding the tables rather than the ingress so it pins neither.
    fn release_when_drained(&self) {
        let connections = self.connections.clone();
        let workload_handles = Arc::clone(&self.workload_handles);
        let service_handlers = Arc::clone(&self.service_handlers);
        let messaging_handlers = Arc::clone(&self.messaging_handlers);
        let addr = self.addr;
        tokio::spawn(async move {
            let budget = crate::timeouts::ingress_drain();
            if tokio::time::timeout(budget, connections.drained())
                .await
                .is_err()
            {
                warn!(
                    addr = ?addr,
                    budget_secs = budget.as_secs(),
                    "ingress still had connections at the end of its drain; \
                     releasing its routes anyway"
                );
            }
            workload_handles.write().await.clear();
            service_handlers.write().await.clear();
            messaging_handlers.write().await.clear();
        });
    }

    /// How many workloads this ingress can currently route an inbound message
    /// or request to. Zero once [`HostHandler::stop`] has drained, and what an
    /// embedder without a probe listener can report about routing state.
    ///
    /// All three tables, because a workload reaches routing by more than one
    /// door: a service-only workload registers through
    /// [`HostHandler::on_service_http_resolved`] and never appears among the
    /// component handles.
    pub async fn routed_workloads(&self) -> usize {
        self.workload_handles.read().await.len()
            + self.service_handlers.read().await.len()
            + self.messaging_handlers.read().await.len()
    }

    /// Returns the actual bound address (useful when binding to port 0).
    pub fn addr(&self) -> SocketAddr {
        self.addr
    }

    /// This ingress's connection ceiling, to register with the probe listener
    /// as a reason the host may be not-ready.
    pub fn connection_limit(&self) -> ConnectionLimit {
        self.connections.clone()
    }

    /// The h2 (ALPN) variant of the outgoing handler's client TLS
    /// configuration, used by the gRPC egress fast path. Derived once on the
    /// first gRPC request so the per-request `ClientConfig` clone is avoided
    /// on both the P2 and P3 paths.
    fn grpc_tls(&self) -> Arc<rustls::ClientConfig> {
        self.grpc_tls
            .get_or_init(|| {
                let base = self
                    .outgoing_handler
                    .client_tls_config()
                    .unwrap_or_else(crate::host::http_client::default_client_tls_config);
                h2_client_config(&base)
            })
            .clone()
    }

    /// The guest meter for locally dispatched requests, the same one the
    /// network ingress path hands to `handle_http_request`. Meters are injected
    /// once at host startup, so `try_read` only contends during that injection;
    /// fall back to the default (no-op) meter rather than blocking a sync
    /// caller.
    fn local_guest_meter(&self) -> GuestMeter {
        self.meters
            .try_read()
            .map(|m| m.guest())
            .unwrap_or_default()
    }

    /// Take an outbound slot from `caller`'s allowance for a locally routed
    /// call, so its in-memory fan-out is bounded by the same number as its
    /// network fan-out.
    ///
    /// `Err(())` when the caller is at its ceiling; the call is refused rather
    /// than queued (see
    /// [`crate::host::quota::GuestConnectionQuota::try_acquire_outbound_http`]).
    ///
    /// This is also what bounds a cycle. Local routing has no per-chain hop
    /// counter — the guest builds its outgoing request itself, so nothing the
    /// host attaches to one request survives into the next — and a cycle such
    /// as `A -> B -> A` is, from here, each workload calling out again before
    /// its previous call has returned. Every hop holds its caller's slot until
    /// the response body drains, which in a cycle is never, so both workloads
    /// reach their ceiling within `outbound_http` hops and the innermost call
    /// is refused; the refusal then unwinds the whole chain instead of it
    /// growing until something upstream times out.
    ///
    /// The slot is therefore taken from a registry that always exists: an
    /// ingress built without [`IngressBuilder::quotas`] falls back to the
    /// default limits rather than dispatching unbounded, because "no registry
    /// configured" must not mean "no bound on recursion".
    fn take_local_slot(&self, caller: &str) -> Result<crate::host::quota::ConnectionSlot, ()> {
        self.quotas
            .for_guest(caller)
            .try_acquire_outbound_http()
            .ok_or(())
    }

    /// The destination a locally routed request would be dispatched to, taken
    /// out of the handler maps at the moment the route is chosen — the
    /// long-lived service instance when one is registered, else the registered
    /// component handle, the same priority order the inbound path uses.
    ///
    /// Resolved *before* committing to the local route, because a route is
    /// registered earlier than the handle it needs. `on_workload_resolved`
    /// registers routes, then awaits `instantiate_pre`, then inserts the handle
    /// — and only for a component that exports `wasi:http`. So a workload can
    /// be briefly unready during start, and permanently unready if it declared
    /// a `localRoute` without exporting the handler. Neither should turn a
    /// caller's request into an error when the network was there all along.
    ///
    /// Returning the destination rather than a yes/no answer is what keeps the
    /// two halves from disagreeing: a workload can be unbound between a check
    /// and the dispatch that trusted it, and by then the request body has been
    /// handed over and there is no going back to the network. Resolving once
    /// means the destination that was validated is the destination that is
    /// used.
    ///
    /// Shutdown is safe in the other direction too. `on_workload_unbind`
    /// removes the routes before the handle goes, so a stopping workload stops
    /// being *matched* first and its callers egress as they did before it
    /// existed; a handle still present under a withdrawn route is simply never
    /// reached from here.
    ///
    /// `try_read`, not `read`: this runs on the sync egress path. The maps are
    /// written only on workload start/stop, so contention is rare; treating it
    /// as "not resolvable" costs one request the short-circuit and never
    /// correctness.
    fn resolve_local_target(&self, target: &str) -> Option<LocalTarget> {
        if let Ok(handlers) = self.service_handlers.try_read()
            && let Some(sender) = handlers.get(target)
        {
            // A stopped service not yet unregistered would take the request body
            // and then fail the send; skip it while the body can still egress.
            return (!sender.is_closed()).then(|| LocalTarget::Service(sender.clone()));
        }
        let handles = self.workload_handles.try_read().ok()?;
        handles.get(target).cloned().map(LocalTarget::Component)
    }

    /// The co-located workload to serve `uri` in-memory and where to dispatch
    /// it, or `None` to egress. Only replicas that can serve now are candidates,
    /// and each destination is resolved once so the one checked is the one used.
    fn local_destination(
        &self,
        workload_id: &str,
        uri: &hyper::Uri,
    ) -> Option<(String, LocalTarget)> {
        if !self.local_routing {
            return None;
        }
        let mut matched = false;
        let mut resolved = None;
        let target = self.router.route_local_egress(uri, &mut |id| {
            matched = true;
            match self.resolve_local_target(id) {
                Some(destination) => {
                    resolved = Some((id.to_string(), destination));
                    true
                }
                None => false,
            }
        });
        let Some(target) = target else {
            if matched {
                debug!(workload_id, uri = %uri, "co-located workload matched but cannot serve yet; egressing instead");
            }
            return None;
        };
        // A router that picked without consulting `can_serve` is resolved here.
        match resolved {
            Some((id, destination)) if id == target => Some((target, destination)),
            _ => self
                .resolve_local_target(&target)
                .map(|destination| (target, destination)),
        }
    }

    /// Serve an outgoing request by dispatching it to co-located workload
    /// `target`'s incoming HTTP path in-memory (see
    /// [`IngressBuilder::local_routing`]).
    fn send_local_request(
        &self,
        caller: &str,
        target: String,
        destination: LocalTarget,
        request: hyper::Request<WasiBody>,
        options: Option<RequestOptions>,
    ) -> SendFuture {
        let guest_meter = self.local_guest_meter();
        let slot = self.take_local_slot(caller);
        Box::new(async move {
            let Ok(slot) = slot else {
                return Err(wasmtime_wasi_http::Error::ConnectionLimitReached);
            };
            let first_byte_timeout = options
                .and_then(|o| o.first_byte_timeout)
                .unwrap_or(Duration::from_secs(600));
            let between_bytes_timeout = options
                .and_then(|o| o.between_bytes_timeout)
                .unwrap_or(Duration::from_secs(600));
            // The probe reports the request body's outcome back to the caller,
            // as the network path does.
            let (parts, body) = request.into_parts();
            let (body, upload) = crate::host::http_client::UploadProbe::new(body);
            let local = LocalRequest::new(slot, body);
            let settle = Settle(Some(local.clone()));
            let body = DrainOnDrop::new(local.clone());
            let request = hyper::Request::from_parts(parts, body.boxed_unsync());
            let dispatched = tokio::time::timeout(
                first_byte_timeout,
                dispatch_local(&target, request, destination, guest_meter),
            )
            .await;
            settle.answered(matches!(dispatched, Ok(Ok(_))));
            let response = dispatched
                .map_err(|_| wasmtime_wasi_http::Error::ConnectionReadTimeout)?
                .map_err(|e| {
                    error!(err = ?e, workload_id = %target, "local dispatch failed");
                    wasmtime_wasi_http::Error::InternalError(Some(format!(
                        "local dispatch failed: {e}"
                    )))
                })?;
            // The slot is held until the body drains, and
            // `between_bytes_timeout` is applied here because the body goes
            // straight back to the guest.
            let response = attach_slot(response, local)
                .map(|body| TimedBody::new(body, between_bytes_timeout).boxed_unsync());
            Ok((response, crate::host::http_client::upload_io(upload)))
        })
    }
}

/// Derive the h2 (ALPN) variant of a client TLS configuration for gRPC egress.
fn h2_client_config(base: &rustls::ClientConfig) -> Arc<rustls::ClientConfig> {
    let mut config = base.clone();
    config.alpn_protocols = vec![b"h2".to_vec()];
    Arc::new(config)
}

/// Response body that holds a quota slot until the response is fully drained.
///
/// A network request occupies its connection until the body is done, so a
/// locally routed one has to hold its slot just as long — releasing at the
/// response head would let a workload keep unbounded bodies streaming while the
/// quota read as idle.
struct SlotBody {
    inner: WasiBody,
    _request: LocalRequest,
}

impl hyper::body::Body for SlotBody {
    type Data = bytes::Bytes;
    type Error = wasmtime_wasi_http::Error;

    fn poll_frame(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Result<hyper::body::Frame<Self::Data>, Self::Error>>> {
        std::pin::Pin::new(&mut self.inner).poll_frame(cx)
    }

    fn is_end_stream(&self) -> bool {
        self.inner.is_end_stream()
    }

    fn size_hint(&self) -> hyper::body::SizeHint {
        self.inner.size_hint()
    }
}

/// Hold the local request's slot until the response body is drained.
fn attach_slot(
    resp: hyper::Response<WasiBody>,
    request: LocalRequest,
) -> hyper::Response<WasiBody> {
    resp.map(|inner| {
        WasiBody::new(SlotBody {
            inner,
            _request: request,
        })
    })
}

/// Share a local upload and its quota slot with the response and upload drain.
/// Failure closes the upload and returns the slot even if the request is queued.
#[derive(Clone)]
struct LocalRequest(Arc<std::sync::Mutex<LocalRequestInner>>);

struct LocalRequestInner {
    slot: Option<crate::host::quota::ConnectionSlot>,
    body: LocalUpload,
    waker: Option<std::task::Waker>,
}

enum LocalUpload {
    Open(crate::host::http_client::UploadProbe),
    Done,
    Closed,
}

impl LocalRequest {
    fn new(
        slot: crate::host::quota::ConnectionSlot,
        body: crate::host::http_client::UploadProbe,
    ) -> Self {
        Self(Arc::new(std::sync::Mutex::new(LocalRequestInner {
            slot: Some(slot),
            body: LocalUpload::Open(body),
            waker: None,
        })))
    }

    fn fail(&self) {
        let (body, slot, waker) = {
            let mut request = self.0.lock().unwrap_or_else(|e| e.into_inner());
            let body = if matches!(request.body, LocalUpload::Open(_)) {
                Some(std::mem::replace(&mut request.body, LocalUpload::Closed))
            } else {
                None
            };
            (body, request.slot.take(), request.waker.take())
        };
        drop(body);
        drop(slot);
        if let Some(waker) = waker {
            waker.wake();
        }
    }

    /// Release the upload while the response still holds its quota slot.
    fn finish_upload(&self) {
        let finished = {
            let mut request = self.0.lock().unwrap_or_else(|e| e.into_inner());
            (
                std::mem::replace(&mut request.body, LocalUpload::Done),
                request.waker.take(),
            )
        };
        drop(finished);
    }

    /// Whether a dropped upload still has frames to drain. If not, the upload is
    /// released now, including one closed by a failed dispatch.
    fn needs_drain(&self) -> bool {
        let finished = {
            let mut request = self.0.lock().unwrap_or_else(|e| e.into_inner());
            if let LocalUpload::Open(body) = &request.body
                && !hyper::body::Body::is_end_stream(body)
            {
                return true;
            }
            (
                std::mem::replace(&mut request.body, LocalUpload::Done),
                request.waker.take(),
            )
        };
        drop(finished);
        false
    }

    /// Read the upload's next frame. Only [`DrainOnDrop`] and its drain task
    /// read, since a pending read keeps a single waker.
    fn poll_frame(
        &self,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Result<hyper::body::Frame<bytes::Bytes>, wasmtime_wasi_http::Error>>>
    {
        let mut request = self.0.lock().unwrap_or_else(|e| e.into_inner());
        let polled = match &mut request.body {
            LocalUpload::Open(inner) => {
                hyper::body::Body::poll_frame(std::pin::Pin::new(inner), cx)
            }
            LocalUpload::Done => return std::task::Poll::Ready(None),
            LocalUpload::Closed => {
                request.body = LocalUpload::Done;
                return std::task::Poll::Ready(Some(Err(
                    wasmtime_wasi_http::Error::ConnectionTerminated,
                )));
            }
        };
        let finished = match &polled {
            std::task::Poll::Pending => {
                // The lock makes registering a pending reader atomic with failure.
                if request
                    .waker
                    .as_ref()
                    .is_none_or(|w| !w.will_wake(cx.waker()))
                {
                    request.waker = Some(cx.waker().clone());
                }
                None
            }
            std::task::Poll::Ready(frame) => {
                request.waker = None;
                if matches!(frame, None | Some(Err(_))) {
                    Some(std::mem::replace(&mut request.body, LocalUpload::Done))
                } else {
                    None
                }
            }
        };
        drop(request);
        drop(finished);
        polled
    }

    fn is_end_stream(&self) -> bool {
        match &self.0.lock().unwrap_or_else(|e| e.into_inner()).body {
            LocalUpload::Open(body) => hyper::body::Body::is_end_stream(body),
            LocalUpload::Done => true,
            LocalUpload::Closed => false,
        }
    }

    fn size_hint(&self) -> hyper::body::SizeHint {
        match &self.0.lock().unwrap_or_else(|e| e.into_inner()).body {
            LocalUpload::Open(body) => hyper::body::Body::size_hint(body),
            LocalUpload::Done => hyper::body::SizeHint::with_exact(0),
            LocalUpload::Closed => hyper::body::SizeHint::default(),
        }
    }
}

/// A successful dispatch keeps its upload and slot. Failure or cancellation
/// closes the upload and releases the slot, even if the request is queued.
struct Settle(Option<LocalRequest>);

impl Settle {
    fn answered(mut self, answered: bool) {
        if answered {
            self.0.take();
        }
    }
}

impl Drop for Settle {
    fn drop(&mut self) {
        if let Some(request) = self.0.take() {
            request.fail();
        }
    }
}

/// Request body handed to a locally routed callee. A callee dropping it unread
/// would close the caller's upload ("connection reset"), so from the drop on
/// the rest is drained on a task, holding the request's outbound slot. The drain
/// has no timer (the quota bounds open drains). A failed, timed-out or abandoned
/// dispatch closes the upload, and whoever holds the body, whether the callee, a
/// queued job or the drain, reads `ConnectionTerminated` rather than a clean end.
struct DrainOnDrop {
    inner: Option<LocalRequest>,
}

impl DrainOnDrop {
    fn new(inner: LocalRequest) -> Self {
        Self { inner: Some(inner) }
    }
}

impl hyper::body::Body for DrainOnDrop {
    type Data = bytes::Bytes;
    type Error = wasmtime_wasi_http::Error;

    fn poll_frame(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Result<hyper::body::Frame<Self::Data>, Self::Error>>> {
        let Some(inner) = self.inner.as_ref() else {
            return std::task::Poll::Ready(None);
        };
        let polled = inner.poll_frame(cx);
        if matches!(polled, std::task::Poll::Ready(None | Some(Err(_)))) {
            self.inner = None;
        }
        polled
    }

    fn is_end_stream(&self) -> bool {
        self.inner.as_ref().is_none_or(|b| b.is_end_stream())
    }

    fn size_hint(&self) -> hyper::body::SizeHint {
        self.inner
            .as_ref()
            .map_or_else(|| hyper::body::SizeHint::with_exact(0), |b| b.size_hint())
    }
}

impl Drop for DrainOnDrop {
    fn drop(&mut self) {
        let Some(body) = self.inner.take() else {
            return;
        };
        if !body.needs_drain() {
            return;
        }
        let Ok(runtime) = tokio::runtime::Handle::try_current() else {
            body.finish_upload();
            return;
        };
        runtime.spawn(async move {
            while let Some(Ok(_)) = std::future::poll_fn(|cx| body.poll_frame(cx)).await {}
        });
    }
}

/// Where a locally routed request is delivered, resolved out of the handler
/// maps by [`Ingress::resolve_local_target`] before the caller commits to the
/// short-circuit.
enum LocalTarget {
    /// The workload's long-lived service instance, which serves the request on
    /// the instance it already keeps warm.
    Service(tokio::sync::mpsc::Sender<ServiceHttpJob>),
    /// The workload's registered component handle, from which a per-request
    /// instance is built.
    Component(Arc<ComponentHandle>),
}

/// Dispatch a locally routed request to `workload_id` through the destination
/// [`Ingress::resolve_local_target`] already picked for it.
async fn dispatch_local(
    workload_id: &str,
    mut request: hyper::Request<WasiBody>,
    target: LocalTarget,
    guest_meter: GuestMeter,
) -> anyhow::Result<hyper::Response<WasiBody>> {
    // Mirror the wire: a network send would carry the request authority as its
    // `Host` header, and handlers routinely read it.
    if !request.headers().contains_key(hyper::header::HOST)
        && let Some(authority) = request.uri().authority()
        && let Ok(value) = hyper::header::HeaderValue::from_str(authority.as_str())
    {
        request.headers_mut().insert(hyper::header::HOST, value);
    }

    let handle = match target {
        LocalTarget::Service(sender) => {
            let (resp_tx, resp_rx) = tokio::sync::oneshot::channel();
            // The deadline is enforced out here, outside the service's store,
            // for the same reason `handle_http_request` enforces it out here: a
            // guest that never yields blocks every host future on its own
            // store, so only a waiter outside it can abandon the call.
            let call =
                DispatchedCall::new("HTTP (local, service)", crate::timeouts::http_response());
            let job = ServiceHttpJob {
                req: request,
                resp_tx,
                abandoned: call.flag(),
            };
            // The one window `resolve_local_target` cannot close: the service
            // can stop between being resolved and being sent to, and by now the
            // request body has been moved into the job, so there is no
            // falling back to the network with it.
            if sender.send(job).await.is_err() {
                anyhow::bail!("service HTTP instance for workload {workload_id} is not running");
            }
            return match call.await_head(resp_rx).await {
                Some((Ok(resp), watch)) => resp.map(|resp| watch_body(resp, watch)),
                Some((Err(_), _)) => {
                    anyhow::bail!("service HTTP instance dropped the response")
                }
                None => anyhow::bail!("service HTTP instance produced no response"),
            };
        }
        LocalTarget::Component(handle) => handle,
    };
    let req_span = tracing::span!(
        tracing::Level::INFO,
        "invoke_component_handler",
        workload.name = handle.workload.name(),
        workload.namespace = handle.workload.namespace(),
        workload.id = handle.workload.id(),
    );
    invoke_component_handler(&handle, request, guest_meter)
        .instrument(req_span)
        .await
}

#[async_trait::async_trait]
impl<T: Router, O: OutgoingHandler> HostHandler for Ingress<T, O> {
    async fn inject_meters(&self, meters: &crate::observability::Meters) {
        *self.meters.write().await = meters.clone();
    }

    async fn start(&self) -> anyhow::Result<()> {
        let addr = self.addr;
        let (shutdown_tx, mut shutdown_rx) = mpsc::channel::<()>(1);
        let shutdown_tx_clone = self.shutdown_tx.clone();
        let workload_handles = self.workload_handles.clone();
        let service_handlers = self.service_handlers.clone();
        let tls_acceptor = self.tls_acceptor.clone();

        // Store the shutdown sender
        *shutdown_tx_clone.write().await = Some(shutdown_tx);

        let listener = self
            .listener
            .lock()
            .await
            .take()
            .context("HTTP server listener already consumed")?;
        let protocol = if self.tls_acceptor.is_some() {
            "HTTPS"
        } else {
            "HTTP"
        };
        info!(addr = ?addr, protocol = protocol, "{protocol} server listening");
        // Start the HTTP server, any incoming requests call Host::handle and then it's routed
        // to the workload based on host header.
        let handler = self.router.clone();
        let guest_meter = self.meters.read().await.guest();
        let connections = self.connections.clone();
        let stopped = AcceptingGuard(connections.clone());
        tokio::spawn(async move {
            if let Err(e) = run_http_server(
                listener,
                handler,
                workload_handles,
                service_handlers,
                &mut shutdown_rx,
                tls_acceptor,
                guest_meter,
                connections,
            )
            .await
            {
                error!(err = ?e, addr = ?addr, "HTTP server error");
            }
            drop(stopped);
        });
        Ok(())
    }

    /// Ends the accept loop, and lets go of the routing tables once the drain
    /// it starts has finished — not before, because connections already
    /// established are served from their own handles on those tables, and
    /// emptying them here would 404 every request still arriving over one.
    async fn stop(&self) -> anyhow::Result<()> {
        info!(addr = ?self.addr, "HTTP server stopping");
        // Scoped, so the release below is arranged without this guard held
        // across the locks it takes.
        let was_accepting = {
            let mut shutdown_guard = self.shutdown_tx.write().await;
            match shutdown_guard.take() {
                Some(tx) => {
                    let _ = tx.send(()).await;
                    true
                }
                None => false,
            }
        };
        // An ingress that never started has no drain to wait on, and waiting
        // would be forever: nothing will mark an accept loop stopped that never
        // ran.
        if was_accepting {
            self.release_when_drained();
        }
        Ok(())
    }

    async fn stopped(&self) {
        self.connections.stopped().await;
    }

    fn port(&self) -> u16 {
        self.addr.port()
    }

    async fn on_workload_resolved(
        &self,
        resolved_handle: &ResolvedWorkload,
        component_id: &str,
    ) -> anyhow::Result<()> {
        self.router
            .on_workload_resolved(resolved_handle, component_id)
            .await?;
        let instance_pre = resolved_handle.instantiate_pre(component_id).await?;

        // Tell the egress transport how much concurrency this component
        // declared, before it serves anything: its outbound connection burst
        // scales with the calls it runs at once, and a pool built without
        // that sizes itself for a component running one call at a time.
        self.outgoing_handler.on_workload_bind(
            resolved_handle.id(),
            resolved_handle.call_concurrency(component_id).await,
        );

        // Only components that export wasi:http are routable HTTP entrypoints.
        // Anything else stays unregistered and routes to a 404.
        if crate::engine::exports_wasi_http(instance_pre.component()) {
            // Resolved before the write lock is taken: they await a read of the
            // component map, and holding the handles' writer across that stalls
            // every inbound request, which reads the same lock to route.
            let identity = resolved_handle.component_identity(component_id).await;
            let pool = resolved_handle
                .instance_pool_for_component(component_id)
                .await;
            let targets_p3 = crate::engine::targets_wasip3_http(instance_pre.component());
            // A wasip2 incoming-handler instance serves one request, so HTTP
            // never reuses one; asking for a pool there would otherwise look
            // like it worked while every request still paid for a cold store.
            // Rate-limited at `warn` across workloads, and logged at `debug`
            // when suppressed, so every workload that does this is named.
            if pool.is_some() && !targets_p3 {
                match P2_POOL_WARN.admit() {
                    Some(suppressed) => warn!(
                        workload_id = resolved_handle.id(),
                        component_id,
                        suppressed,
                        "poolSize is set on a wasip2 HTTP handler, which serves one request per \
                         instance: HTTP requests to it are not pooled. Build it for wasip3 to \
                         keep instances warm"
                    ),
                    None => debug!(
                        workload_id = resolved_handle.id(),
                        component_id,
                        "poolSize is set on a wasip2 HTTP handler, which serves one request per \
                         instance: HTTP requests to it are not pooled (warning rate-limited)"
                    ),
                }
            }
            let handle = ComponentHandle {
                workload: resolved_handle.clone(),
                targets_p3,
                instance_pre,
                component_id: component_id.to_string(),
                identity,
                pool,
            };
            self.workload_handles
                .write()
                .await
                .insert(resolved_handle.id().to_string(), Arc::new(handle));
        }

        Ok(())
    }

    async fn on_workload_unbind(&self, workload_id: &str) -> anyhow::Result<()> {
        // A router that fails to forget the workload must not keep the rest of
        // its state alive too.
        let routed = self.router.on_workload_unbind(workload_id).await;

        self.workload_handles.write().await.remove(workload_id);
        self.service_handlers.write().await.remove(workload_id);
        self.messaging_handlers.write().await.remove(workload_id);
        // Drop the stopped workload's egress state (pooled connections, TLS
        // session store, pinned connection permits) instead of letting it
        // linger until idle expiry.
        self.outgoing_handler.on_workload_unbind(workload_id);

        routed
    }

    async fn on_service_http_resolved(
        &self,
        workload_id: &str,
        routes: &[IngressRoute],
        sender: tokio::sync::mpsc::Sender<ServiceHttpJob>,
    ) -> anyhow::Result<()> {
        self.router
            .on_service_http_resolved(workload_id, routes)
            .await?;
        // A re-resolve without an intervening unbind is expected: the trigger
        // service supervisor re-registers a fresh sender on every restart (see
        // `execute_trigger_service`) to swap in the new incarnation. Overwriting
        // is correct there — the replaced mapping belonged to the faulted
        // incarnation whose receiver is already dropped, so nothing live is
        // orphaned. Stop is the only path that unbinds.
        self.service_handlers
            .write()
            .await
            .insert(workload_id.to_string(), sender);
        Ok(())
    }

    async fn on_service_http_unbind(&self, workload_id: &str) -> anyhow::Result<()> {
        // Drop the router registration too, so a stopped service replica leaves
        // the hostname's replica set and stops being selected.
        let routed = self.router.on_workload_unbind(workload_id).await;
        self.service_handlers.write().await.remove(workload_id);
        routed
    }

    async fn on_trigger_service_messaging_resolved(
        &self,
        workload_id: &str,
        sender: tokio::sync::mpsc::Sender<MessagingJob>,
    ) -> anyhow::Result<()> {
        // As with the HTTP handler: a re-resolve without unbind is the expected
        // restart path (the supervisor swaps in the new incarnation's sender),
        // and the replaced mapping belonged to a faulted incarnation whose
        // receiver is already gone. Stop is the only path that unbinds.
        self.messaging_handlers
            .write()
            .await
            .insert(workload_id.to_string(), sender);
        Ok(())
    }

    async fn on_trigger_service_messaging_unbind(&self, workload_id: &str) -> anyhow::Result<()> {
        self.messaging_handlers.write().await.remove(workload_id);
        Ok(())
    }

    async fn deliver_trigger_service_message(
        &self,
        workload_id: &str,
        msg: BrokerMessage,
        attributes: std::sync::Arc<[opentelemetry::KeyValue]>,
    ) -> anyhow::Result<Result<(), String>> {
        let sender = self
            .messaging_handlers
            .read()
            .await
            .get(workload_id)
            .cloned()
            .ok_or_else(|| {
                anyhow::anyhow!(
                    "no messaging trigger service registered for workload {workload_id}"
                )
            })?;
        let (tx, rx) = tokio::sync::oneshot::channel();
        // Deadline enforced here, outside the service's store, where a
        // non-yielding guest cannot block it (see `crate::engine::abandon`).
        let call = DispatchedCall::new("messaging (service)", crate::timeouts::messaging_deliver());
        sender
            .send(MessagingJob {
                msg,
                result_tx: tx,
                abandoned: call.flag(),
                attributes,
            })
            .await
            .map_err(|_| anyhow::anyhow!("trigger service messaging instance is not running"))?;
        call.await_reply(rx)
            .await
            .ok_or_else(|| anyhow::anyhow!("trigger service produced no message response in time"))?
            .map_err(|_| anyhow::anyhow!("trigger service dropped the message response"))
    }

    async fn has_trigger_service_messaging(&self, workload_id: &str) -> bool {
        self.messaging_handlers
            .read()
            .await
            .contains_key(workload_id)
    }

    fn outgoing_request(
        &self,
        workload_id: &str,
        request: hyper::Request<WasiBody>,
        options: Option<RequestOptions>,
        fut: RequestIoFuture,
        allowed_hosts: &[AllowedHost],
    ) -> SendFuture {
        let span = outbound_client_span(request.method(), request.uri());
        let inner: SendFuture = if let Err(e) =
            self.router
                .allow_outgoing_request(workload_id, &request, options, allowed_hosts)
        {
            warn!(workload_id = %workload_id, err = %e, "outgoing request denied by allowed_hosts policy");
            deny_request(request)
        } else if is_grpc_request(&request) {
            // The gRPC path is selected by the guest via a
            // `content-type: application/grpc` header, and needs HTTP/2 rather
            // than the HTTP/1.1 the ordinary egress pool speaks. A pooling
            // handler serves it from its own per-workload HTTP/2 pool, under
            // the same quota; otherwise the runtime opens a connection per
            // request.
            match self.outgoing_handler.grpc_transport(workload_id) {
                Some(client) => {
                    Box::new(async move { client.send_grpc_request(request, options).await })
                }
                None => Box::new(send_grpc_request(request, options, self.grpc_tls())),
            }
        } else if let Some((target, destination)) =
            self.local_destination(workload_id, request.uri())
        {
            // Same-host short-circuit: dispatch to a co-located workload's
            // incoming path in-memory. Checked after the gRPC branch so gRPC
            // always egresses over the network, and after `allowed_hosts` so
            // the short-circuit never widens a workload's egress policy.
            // `fut`, the guest's response-consumption outcome, is dropped here
            // as wasmtime's default sender drops it.
            debug!(workload_id, target, uri = %request.uri(), "routing outgoing request to co-located workload");
            span.record("wasmcloud.http.route", "local");
            self.send_local_request(workload_id, target, destination, request, options)
        } else {
            self.outgoing_handler
                .send_request(workload_id, request, options, fut)
        };
        // Instrument the whole send so the span is current while the response
        // is awaited; `record_outbound_status` then lands on this span.
        Box::new(
            async move {
                let result = Box::into_pin(inner).await;
                match &result {
                    Ok((resp, _)) => {
                        record_outbound_status(resp.status());
                        // No-op unless the response carries a `grpc-status` header.
                        record_grpc_status(resp.headers());
                    }
                    // Covers allowed-hosts denials and transport failures.
                    Err(_) => record_outbound_error(),
                }
                result
            }
            .instrument(span),
        )
    }
}

/// How often a saturated ingress says so. Reporting each shed connection would
/// make the log the load problem.
const SHED_LOG_INTERVAL: Duration = Duration::from_secs(60);

/// How long a peer has to finish a TLS handshake before its connection slot is
/// taken back.
const TLS_HANDSHAKE_TIMEOUT: Duration = Duration::from_secs(30);

/// How long an accepted connection has to produce its first request.
///
/// Generous, because it also covers a client that connects ahead of the traffic
/// it is about to send. What it is not is unbounded, which is what deciding a
/// connection's protocol otherwise is.
const FIRST_REQUEST_TIMEOUT: Duration = Duration::from_secs(30);

/// Free connections a saturated host has to get back before it claims capacity
/// again, as a percentage of its ceiling.
///
/// Only the recovery side is a chosen number. What takes a host out of the
/// Service is having no room at all, which needs no threshold and cannot fire
/// on a host that is merely busy. This decides how much room is enough to stop
/// it returning into the same wall, so getting it wrong costs a saturated host
/// a little longer out of rotation and nothing else.
const READY_RECOVER_PERCENT: usize = 10;

/// The ingress connection ceiling, the permits enforcing it, and the counter
/// reporting it.
///
/// Together rather than separately because a refusal has to be counted where it
/// is decided: the accept loop is the only place that knows a connection was
/// offered and turned away.
#[derive(Clone)]
pub struct ConnectionLimit {
    max: usize,
    permits: Arc<Semaphore>,
    /// Set when the accept loop returns. A ceiling with every permit free is
    /// indistinguishable from a listener that stopped accepting, and the second
    /// is the more urgent of the two.
    ///
    /// A watch rather than a flag because both questions get asked: `/readyz`
    /// polls it per probe, and [`Self::stopped`] waits on it so the host can
    /// act on an accept loop that ended without being asked to.
    stopped: Arc<tokio::sync::watch::Sender<bool>>,
    /// Which side of the hysteresis below readiness is currently on. Shared,
    /// because the probe handler and the accept loop hold separate clones of
    /// the same limit.
    has_headroom: Arc<AtomicBool>,
    offered: opentelemetry::metrics::Counter<u64>,
    /// Built once. `error.type` marks the refusals inside the one series, so a
    /// shed rate is a filter on it rather than a second counter to keep in step.
    shed: Arc<[KeyValue]>,
}

impl ConnectionLimit {
    pub fn new(max: usize) -> Self {
        Self {
            max,
            permits: Arc::new(Semaphore::new(max)),
            stopped: Arc::new(tokio::sync::watch::Sender::new(false)),
            has_headroom: Arc::new(AtomicBool::new(true)),
            offered: opentelemetry::global::meter("wash-runtime")
                .u64_counter("http.ingress.connections")
                .with_description(
                    "Connections offered to the host's HTTP ingress, whether held or shed",
                )
                .build(),
            shed: Arc::from(vec![KeyValue::new(ERROR_TYPE, "no_capacity")]),
        }
    }

    /// Record that the accept loop is no longer running.
    fn stopped_accepting(&self) {
        self.stopped.send_replace(true);
    }

    /// Whether the accept loop is still running.
    ///
    /// An embedder that runs no probe listener reads this — or waits on
    /// [`Self::stopped`] — to learn what the host otherwise only logs.
    pub fn accepting(&self) -> bool {
        !*self.stopped.borrow()
    }

    /// Resolves once the accept loop has stopped, immediately if it already
    /// has.
    ///
    /// The loop is spawned detached and nothing restarts it, so this resolving
    /// means the host will serve no more HTTP for as long as it runs. See
    /// [`crate::host::http::HostHandler::stopped`], which is how that reaches
    /// the host.
    pub async fn stopped(&self) {
        let mut stopped = self.stopped.subscribe();
        // `Err` is the sender dropped, which cannot happen through a `&self`
        // holding it — and would mean the same thing if it could.
        let _ = stopped.wait_for(|stopped| *stopped).await;
    }

    /// Resolves once the accept loop has stopped *and* every connection it
    /// accepted has finished — the end of a drain, not the start of one.
    ///
    /// [`Self::stopped`] is weaker: connections are served by tasks outliving
    /// the loop, each holding the permit [`Self::take`] gave it, so holding
    /// every permit at once is what says none of them is still serving.
    pub async fn drained(&self) {
        self.stopped().await;
        let all = u32::try_from(self.max).unwrap_or(u32::MAX);
        // `Err` is a closed semaphore, which this never closes; either way
        // there is nothing left to wait for.
        let _ = self.permits.acquire_many(all).await;
    }

    /// Take a slot for an accepted connection, or `None` at the ceiling.
    ///
    /// Counted either way, with no attribute naming who was refused: a
    /// connection is turned away before its first request names a workload.
    fn take(&self) -> Option<tokio::sync::OwnedSemaphorePermit> {
        match Arc::clone(&self.permits).try_acquire_owned() {
            Ok(permit) => {
                self.offered.add(1, &[]);
                Some(permit)
            }
            Err(_) => {
                self.offered.add(1, &self.shed);
                None
            }
        }
    }
}

impl std::fmt::Debug for ConnectionLimit {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ConnectionLimit")
            .field("max", &self.max)
            .field("available", &self.permits.available_permits())
            .finish()
    }
}

/// A full ingress is a reason to stop being sent work, and not a reason to be
/// restarted.
///
/// Shedding keeps the host reachable, which means it keeps passing a TCP probe
/// — so without this its endpoint stays in the Service and traffic keeps
/// arriving for it to refuse. Readiness is what moves that traffic to a replica
/// with capacity.
impl crate::host::probes::ReadinessCheck for ConnectionLimit {
    fn name(&self) -> &'static str {
        if self.accepting() {
            "http_ingress_saturated"
        } else {
            "http_ingress_stopped"
        }
    }

    /// Not-ready means this host has no room, not that it is busy.
    ///
    /// A threshold on utilisation would take a healthy host out of the Service:
    /// a ceiling of 256 and a tenth-free mark pulls it at 231 connections while
    /// it is still serving every one of them, and replicas at similar load
    /// cross it together. So the departure is absolute — no permits left, which
    /// is the host actually turning connections away.
    ///
    /// Recovery is the part that needs a margin. Returning on a single freed
    /// permit puts a saturated host back a probe before it is full again, so it
    /// waits for [`READY_RECOVER_PERCENT`] of its ceiling to come back.
    fn ready(&self) -> bool {
        use std::sync::atomic::Ordering::Relaxed;
        if !self.accepting() {
            return false;
        }
        // Never above the ceiling, so a host too small for the percentage still
        // has a reachable recovery mark.
        let recover = (self.max * READY_RECOVER_PERCENT / 100)
            .max(1)
            .min(self.max);
        let free = self.permits.available_permits();
        let ready = if self.has_headroom.load(Relaxed) {
            free > 0
        } else {
            free >= recover
        };
        self.has_headroom.store(ready, Relaxed);
        ready
    }

    /// Saturation passes; an accept loop that has ended does not.
    ///
    /// Nothing brings the loop back without a restart, and readiness alone does
    /// not remove this host from anything that places work: the scheduler reads
    /// the Host CR's heartbeat-driven condition, which a host with a dead
    /// listener goes on satisfying. Left to readiness, it keeps being given
    /// workloads that report Ready and are unreachable.
    fn unrecoverable(&self) -> bool {
        !self.accepting()
    }
}

/// Marks [`ConnectionLimit`] stopped however the accept loop ends.
///
/// A guard rather than a statement after the await: a panicking task unwinds
/// past the statement, leaving readiness reporting a healthy idle host.
struct AcceptingGuard(ConnectionLimit);

impl Drop for AcceptingGuard {
    fn drop(&mut self) {
        self.0.stopped_accepting();
    }
}

/// Configure a freshly accepted connection before it is served.
///
/// Disables Nagle's algorithm. Responses are written as a head segment followed
/// by body frames streamed from the guest (see [`crate::host::http_p3`]); with
/// Nagle on, the small body segment is held until the client ACKs the head, and
/// the client's delayed ACK adds a ~40ms stall to every request (write-write-read
/// deadlock). `wasmtime serve` sets `TCP_NODELAY` for the same reason.
fn prepare_accepted_conn(stream: &TcpStream) {
    if let Err(e) = stream.set_nodelay(true) {
        warn!(err = ?e, "failed to set TCP_NODELAY on accepted connection");
    }
}

/// HTTP server implementation that routes to workload components
#[allow(clippy::too_many_arguments)]
async fn run_http_server<T: Router>(
    listener: TcpListener,
    handler: Arc<T>,
    workload_handles: WorkloadHandles,
    service_handlers: ServiceHandlers,
    shutdown_rx: &mut mpsc::Receiver<()>,
    tls_acceptor: Option<TlsAcceptor>,
    guest_meter: GuestMeter,
    connections: ConnectionLimit,
) -> anyhow::Result<()> {
    let mut backoff = crate::host::accept::AcceptBackoff::default();
    let mut shed = 0u64;
    let mut shed_reported: Option<std::time::Instant> = None;
    loop {
        // Taken before the select rather than inside it, so the pause races the
        // shutdown branch instead of needing a second copy of it.
        let pause = backoff.pause();
        tokio::select! {
            // Handle shutdown signal
            _ = shutdown_rx.recv() => {
                info!("HTTP server received shutdown signal");
                break;
            }
            // Accept new connections
            result = async {
                if let Some(pause) = pause {
                    tokio::time::sleep(pause).await;
                }
                listener.accept().await
            } => {
                match result {
                    Ok((client, client_addr)) => {
                        // A connection there is no descriptor budget to hold is
                        // closed now, while closing it is cheap. Holding it
                        // instead is what exhausts the process's descriptors,
                        // and a host that cannot accept is a host nothing can
                        // reach — including its own liveness probe.
                        let Some(slot) = connections.take() else {
                            shed += 1;
                            if shed_reported.is_none_or(|at| at.elapsed() >= SHED_LOG_INTERVAL) {
                                warn!(
                                    max_connections = connections.max, shed,
                                    "HTTP ingress is at its connection ceiling; shedding new connections"
                                );
                                shed_reported = Some(std::time::Instant::now());
                                shed = 0;
                            }
                            drop(client);
                            continue;
                        };

                        debug!(addr = ?client_addr, "new HTTP client connection");

                        prepare_accepted_conn(&client);

                        let handles_clone = workload_handles.clone();
                        let service_handlers_clone = service_handlers.clone();
                        let tls_acceptor_clone = tls_acceptor.clone();
                        let handler_clone = handler.clone();
                        let guest_meter = guest_meter.clone();
                        // What a guest is told it was reached over: this
                        // listener's own scheme, not a header a client can set.
                        let client_scheme = if tls_acceptor.is_some() {
                            hyper::http::uri::Scheme::HTTPS
                        } else {
                            hyper::http::uri::Scheme::HTTP
                        };
                        tokio::spawn(async move {
                            // Held for the connection's life: its descriptor is
                            // only given back once hyper is done with it.
                            let _slot = slot;
                            let requested = Arc::new(std::sync::atomic::AtomicBool::new(false));
                            let first_request = Arc::clone(&requested);
                            let service = hyper::service::service_fn(move |req| {
                                first_request.store(true, std::sync::atomic::Ordering::Relaxed);
                                let handles = handles_clone.clone();
                                let service_handlers = service_handlers_clone.clone();
                                let handler = handler_clone.clone();
                                let guest_meter = guest_meter.clone();
                                let scheme = client_scheme.clone();
                                async move {
                                    let extractor = opentelemetry_http::HeaderExtractor(req.headers());
                                    let remote_context =
                                        opentelemetry::global::get_text_map_propagator(|propagator| propagator.extract(&extractor));

                                    handle_http_request(handler, req, scheme, handles, service_handlers, guest_meter).with_context(remote_context).await
                                }
                            });

                            let mut builder = auto::Builder::new(TokioExecutor::new());
                            // Arms hyper's own header-read timeout, which
                            // bounds a peer dribbling headers once its protocol
                            // is known. Deciding that protocol is bounded
                            // separately, below.
                            builder
                                .http1()
                                .timer(TokioTimer::new())
                                .keep_alive(true);
                            builder
                                .http2()
                                .timer(TokioTimer::new())
                                .keep_alive_interval(Some(Duration::from_secs(20)));

                            let serve = async {
                            if let Some(acceptor) = tls_acceptor_clone {
                                // Handle HTTPS connection. Bounded, because a
                                // handshake nobody finishes holds a connection
                                // slot that no request will ever release.
                                let handshake = tokio::time::timeout(
                                    TLS_HANDSHAKE_TIMEOUT,
                                    acceptor.accept(client),
                                );
                                match handshake.await {
                                    Err(_) => {
                                        warn!(addr = ?client_addr, "TLS handshake timed out");
                                        Ok(())
                                    }
                                    Ok(Ok(tls_stream)) => {
                                        builder
                                            .serve_connection_with_upgrades(TokioIo::new(tls_stream), service)
                                            .await
                                    }
                                    Ok(Err(e)) => {
                                        error!(addr = ?client_addr, err = ?e, "TLS handshake failed");
                                        Ok(())
                                    }
                                }
                            } else {
                                // Handle HTTP/h2c connection
                                builder
                                    .serve_connection_with_upgrades(TokioIo::new(client), service)
                                    .await
                            }
                            };

                            // A connection earns its slot by asking for
                            // something: sniffing its protocol is bounded by
                            // nothing, so a peer sending half an HTTP/2 preface
                            // would hold one forever.
                            let mut serve = std::pin::pin!(serve);
                            let mut deadline = std::pin::pin!(tokio::time::sleep(FIRST_REQUEST_TIMEOUT));
                            let mut expired = false;
                            let result = loop {
                                tokio::select! {
                                    // Biased, so the connection is always polled
                                    // before the deadline is acted on. `requested`
                                    // is set from inside the service, which only
                                    // runs while `serve` is being polled — with
                                    // the arms chosen at random, a request that
                                    // arrived in the same instant the deadline
                                    // fired had not been seen yet, and the
                                    // connection was dropped with that request
                                    // unanswered and unread. Polling first is what
                                    // makes "sent no request" mean it.
                                    biased;
                                    result = &mut serve => break result,
                                    () = &mut deadline, if !expired => {
                                        expired = true;
                                        if !requested.load(std::sync::atomic::Ordering::Relaxed) {
                                            debug!(addr = ?client_addr, "closing a connection that sent no request");
                                            return;
                                        }
                                    }
                                }
                            };

                            if let Err(e) = result {
                                // A timeout is the peer not sending, which is
                                // what the deadline above closes connections
                                // for. Both bound that same condition, so
                                // whichever fires first decides nothing about
                                // what happened — and `ERROR` here would put a
                                // probe, a port scan or a forwarded port whose
                                // far end went away beside real serving
                                // failures, in the one place an operator looks
                                // for them.
                                if ended_in_timeout(&*e) {
                                    debug!(addr = ?client_addr, err = ?e, "closing a connection that sent no request");
                                } else {
                                    error!(addr = ?client_addr, err = ?e, "error serving HTTP client");
                                }
                            }
                        });
                    }
                    Err(e) => {
                        if backoff.failed(&e) {
                            error!(err = ?e, failures = backoff.failures(), "HTTP ingress cannot accept connections");
                        } else {
                            debug!(err = ?e, "failed to accept HTTP connection");
                        }
                    }
                }
            }
        }
    }

    Ok(())
}

/// Whether a served connection ended because the peer stopped sending.
///
/// The connection future is boxed by the protocol-detecting builder, so the
/// hyper error carrying that answer can be at any depth of the chain.
fn ended_in_timeout(e: &(dyn std::error::Error + 'static)) -> bool {
    if let Some(hyper) = e.downcast_ref::<hyper::Error>() {
        return hyper.is_timeout();
    }
    e.source().is_some_and(ended_in_timeout)
}

/// How often each per-request ingress warning may be logged.
const INGRESS_WARN_INTERVAL: Duration = Duration::from_secs(10);
static INVALID_AUTHORITY_WARN: RateLimitedWarn = RateLimitedWarn::new(INGRESS_WARN_INTERVAL);
static ROUTE_FAILURE_WARN: RateLimitedWarn = RateLimitedWarn::new(INGRESS_WARN_INTERVAL);
/// `poolSize` on a wasip2 HTTP handler at `warn`, once per interval however
/// many bind; the rest are logged at `debug`.
static P2_POOL_WARN: RateLimitedWarn = RateLimitedWarn::new(INGRESS_WARN_INTERVAL);
static UNBOUND_HOST_WARN: RateLimitedWarn = RateLimitedWarn::new(INGRESS_WARN_INTERVAL);

/// Build an error response with the given status code.
/// Building HTTP responses with valid status codes is infallible.
#[allow(clippy::expect_used)]
fn error_response(status: u16) -> hyper::Response<WasiBody> {
    hyper::Response::builder()
        .status(status)
        .body(WasiBody::default())
        .expect("building HTTP response with valid status code should never fail")
}

/// Handle individual HTTP requests by looking up workload and invoking component
///
/// HTTP request attributes are emitted under both the current-stable OTel HTTP
/// semconv names (`http.request.method`, `url.path`, `server.address`,
/// `server.port`) and the legacy names (`http.method`, `http.uri`, `http.host`)
/// so dashboards built against either convention resolve. `server.address` holds
/// the host without its port; the port is recorded separately as `server.port`
/// when the `Host` header carries one. In addition:
/// - `http.response.status_code` is recorded before returning so span-metrics
///   collectors can break down requests by 2xx/4xx/5xx.
/// - `otel.status_code` is set to `ERROR` for 5xx; 4xx stays UNSET per semconv.
#[instrument(skip_all, fields(
    // Legacy (pre-semconv) attribute names retained so dashboards built against
    // them keep resolving.
    http.method = %req.method(),
    http.uri = %req.uri(),
    http.host = %host_header(&req),
    // Current OTel HTTP semantic conventions, referenced via the
    // `opentelemetry-semantic-conventions` constants (tracing's `{expr}` field
    // syntax resolves the constant to its attribute name at compile time).
    { HTTP_REQUEST_METHOD } = %req.method(),
    { URL_PATH } = %req.uri().path(),
    { SERVER_ADDRESS } = split_host_port(host_header(&req)).0,
    { SERVER_PORT } = tracing::field::Empty,
    { HTTP_RESPONSE_STATUS_CODE } = tracing::field::Empty,
    // Recorded once the response body has been fully streamed (see `MeteredBody`).
    { HTTP_RESPONSE_BODY_SIZE } = tracing::field::Empty,
    { OTEL_STATUS_CODE } = tracing::field::Empty,
))]
async fn handle_http_request<T: Router>(
    handler: Arc<T>,
    mut req: hyper::Request<hyper::body::Incoming>,
    scheme: hyper::http::uri::Scheme,
    workload_handles: WorkloadHandles,
    service_handlers: ServiceHandlers,
    guest_meter: GuestMeter,
) -> Result<hyper::Response<WasiBody>, hyper::Error> {
    // Every guest reads its scheme and authority off the URI, so they are put
    // there once, here, from this listener rather than from any header.
    if !normalize_ingress_uri(&mut req, &scheme) {
        let host = host_header(&req);
        match INVALID_AUTHORITY_WARN.admit() {
            Some(suppressed) => warn!(
                host,
                suppressed, "rejecting a request whose Host is not a valid authority"
            ),
            None => debug!(
                host,
                "rejecting a request whose Host is not a valid authority"
            ),
        }
        let resp = error_response(400);
        record_response_status(&resp);
        return Ok(resp);
    }
    let method = req.method().clone();
    let uri = req.uri().clone();

    // server.port is recorded separately from server.address per the OTel HTTP
    // semconv; only set it when the Host header actually carries a port.
    if let Some(port) = split_host_port(host_header(&req)).1 {
        tracing::Span::current().record(SERVER_PORT, port);
    }

    let workload_id = match handler.route_incoming_request(&req) {
        Ok(id) => id,
        Err(e) => {
            match ROUTE_FAILURE_WARN.admit() {
                Some(suppressed) => {
                    warn!(err = %e, suppressed, "failed to route incoming request")
                }
                None => debug!(err = %e, "failed to route incoming request"),
            }
            let resp = error_response(e.status());
            record_response_status(&resp);
            return Ok(resp);
        }
    };

    debug!(
        method = %method,
        uri = %uri,
        host = %workload_id,
        "HTTP request received"
    );

    // Box the network body into the shared body type so the service channel
    // and per-request invoke path accept both network ingress and locally
    // routed requests (see `dispatch_local`).
    let req = req.map(|body| body.map_err(wasmtime_wasi_http::Error::from).boxed_unsync());

    // If this workload's long-lived service serves HTTP, deliver the request to
    // it (preserving its in-memory state) instead of the per-request path.
    let service_sender = service_handlers.read().await.get(&workload_id).cloned();
    if let Some(sender) = service_sender {
        let (resp_tx, resp_rx) = tokio::sync::oneshot::channel();
        // The deadline is enforced here, outside the service's store: a guest
        // that never yields blocks every host future on its own store, so only
        // a waiter out here can abandon the call (see `crate::engine::abandon`).
        let call = DispatchedCall::new("HTTP (service)", crate::timeouts::http_response());
        let job = ServiceHttpJob {
            req,
            resp_tx,
            abandoned: call.flag(),
        };
        let response = if sender.send(job).await.is_err() {
            error!(host = %workload_id, "service HTTP instance is not running");
            error_response(503)
        } else {
            match call.await_head(resp_rx).await {
                Some((Ok(Ok(resp)), watch)) => watch_body(resp, watch),
                Some((Ok(Err(e)), _)) => {
                    error!(err = ?e, "service HTTP handler failed");
                    error_response(500)
                }
                Some((Err(_), _)) => {
                    error!("service HTTP instance dropped the response");
                    error_response(500)
                }
                None => {
                    error!("service HTTP instance produced no response");
                    error_response(500)
                }
            }
        };
        record_response_status(&response);
        return Ok(response);
    }

    // NOTE(lxf): Separate HTTP / GRPC handling

    // Look up workload handle for this host, with wildcard fallback
    let workload_handle = {
        let handles = workload_handles.read().await;
        debug!(host = %workload_id, "looking up workload handle for host header");
        handles.get(&workload_id).cloned()
    };

    let response = match workload_handle {
        Some(handle) => {
            let req_span = tracing::span!(
                tracing::Level::INFO,
                "invoke_component_handler",
                workload.name = handle.workload.name(),
                workload.namespace = handle.workload.namespace(),
                workload.id = handle.workload.id(),
            );
            match invoke_component_handler(&handle, req, guest_meter)
                .instrument(req_span)
                .await
            {
                Ok(resp) => resp,
                Err(e) => {
                    error!(err = ?e, "failed to invoke component");
                    error_response(500)
                }
            }
        }
        None => {
            match UNBOUND_HOST_WARN.admit() {
                Some(suppressed) => warn!(
                    host = %workload_id,
                    suppressed,
                    "No workload bound to host header or wildcard '*'"
                ),
                None => debug!(
                    host = %workload_id,
                    "No workload bound to host header or wildcard '*'"
                ),
            }
            error_response(404)
        }
    };

    record_response_status(&response);
    // Carry the current span on the response body so `http.response.body.size`
    // is recorded once the HTTP server finishes streaming the body. That
    // happens after this handler future — and its `#[instrument]` span — has
    // returned, so the body wrapper keeps a span handle alive to land the
    // attribute before the span closes.
    let response =
        response.map(|body| MeteredBody::new(body, tracing::Span::current()).boxed_unsync());
    Ok(response)
}

/// Record the response's status on the current span as the OTel HTTP semconv
/// attribute `http.response.status_code`. 5xx flips `otel.status_code` to
/// `ERROR` per the HTTP semconv (4xx is a client error and stays UNSET).
fn record_response_status<B>(response: &hyper::Response<B>) {
    let status = response.status().as_u16();
    let span = tracing::Span::current();
    span.record(HTTP_RESPONSE_STATUS_CODE, status);
    if status >= 500 {
        span.record(OTEL_STATUS_CODE, "ERROR");
    }
}

/// Build a `client` span for an outbound HTTP request following the OTel HTTP
/// client semantic conventions. `http.response.status_code` and
/// `otel.status_code` are left empty for [`record_outbound_status`] to fill in
/// once the response arrives.
///
/// The span must be entered (e.g. via [`tracing::Instrument::instrument`]) for
/// the duration of the request so that status recorded on the *current* span
/// from inside the async work lands on this span.
fn outbound_client_span(method: &hyper::Method, uri: &hyper::Uri) -> tracing::Span {
    let span = tracing::info_span!(
        "outbound_http_request",
        otel.kind = "client",
        { HTTP_REQUEST_METHOD } = %method,
        { URL_FULL } = %uri,
        { SERVER_ADDRESS } = uri.host().unwrap_or_default(),
        { SERVER_PORT } = tracing::field::Empty,
        { HTTP_RESPONSE_STATUS_CODE } = tracing::field::Empty,
        { RPC_GRPC_STATUS_CODE } = tracing::field::Empty,
        { OTEL_STATUS_CODE } = tracing::field::Empty,
        // Set to "local" when the request is served by a co-located workload
        // in-memory instead of egressing (see IngressBuilder::local_routing).
        wasmcloud.http.route = tracing::field::Empty,
    );
    if let Some(port) = uri.port_u16() {
        span.record(SERVER_PORT, port);
    }
    span
}

/// Record an outbound response status on the current span. Per the HTTP client
/// semconv, both 4xx and 5xx flip `otel.status_code` to `ERROR` for client
/// spans (unlike server spans, where 4xx stays UNSET).
fn record_outbound_status(status: hyper::StatusCode) {
    let span = tracing::Span::current();
    span.record(HTTP_RESPONSE_STATUS_CODE, status.as_u16());
    if status.as_u16() >= 400 {
        span.record(OTEL_STATUS_CODE, "ERROR");
    }
}

/// Mark the current outbound span as failed when the request never produced a
/// response (allowed-hosts denial, connection failure, transport error, …).
fn record_outbound_error() {
    tracing::Span::current().record(OTEL_STATUS_CODE, "ERROR");
}

/// Record the gRPC status as `rpc.grpc.status_code` on the current span when the
/// response carries a `grpc-status` header. gRPC errors are typically
/// trailers-only responses that put the status in headers, so this captures
/// them; a status delivered in actual trailers (the streaming-success case) is
/// not read here.
fn record_grpc_status(headers: &hyper::HeaderMap) {
    if let Some(code) = headers
        .get("grpc-status")
        .and_then(|v| v.to_str().ok())
        .and_then(|v| v.parse::<i64>().ok())
    {
        tracing::Span::current().record(RPC_GRPC_STATUS_CODE, code);
    }
}

/// Response-body wrapper that tallies streamed bytes and records
/// `http.response.body.size` on `span` once the body completes (ends, errors,
/// or is dropped).
///
/// The HTTP server drains the body after the handler future returns, so the
/// wrapper holds its own [`tracing::Span`] handle. That keeps the span open
/// until the body is done, ensuring the attribute is recorded before the span
/// closes.
struct MeteredBody {
    inner: WasiBody,
    span: tracing::Span,
    bytes: u64,
    recorded: bool,
}

impl MeteredBody {
    fn new(inner: WasiBody, span: tracing::Span) -> Self {
        Self {
            inner,
            span,
            bytes: 0,
            recorded: false,
        }
    }

    fn record(&mut self) {
        if !self.recorded {
            self.span.record(HTTP_RESPONSE_BODY_SIZE, self.bytes);
            self.recorded = true;
        }
    }
}

impl hyper::body::Body for MeteredBody {
    type Data = bytes::Bytes;
    type Error = wasmtime_wasi_http::Error;

    fn poll_frame(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Result<hyper::body::Frame<Self::Data>, Self::Error>>> {
        use std::task::Poll;
        match std::pin::Pin::new(&mut self.inner).poll_frame(cx) {
            Poll::Ready(Some(Ok(frame))) => {
                if let Some(data) = frame.data_ref() {
                    self.bytes += data.len() as u64;
                }
                Poll::Ready(Some(Ok(frame)))
            }
            Poll::Ready(Some(Err(e))) => {
                self.record();
                Poll::Ready(Some(Err(e)))
            }
            Poll::Ready(None) => {
                self.record();
                Poll::Ready(None)
            }
            Poll::Pending => Poll::Pending,
        }
    }

    fn is_end_stream(&self) -> bool {
        self.inner.is_end_stream()
    }

    fn size_hint(&self) -> hyper::body::SizeHint {
        self.inner.size_hint()
    }
}

impl Drop for MeteredBody {
    fn drop(&mut self) {
        // Capture whatever was streamed if the body was dropped early (e.g. the
        // client disconnected mid-response).
        self.record();
    }
}

/// The request's `Host` header as a string, or `"unknown"` when absent or
/// non-UTF-8.
fn host_header<B>(req: &hyper::Request<B>) -> &str {
    req.headers()
        .get(hyper::header::HOST)
        .and_then(|h| h.to_str().ok())
        .unwrap_or("unknown")
}

/// Split a `Host` header value into the host without its port and an optional
/// port. Handles bracketed IPv6 literals such as `[::1]:8080`, returning the
/// address without brackets.
///
/// Feeds the OTel `server.address`/`server.port` attributes and
/// [`DynamicRouter`]'s routing key. A suffix that is not a number is dropped
/// rather than rejected, so `example.com:no-such-port` routes as
/// `example.com`.
/// The port a scheme implies when a URI does not spell one out.
fn default_port_for_scheme(scheme: Option<&str>) -> u16 {
    scheme
        .and_then(crate::host::allowed_hosts::default_port)
        .unwrap_or(80)
}

fn split_host_port(host: &str) -> (&str, Option<u16>) {
    if let Some(rest) = host.strip_prefix('[') {
        // IPv6 literal: `[addr]` or `[addr]:port`.
        if let Some((addr, after)) = rest.split_once(']') {
            let port = after.strip_prefix(':').and_then(|p| p.parse().ok());
            return (addr, port);
        }
        return (host, None);
    }
    match host.rsplit_once(':') {
        Some((addr, port)) => (addr, port.parse().ok()),
        None => (host, None),
    }
}

/// Invoke the component handler for the given workload
async fn invoke_component_handler(
    // Resolved once when the route was registered: this runs per request.
    handle: &ComponentHandle,
    req: hyper::Request<WasiBody>,
    guest_meter: GuestMeter,
) -> anyhow::Result<hyper::Response<WasiBody>> {
    let ComponentHandle {
        workload: workload_handle,
        instance_pre,
        component_id,
        identity,
        targets_p3,
        pool,
    } = handle;
    let component_id = component_id.as_str();
    if *targets_p3 {
        // A component that keeps instances warm serves this on one of them,
        // alongside whatever else that instance already has in flight. Only
        // when every warm instance is full and the pool is at `pool_size` does
        // the request fall through to a store of its own.
        let mut reclaimed = None;
        let req = if let Some(pool) = pool.as_ref() {
            use crate::engine::instance_driver::InstanceJob;
            use crate::engine::instance_pool::Declined;
            let (resp_tx, resp_rx) = tokio::sync::oneshot::channel();
            let call = DispatchedCall::new("HTTP (pooled)", crate::timeouts::http_response());
            let job = InstanceJob::Http(Box::new(ServiceHttpJob {
                req,
                resp_tx,
                abandoned: call.flag(),
            }));
            let outcome =
                crate::engine::instance_pool::offer_or_install(pool, instance_pre, job, || {
                    workload_handle.new_store_as(component_id, Some(identity))
                })
                .await?;
            match outcome {
                Ok(()) => {
                    let (resp, watch) = call
                        .await_head(resp_rx)
                        .await
                        .ok_or_else(|| anyhow::anyhow!("pooled instance produced no response"))?;
                    let resp =
                        resp.map_err(|_| anyhow::anyhow!("pooled instance dropped the request"))??;
                    return Ok(watch_body(resp, watch));
                }
                // Every warm instance was busy; serve it cold below.
                Err(Declined {
                    job: InstanceJob::Http(job),
                    instance,
                }) => {
                    reclaimed = instance;
                    job.req
                }
                // A job comes back as the variant it went in as, so this is
                // unreachable — but not worth a panic on a request path.
                Err(Declined { job: other, .. }) => {
                    debug_assert!(false, "an HTTP job cannot come back as another kind");
                    anyhow::bail!(
                        "instance pool returned a {} job for an HTTP request",
                        match other {
                            InstanceJob::Linked(_) => "linked",
                            InstanceJob::Messaging(_) => "messaging",
                            InstanceJob::Guest(_) => "dispatched",
                            InstanceJob::Http(_) => "http",
                        }
                    );
                }
            }
        } else {
            req
        };

        let cold = match reclaimed {
            Some(built) => built,
            None => {
                let mut store = workload_handle
                    .new_store_as(component_id, Some(identity))
                    .await?;
                let instance = instance_pre
                    .instantiate_async(&mut store)
                    .await
                    .map_err(|e| {
                        crate::engine::pool_usage::explain_instantiate_failure(store.data(), e)
                    })?;
                crate::engine::instance_pool::ComponentInstance { store, instance }
            }
        };
        let call = DispatchedCall::new("HTTP (cold store)", crate::timeouts::http_response());
        let flag = call.flag();
        let (resp, watch) = call
            .await_head(crate::host::http_p3::handle_component_request_p3(
                cold, req, flag,
            ))
            .await
            .ok_or_else(|| anyhow::anyhow!("cold instance produced no response"))?;
        return Ok(watch_body(resp?, watch));
    }

    // The p2 path still builds and instantiates per request: its store is
    // owned by a detached task that outlives the response head, so recovering
    // it for reuse needs a restructure the p3 path did not.
    let store = workload_handle
        .new_store_as(component_id, Some(identity))
        .await?;
    handle_component_request(store, instance_pre.clone(), req, guest_meter, identity).await
}

/// Handle a component request using WASI HTTP (copied from wash/crates/src/cli/dev.rs)
pub async fn handle_component_request(
    mut store: Store<SharedCtx>,
    pre: InstancePre<SharedCtx>,
    req: hyper::Request<WasiBody>,
    guest_meter: GuestMeter,
    identity: &crate::observability::WorkloadIdentity,
) -> anyhow::Result<hyper::Response<WasiBody>> {
    let (sender, receiver) = tokio::sync::oneshot::channel();
    let scheme = match req.uri().scheme() {
        Some(scheme) if scheme == &hyper::http::uri::Scheme::HTTP => Scheme::Http,
        Some(scheme) if scheme == &hyper::http::uri::Scheme::HTTPS => Scheme::Https,
        Some(scheme) => Scheme::Other(scheme.as_str().to_string()),
        // Fallback to HTTP if no scheme is present
        None => Scheme::Http,
    };

    let attributes = http_attributes(identity, req.method(), HTTP_OPERATION_P2);

    let req = with_body_timeout(req, crate::timeouts::http_request_body());
    let req = store.data_mut().http().new_incoming_request(scheme, req)?;
    let out = store.data_mut().http().new_response_outparam(sender)?;
    let pre = ProxyPre::new(pre)
        .map_err(anyhow::Error::from)
        .context("failed to instantiate proxy pre")?;

    // The deadline is enforced below, outside the store, where a non-yielding
    // guest cannot block it (see `crate::engine::abandon`).
    let call = DispatchedCall::new("HTTP (p2 cold store)", crate::timeouts::http_response());
    let watch_guard = store.data().abandoned.watch(call.flag());

    // Run the http request itself in a separate task so the task can
    // optionally continue to execute beyond after the initial
    // headers/response code are sent.
    let task: JoinHandle<anyhow::Result<()>> = tokio::task::spawn(
        async move {
            // Watched for as long as the store runs guest code.
            let _abandoned = watch_guard;
            // Run the http request itself by instantiating and calling the component
            let proxy = pre.instantiate_async(&mut store).await.map_err(|e| {
                crate::engine::pool_usage::explain_instantiate_failure(store.data(), e)
            })?;

            guest_meter
                .observe(&attributes, &mut store, async move |store| {
                    proxy
                        .wasi_http_incoming_handler()
                        .call_handle(store, req, out)
                        .await?;

                    Ok(())
                })
                .await?;

            Ok(())
        }
        .in_current_span(),
    );

    match call.await_head(receiver).await {
        // If the client calls `response-outparam::set` then one of these
        // methods will be called.
        Some((Ok(Ok(resp)), watch)) => Ok(watch_body(resp, watch)),
        Some((Ok(Err(e)), _)) => Err(e.into()),

        // Otherwise the `sender` will get dropped along with the `Store`
        // meaning that the oneshot will get disconnected
        Some((Err(e), _)) => {
            if let Err(task_error) = task.await {
                error!(err = ?task_error, "error receiving http response");
                Err(anyhow::anyhow!(
                    "error receiving http response: {task_error}"
                ))
            } else {
                error!(err = ?e, "error receiving http response");
                Err(anyhow::anyhow!(
                    "oneshot channel closed but no response was sent"
                ))
            }
        }

        // No response within the deadline; the call is abandoned, and the
        // store's epoch callback ends the guest work behind it.
        None => Err(anyhow::anyhow!("component produced no response in time")),
    }
}

/// Load TLS configuration from certificate and key files
/// Extracted from wash dev command for reuse in HTTP server plugin
async fn load_tls_config(
    cert_path: &Path,
    key_path: &Path,
    ca_path: Option<&Path>,
) -> anyhow::Result<ServerConfig> {
    // Load certificate chain
    let cert_data = tokio::fs::read(cert_path).await.context(format!(
        "Failed to read certificate file: {}",
        cert_path.display()
    ))?;
    let cert_chain: Vec<CertificateDer<'static>> = CertificateDer::pem_slice_iter(&cert_data)
        .collect::<Result<Vec<_>, _>>()
        .context(format!(
            "Failed to parse certificate file: {}",
            cert_path.display()
        ))?;

    ensure!(
        !cert_chain.is_empty(),
        "No certificates found in file: {}",
        cert_path.display()
    );

    // Load private key
    let key_data = tokio::fs::read(key_path).await.context(format!(
        "Failed to read private key file: {}",
        key_path.display()
    ))?;
    let key = PrivateKeyDer::from_pem_slice(&key_data).context(format!(
        "Failed to parse private key file: {}",
        key_path.display()
    ))?;

    // Create rustls server config
    let mut config = ServerConfig::builder()
        .with_no_client_auth()
        .with_single_cert(cert_chain, key)
        .context("failed to create TLS configuration")?;

    // Advertise both h2 and http/1.1 via ALPN
    config.alpn_protocols = vec![b"h2".to_vec(), b"http/1.1".to_vec()];

    // If CA is provided, configure client certificate verification
    if let Some(ca_path) = ca_path {
        let ca_data = tokio::fs::read(ca_path)
            .await
            .context(format!("failed to read CA file: {}", ca_path.display()))?;
        let ca_certs: Vec<CertificateDer<'static>> = CertificateDer::pem_slice_iter(&ca_data)
            .collect::<Result<Vec<_>, _>>()
            .context(format!("failed to parse CA file: {}", ca_path.display()))?;

        ensure!(
            !ca_certs.is_empty(),
            "No CA certificates found in file: {}",
            ca_path.display()
        );

        // Note: Client certificate verification configuration would go here
        // For now, we'll keep it simple without client cert verification
        debug!("CA certificate loaded, but client certificate verification not yet implemented");
    }

    Ok(config)
}

/// Checks whether an outgoing request is permitted by the `allowed_hosts`
/// policy.
///
/// **Empty list = deny all.** A workload with no entries cannot
/// reach any outbound host. Callers that want unrestricted egress must pass
/// an explicit `[AllowedHost::Any]`. The wash config layer enforces this by
/// substituting `[Any]` when `allowedHosts` is omitted from the YAML
/// (see `wash::workload::resolve_workload`), so runtime callers that come
/// through wash never see an empty list.
///
/// Otherwise the request's host (and, when the policy entry specifies them,
/// scheme and port) must satisfy at least one [`AllowedHost`] entry. See
/// [`AllowedHost::matches`] for per-variant semantics.
///
/// # Errors
///
/// Returns an error when the request has no host, when `allowed_hosts` is
/// empty, or when no policy entry matches.
pub fn check_allowed_hosts<B>(
    request: &hyper::Request<B>,
    allowed_hosts: &[AllowedHost],
) -> anyhow::Result<()> {
    let uri = request.uri();
    let request_host = uri.host().context("outgoing request has no host")?;

    if allowed_hosts.is_empty() {
        anyhow::bail!(
            "outgoing request to host '{request_host}' denied: allowed_hosts policy is empty (deny-all)"
        );
    }

    if allowed_hosts.iter().any(|entry| entry.matches(uri)) {
        return Ok(());
    }

    anyhow::bail!(
        "outgoing request to host '{request_host}' is not allowed by allowed_hosts policy"
    )
}

const MAX_DENIED_BODY_DRAINS: usize = 64;
const DENIED_BODY_DRAIN_TIMEOUT: Duration = Duration::from_secs(10);

async fn drain_denied_body(mut body: WasiBody, timeout: Duration) {
    _ = tokio::time::timeout(timeout, async {
        while let Some(Ok(_frame)) = body.frame().await {}
    })
    .await;
}

/// Refuse an outgoing request while briefly draining its body.
fn deny_request(request: hyper::Request<WasiBody>) -> SendFuture {
    static DRAINS: std::sync::LazyLock<Arc<Semaphore>> =
        std::sync::LazyLock::new(|| Arc::new(Semaphore::new(MAX_DENIED_BODY_DRAINS)));
    if let Ok(permit) = Arc::clone(&DRAINS).try_acquire_owned() {
        tokio::spawn(async move {
            let _permit = permit;
            drain_denied_body(request.into_body(), DENIED_BODY_DRAIN_TIMEOUT).await;
        });
    }
    Box::new(async { Err(wasmtime_wasi_http::Error::HttpRequestDenied) })
}

/// The I/O future of an inbound `wasi:http` 0.3 request; see [`p3_request`].
pub(crate) type P3RequestIo = std::pin::Pin<
    Box<dyn std::future::Future<Output = Result<(), wasmtime_wasi_http::Error>> + Send>,
>;

/// Convert an inbound request for a `wasi:http` 0.3 guest, with the store's
/// hooks deciding which headers it may see.
///
/// Those hooks strip every hop-by-hop header — `host`, `connection`,
/// `keep-alive`, `transfer-encoding`, `upgrade`, the `proxy-*` pair and
/// `http2-settings` — before the guest is handed the request. That is what a
/// 0.2 guest has always been given and what `wasi:http` intends: they describe
/// this hop, which the guest does not own. What a guest legitimately needs from
/// them, the scheme and authority, is on the URI — see
/// [`normalize_ingress_uri`].
///
/// The I/O future is boxed because `from_http`'s opaque return type captures
/// the hooks borrow, although the future itself is `'static`.
pub(crate) fn p3_request(
    ctx: &mut SharedCtx,
    mut req: hyper::Request<WasiBody>,
) -> (wasmtime_wasi_http::p3::Request, P3RequestIo) {
    // A request that reaches a guest came through the ingress, which has
    // normalized it already; this covers a caller that did not, and is a no-op
    // otherwise.
    normalize_ingress_uri(&mut req, &hyper::http::uri::Scheme::HTTP);
    let req = with_body_timeout(req, crate::timeouts::http_request_body());
    let (req, io) = wasmtime_wasi_http::p3::Request::from_http(ctx.http().hooks, req);
    (req, Box::pin(io))
}

/// Give a request the scheme and authority a guest should see, reporting
/// whether its `Host` was usable.
///
/// HTTP/1.1 sends an origin-form target, so the URI carries neither scheme nor
/// authority, and wasmtime strips `Host` before any guest — 0.2 or 0.3 — is
/// handed the request. Both therefore have to read them from here.
///
/// `scheme` is how the client reached *this* listener, never a forwarded
/// header: `X-Forwarded-Proto` is set by whoever spoke to us, and a workload
/// building redirect or callback URLs from a spoofed scheme is the same class of
/// bug [wasmCloud#5557] fixes for `X-Real-IP`. A trusted-proxy setting could
/// override it later; there is no such trust today.
///
/// Returns `false` for a `Host` that is not a valid authority. Such a request
/// cannot be routed either — the hostname router splits on the last colon, so
/// `example.com:8080:9090` would route as `example.com:8080` — so the ingress
/// answers it with a 400 rather than guessing.
///
/// [wasmCloud#5557]: https://github.com/wasmCloud/wasmCloud/pull/5557
fn normalize_ingress_uri<B>(
    req: &mut hyper::Request<B>,
    scheme: &hyper::http::uri::Scheme,
) -> bool {
    let header_authority = match req.headers().get(hyper::header::HOST) {
        Some(host) => match host
            .to_str()
            .ok()
            .and_then(|host| host.parse::<hyper::http::uri::Authority>().ok())
        {
            Some(authority) => Some(authority),
            None => return false,
        },
        None => None,
    };
    let uri_authority = req.uri().authority();
    if let (Some(header), Some(uri)) = (&header_authority, uri_authority)
        && !header.as_str().eq_ignore_ascii_case(uri.as_str())
    {
        return false;
    }
    // `OPTIONS *` has no URI authority or scheme to normalize.
    if req.uri().path() == "*" {
        return true;
    }
    let Some(authority) = uri_authority.cloned().or(header_authority) else {
        return true;
    };
    let mut parts = req.uri().clone().into_parts();
    parts.scheme = Some(scheme.clone());
    parts.authority = Some(authority);
    parts
        .path_and_query
        .get_or_insert(hyper::http::uri::PathAndQuery::from_static("/"));
    match hyper::Uri::from_parts(parts) {
        Ok(uri) => {
            *req.uri_mut() = uri;
            true
        }
        Err(_) => false,
    }
}

/// Check if a request is a gRPC request based on Content-Type header.
fn is_grpc_request<B>(req: &hyper::Request<B>) -> bool {
    req.headers()
        .get(hyper::header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok())
        .is_some_and(|ct| ct.starts_with("application/grpc"))
}

/// Enforces a between-frame timeout on an HTTP body.
/// Drops the inner body on timeout or completion to release its connection.
pub(crate) struct TimedBody<B> {
    inner: Option<B>,
    timeout: Duration,
    /// Armed only while a frame is actually being waited for, and cleared
    /// whenever one arrives. A clock that ran whether or not anybody was
    /// reading would count the time a guest spent doing something else against
    /// the peer sending the body.
    deadline: Option<std::pin::Pin<Box<tokio::time::Sleep>>>,
}

fn with_body_timeout<B>(req: hyper::Request<B>, timeout: Duration) -> hyper::Request<TimedBody<B>> {
    req.map(|body| TimedBody::new(body, timeout))
}

impl<B> TimedBody<B> {
    /// Wrap `inner`, erroring with `ConnectionReadTimeout` when a frame is
    /// awaited for longer than `between_bytes_timeout`.
    ///
    /// A zero timeout is honoured as the guest asks it — `wasi:http`
    /// request-options accept one — and means the next frame must already be
    /// ready or the body errors.
    pub(crate) fn new(inner: B, between_bytes_timeout: Duration) -> Self {
        Self {
            inner: Some(inner),
            timeout: between_bytes_timeout,
            deadline: None,
        }
    }
}

impl<B> hyper::body::Body for TimedBody<B>
where
    B: hyper::body::Body<Data = bytes::Bytes> + Unpin,
    B::Error: IntoBodyError,
{
    type Data = bytes::Bytes;
    type Error = wasmtime_wasi_http::Error;

    fn poll_frame(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Result<hyper::body::Frame<Self::Data>, Self::Error>>> {
        use std::task::{Poll, ready};
        use wasmtime_wasi_http::Error;

        let Some(inner) = self.inner.as_mut() else {
            return Poll::Ready(None);
        };
        match std::pin::Pin::new(inner).poll_frame(cx) {
            Poll::Ready(None) => {
                self.inner = None;
                Poll::Ready(None)
            }
            Poll::Ready(Some(Err(err))) => {
                self.inner = None;
                Poll::Ready(Some(Err(err.into_body_error())))
            }
            Poll::Ready(Some(Ok(frame))) => {
                // The wait is over, so the clock stops until the next one.
                self.deadline = None;
                Poll::Ready(Some(Ok(frame)))
            }
            Poll::Pending => {
                let timeout = self.timeout;
                let deadline = self
                    .deadline
                    .get_or_insert_with(|| Box::pin(tokio::time::sleep(timeout)));
                ready!(deadline.as_mut().poll(cx));
                // Release the connection before surfacing the timeout rather
                // than waiting for the guest to drop the body.
                self.inner = None;
                self.deadline = None;
                Poll::Ready(Some(Err(Error::ConnectionReadTimeout)))
            }
        }
    }

    fn is_end_stream(&self) -> bool {
        self.inner
            .as_ref()
            .is_none_or(hyper::body::Body::is_end_stream)
    }

    fn size_hint(&self) -> hyper::body::SizeHint {
        self.inner
            .as_ref()
            .map_or_else(hyper::body::SizeHint::default, hyper::body::Body::size_hint)
    }
}

/// A body error [`TimedBody`] can hand the guest: a network body's
/// `hyper::Error`, classified as wasmtime's default transport classifies it,
/// or an error a local dispatch already produced.
pub(crate) trait IntoBodyError {
    fn into_body_error(self) -> wasmtime_wasi_http::Error;
}

impl IntoBodyError for hyper::Error {
    fn into_body_error(self) -> wasmtime_wasi_http::Error {
        crate::host::http_client::connection_error(self)
    }
}

impl IntoBodyError for wasmtime_wasi_http::Error {
    fn into_body_error(self) -> Self {
        self
    }
}

/// Send a gRPC request over its own HTTP/2 connection. `tls` must already carry
/// the h2 ALPN (see [`h2_client_config`]).
async fn send_grpc_request(
    mut request: hyper::Request<WasiBody>,
    options: Option<RequestOptions>,
    tls: Arc<rustls::ClientConfig>,
) -> SendResult {
    use crate::host::http_client::{
        connect_http_tcp, connect_http_tls, request_authority, spawn_conn_worker, to_origin_form,
    };
    use tokio::time::timeout;
    use wasmtime_wasi_http::Error;

    let connect_timeout = options
        .and_then(|o| o.connect_timeout)
        .unwrap_or(Duration::from_secs(600));
    let first_byte_timeout = options
        .and_then(|o| o.first_byte_timeout)
        .unwrap_or(Duration::from_secs(600));
    let between_bytes_timeout = options
        .and_then(|o| o.between_bytes_timeout)
        .unwrap_or(Duration::from_secs(600));

    let use_tls = request.uri().scheme() == Some(&hyper::http::uri::Scheme::HTTPS);

    let authority = request_authority(&request, use_tls).ok_or(Error::HttpRequestUriInvalid)?;
    let tcp_stream = connect_http_tcp(&authority, connect_timeout).await?;

    let (mut sender, conn_worker) = if use_tls {
        // The cached gRPC TLS configuration is shared across workloads; give
        // this connection its own session store so TLS session tickets never
        // resume across workloads.
        let config = crate::host::http_client::isolated_resumption(&tls);
        let stream = connect_http_tls(Arc::new(config), &authority, tcp_stream).await?;
        let (sender, conn) = timeout(
            connect_timeout,
            http2::handshake(TokioExecutor::new(), TokioIo::new(stream)),
        )
        .await
        .map_err(|_| Error::ConnectionTimeout)??;
        (sender, spawn_conn_worker(conn))
    } else {
        let (sender, conn) = timeout(
            connect_timeout,
            http2::handshake(TokioExecutor::new(), TokioIo::new(tcp_stream)),
        )
        .await
        .map_err(|_| Error::ConnectionTimeout)??;
        (sender, spawn_conn_worker(conn))
    };

    to_origin_form(&mut request);

    let resp = timeout(first_byte_timeout, sender.send_request(request))
        .await
        .map_err(|_| Error::ConnectionReadTimeout)??
        .map(|body| TimedBody::new(body, between_bytes_timeout).boxed_unsync());

    // The connection driver *is* the request-error future: it must stay
    // pending while the guest reads the body (wasmtime keeps it alive for the
    // body's lifetime only while it polls pending — see `p3::host::handler` —
    // and the `AbortOnDropJoinHandle` aborts the connection when dropped), and
    // a connection failure propagates to the guest instead of being dropped.
    let io: RequestIoFuture = Box::new(conn_worker);
    Ok((resp, io))
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeSet;

    fn build_request(uri: &str) -> hyper::Request<WasiBody> {
        hyper::Request::builder()
            .uri(uri)
            .body(WasiBody::default())
            .unwrap()
    }

    #[test]
    fn ingress_uses_listener_scheme_for_absolute_uri() {
        let mut req = hyper::Request::builder()
            .uri("https://tenant.test/path")
            .header(hyper::header::HOST, "tenant.test")
            .body(())
            .unwrap();
        assert!(normalize_ingress_uri(
            &mut req,
            &hyper::http::uri::Scheme::HTTP
        ));
        assert_eq!(req.uri().scheme(), Some(&hyper::http::uri::Scheme::HTTP));
        assert_eq!(req.uri().authority().unwrap().as_str(), "tenant.test");
    }

    #[test]
    fn ingress_rejects_mismatched_host_and_uri_authority() {
        let mut req = hyper::Request::builder()
            .uri("https://other.test/path")
            .header(hyper::header::HOST, "tenant.test")
            .body(())
            .unwrap();
        assert!(!normalize_ingress_uri(
            &mut req,
            &hyper::http::uri::Scheme::HTTP
        ));
    }

    /// `with_quotas` rebuilds an eagerly-configured client cache and must
    /// carry the TLS configuration over — losing it would silently revert a
    /// host to the default trust roots.
    #[test]
    fn quota_builder_preserves_tls_config() {
        let tls = crate::host::http_client::ClientTlsOptions::default()
            .build()
            .unwrap();
        let handler = DefaultOutgoingHandler::with_tls_config(tls.clone()).with_quotas(
            crate::host::quota::QuotaRegistry::new(
                crate::host::quota::QuotaLimits {
                    outbound_http: 1,
                    ..Default::default()
                },
                Some(2),
            ),
        );
        let got = handler
            .client_tls_config()
            .expect("handler should expose its TLS configuration");
        assert!(
            Arc::ptr_eq(&tls, &got),
            "with_quotas must preserve the configured TLS roots"
        );
    }

    /// Spawn an HTTP/2-over-TLS server (h2 ALPN) whose certificate chains to a
    /// private CA (an IP SAN, so tests dial 127.0.0.1 directly), answering
    /// every request with `200 ok`. Returns the bound port and the CA PEM.
    async fn private_ca_h2_server() -> (u16, String) {
        crate::init_crypto();
        let certified_key =
            rcgen::generate_simple_self_signed(vec!["127.0.0.1".to_string()]).unwrap();
        let ca_pem = certified_key.cert.pem();
        let cert_der = certified_key.cert.der().clone();
        let key_der =
            rustls::pki_types::PrivateKeyDer::try_from(certified_key.signing_key.serialize_der())
                .unwrap();

        let mut server_config = ServerConfig::builder()
            .with_no_client_auth()
            .with_single_cert(vec![cert_der], key_der)
            .unwrap();
        server_config.alpn_protocols = vec![b"h2".to_vec()];
        let acceptor = TlsAcceptor::from(Arc::new(server_config));
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        tokio::spawn(async move {
            loop {
                let (stream, _) = match listener.accept().await {
                    Ok(accepted) => accepted,
                    Err(_) => return,
                };
                let acceptor = acceptor.clone();
                tokio::spawn(async move {
                    // Failed handshakes (the untrusted-CA case) just drop.
                    let Ok(tls) = acceptor.accept(stream).await else {
                        return;
                    };
                    let service = hyper::service::service_fn(
                        |_req: hyper::Request<hyper::body::Incoming>| async {
                            Ok::<_, std::convert::Infallible>(hyper::Response::new(
                                http_body_util::Full::new(bytes::Bytes::from_static(b"ok")),
                            ))
                        },
                    );
                    let _ = hyper::server::conn::http2::Builder::new(TokioExecutor::new())
                        .serve_connection(TokioIo::new(tls), service)
                        .await;
                });
            }
        });
        (port, ca_pem)
    }

    fn grpc_options() -> Option<RequestOptions> {
        Some(RequestOptions {
            connect_timeout: Some(Duration::from_secs(5)),
            first_byte_timeout: Some(Duration::from_secs(5)),
            between_bytes_timeout: Some(Duration::from_secs(5)),
        })
    }

    /// The gRPC egress fast path must verify TLS against the roots configured
    /// on the outgoing handler (with h2 ALPN layered on by
    /// [`h2_client_config`]), not the compiled-in webpki bundle — and the
    /// request I/O future it hands back must poll pending, so wasmtime keeps
    /// the connection alive while the guest reads the body.
    #[tokio::test]
    async fn grpc_path_picks_up_configured_roots() {
        use core::task::{Context as TaskContext, Waker};

        let (port, ca_pem) = private_ca_h2_server().await;
        let dir = tempfile::tempdir().unwrap();
        let ca_path = dir.path().join("ca.pem");
        std::fs::write(&ca_path, ca_pem).unwrap();
        let uri = format!("https://127.0.0.1:{port}/svc.Test/Call");

        // Default roots: the handshake must fail with a TLS error.
        let Err(err) = send_grpc_request(
            build_request(&uri),
            grpc_options(),
            h2_client_config(&crate::host::http_client::default_client_tls_config()),
        )
        .await
        else {
            panic!("untrusted CA must fail");
        };
        assert!(
            matches!(err, wasmtime_wasi_http::Error::TlsProtocolError),
            "expected TlsProtocolError, got {err:?}"
        );

        // Configured roots: the same request must succeed.
        let tls = crate::host::http_client::ClientTlsOptions {
            roots: crate::host::http_client::TrustRoots::ExtraOnly,
            extra_ca_paths: vec![ca_path],
            ..Default::default()
        }
        .build()
        .unwrap();
        let Ok((response, io)) =
            send_grpc_request(build_request(&uri), grpc_options(), h2_client_config(&tls)).await
        else {
            panic!("request with the private CA trusted should succeed");
        };
        assert_eq!(response.status(), 200);

        let mut io = Box::into_pin(io);
        assert!(
            io.as_mut()
                .poll(&mut TaskContext::from_waker(Waker::noop()))
                .is_pending(),
            "request-error future must stay pending so wasmtime ties it to the body"
        );

        // Drive it the way wasmtime does once it sees `Pending`.
        let io = wasmtime_wasi::runtime::spawn(io);
        let body = tokio::time::timeout(
            Duration::from_secs(3),
            BodyExt::collect(response.into_body()),
        )
        .await
        .expect("body read timed out")
        .expect("body read failed");
        assert_eq!(body.to_bytes().as_ref(), b"ok");
        drop(io);
    }

    /// Guards the P3 streaming regression fix: `run_http_server` must disable
    /// Nagle on accepted sockets. A streamed head-then-body response otherwise
    /// stalls ~40ms per request on the client's delayed ACK. The precondition
    /// asserts the socket starts with Nagle on, so this proves the helper
    /// actually flips it rather than reading a coincidental default.
    #[tokio::test]
    async fn accepted_connections_disable_nagle() {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let _client = TcpStream::connect(addr).await.unwrap();
        let (server, _) = listener.accept().await.unwrap();

        assert!(
            !server.nodelay().unwrap(),
            "precondition: a freshly accepted socket should start with Nagle enabled"
        );
        prepare_accepted_conn(&server);
        assert!(
            server.nodelay().unwrap(),
            "run_http_server must set TCP_NODELAY on accepted connections"
        );
    }

    /// However the accept loop ends, it has to be findable. It is spawned
    /// detached and nothing restarts it, so a host that only logged the exit
    /// holds every workload it was given, keeps answering its control plane,
    /// and serves no HTTP for the rest of its life.
    #[tokio::test]
    async fn a_stopped_accept_loop_is_observable_and_unrecoverable() {
        use crate::host::probes::ReadinessCheck as _;

        let ingress = Ingress::builder(DevRouter::default(), "127.0.0.1:0".parse().unwrap())
            .build()
            .await
            .unwrap();
        let limit = ingress.connection_limit();

        assert!(limit.accepting());
        assert!(limit.ready(), "a fresh ingress has room");
        assert!(!limit.unrecoverable());

        ingress.start().await.unwrap();
        assert!(
            tokio::time::timeout(Duration::from_millis(100), ingress.stopped())
                .await
                .is_err(),
            "a running accept loop must not report itself stopped"
        );

        ingress.stop().await.unwrap();
        tokio::time::timeout(Duration::from_secs(5), ingress.stopped())
            .await
            .expect("the accept loop's exit has to reach whoever is watching for it");

        assert!(!limit.accepting());
        assert!(!limit.ready());
        assert_eq!(limit.name(), "http_ingress_stopped");
        // The distinction from saturation: a full ingress empties, this does
        // not — so it is a reason to be replaced, not only to leave the Service.
        assert!(limit.unrecoverable());
    }

    /// A host at its ingress ceiling has to keep accepting and close what it
    /// cannot serve. Leaving the connections queued instead fills the listen
    /// backlog, and once that is full the kernel drops new handshakes — so a TCP
    /// liveness probe times out and a running host is killed as unreachable.
    #[tokio::test]
    async fn a_saturated_ingress_keeps_accepting() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let (shutdown_tx, mut shutdown_rx) = mpsc::channel::<()>(1);

        let server = tokio::spawn(async move {
            run_http_server(
                listener,
                Arc::new(DevRouter::default()),
                WorkloadHandles::default(),
                ServiceHandlers::default(),
                &mut shutdown_rx,
                None,
                Meters::default().guest(),
                ConnectionLimit::new(1),
            )
            .await
        });

        // Takes the only permit and holds it: nothing reads or writes, so the
        // server keeps the connection open.
        let _held = TcpStream::connect(addr).await.unwrap();

        // A real client has its request in flight by the time the ceiling is
        // checked, so the shed path has to survive unread bytes.
        let mut shed = TcpStream::connect(addr).await.unwrap();
        let _ = shed.write_all(b"GET / HTTP/1.1\r\nHost: x\r\n\r\n").await;
        let closed = tokio::time::timeout(Duration::from_secs(5), shed.read(&mut [0u8; 64])).await;
        match closed.expect("a connection past the ceiling must be closed, not left hanging") {
            Ok(0) => {}
            // The kernel answers unread bytes with an RST rather than a FIN.
            // Windows reports that as `ConnectionAborted` (WSAECONNABORTED).
            Err(e)
                if matches!(
                    e.kind(),
                    std::io::ErrorKind::ConnectionReset | std::io::ErrorKind::ConnectionAborted
                ) => {}
            Ok(n) => {
                panic!("the ceiling was not enforced: the shed connection was served {n} bytes")
            }
            Err(e) => panic!("expected the server to close the shed connection, got {e:?}"),
        }

        let _ = shutdown_tx.send(()).await;
        let _ = tokio::time::timeout(Duration::from_secs(5), server).await;
    }

    /// Wait for the ingress to reach `want` free permits, or fail saying what it
    /// reached instead. Bounded well past `FIRST_REQUEST_TIMEOUT` so a paused
    /// clock advances through the deadline under test.
    async fn await_permits(limit: &ConnectionLimit, want: usize, why: &str) {
        for _ in 0..2_000 {
            if limit.permits.available_permits() == want {
                return;
            }
            tokio::time::sleep(Duration::from_millis(50)).await;
        }
        panic!(
            "{why}: permits stayed at {}",
            limit.permits.available_permits()
        );
    }

    /// A busy host is not an unready one. The mark that takes it out of the
    /// Service is having nothing left to give, so a host serving every
    /// connection it holds stays in rotation however close to the ceiling it
    /// is — otherwise replicas at similar load leave together and the Service
    /// empties while every one of them is healthy.
    #[test]
    fn a_host_with_room_stays_ready_however_busy() {
        use crate::host::probes::ReadinessCheck as _;

        let limit = ConnectionLimit::new(100);
        let mut held = Vec::new();
        while limit.permits.available_permits() > 1 {
            held.push(limit.permits.clone().try_acquire_owned().unwrap());
        }
        assert!(
            limit.ready(),
            "99 of 100 connections in use is busy, not full"
        );

        held.push(limit.permits.clone().try_acquire_owned().unwrap());
        assert!(!limit.ready(), "no permits left is the host refusing work");
    }

    /// Recovery waits for real room. One freed permit would put a saturated
    /// host back into rotation a probe before it is full again.
    #[test]
    fn a_saturated_host_waits_for_room_before_returning() {
        use crate::host::probes::ReadinessCheck as _;

        let limit = ConnectionLimit::new(100);
        let mut held = Vec::new();
        while limit.permits.available_permits() > 0 {
            held.push(limit.permits.clone().try_acquire_owned().unwrap());
        }
        assert!(!limit.ready());

        held.truncate(held.len() - 9);
        assert!(!limit.ready(), "9 free of 100 is not yet the recovery mark");
        held.truncate(held.len() - 1);
        assert!(limit.ready(), "10 free of 100 clears it");
    }

    /// The smallest ceiling there is. Its recovery mark has to be reachable, or
    /// a host started with one connection never returns after its first.
    #[test]
    fn a_ceiling_of_one_recovers() {
        use crate::host::probes::ReadinessCheck as _;

        let limit = ConnectionLimit::new(1);
        assert!(limit.ready(), "idle with its one connection free");
        let only = limit.permits.clone().try_acquire_owned().unwrap();
        assert!(!limit.ready(), "its one connection is in use");
        drop(only);
        assert!(limit.ready(), "and free again");
    }

    /// The connection future is boxed, and a real serving failure has to stay
    /// an `ERROR` however deep the chain gets. Only the hyper error at the
    /// bottom of it decides, and a chain that has none is not a timeout.
    #[test]
    fn a_served_error_that_is_not_a_timeout_stays_an_error() {
        #[derive(Debug)]
        struct Wrapped(std::io::Error);
        impl std::fmt::Display for Wrapped {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(f, "wrapped")
            }
        }
        impl std::error::Error for Wrapped {
            fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
                Some(&self.0)
            }
        }

        let reset = std::io::Error::from(std::io::ErrorKind::ConnectionReset);
        assert!(!ended_in_timeout(&reset), "a reset is not a timeout");
        assert!(
            !ended_in_timeout(&Wrapped(std::io::Error::from(
                std::io::ErrorKind::ConnectionReset
            ))),
            "and neither is one behind a wrapper"
        );
        // A chain with no hyper error in it must terminate rather than recurse
        // on itself.
        assert!(!ended_in_timeout(&Wrapped(std::io::Error::other("x"))));
    }

    /// A connection that never asks for anything must give its slot back.
    ///
    /// hyper decides h1 vs h2 by reading up to 24 preface bytes, and that read
    /// has no timeout of its own — a peer sending nothing, or half a preface,
    /// parks there. Holding a ceiling slot the whole time turns a handful of
    /// silent peers into a host that reports itself full, which the readiness
    /// check then reports to Kubernetes as a reason to take it out of service.
    #[tokio::test(start_paused = true)]
    async fn a_connection_that_never_speaks_gives_its_slot_back() {
        use tokio::io::AsyncWriteExt;

        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let (_shutdown_tx, mut shutdown_rx) = mpsc::channel::<()>(1);
        let limit = ConnectionLimit::new(1);

        let served = limit.clone();
        tokio::spawn(async move {
            run_http_server(
                listener,
                Arc::new(DevRouter::default()),
                WorkloadHandles::default(),
                ServiceHandlers::default(),
                &mut shutdown_rx,
                None,
                Meters::default().guest(),
                served,
            )
            .await
        });

        // Half an HTTP/2 preface: enough that the connection is not idle, not
        // enough for hyper to decide what it is.
        let mut silent = TcpStream::connect(addr).await.unwrap();
        silent.write_all(b"PRI * HTTP/2.0").await.unwrap();

        // Polled rather than slept on: the paused clock advances the moment this
        // task idles, which can be before the OS has delivered accept readiness.
        await_permits(&limit, 0, "the silent connection should hold the only slot").await;
        await_permits(
            &limit,
            1,
            "a connection that sent no request must not hold its slot forever",
        )
        .await;
    }

    // --- check_allowed_hosts tests ---

    fn hosts(entries: &[&str]) -> Vec<AllowedHost> {
        entries.iter().map(|s| s.parse().unwrap()).collect()
    }

    #[test]
    fn empty_allowed_hosts_denies_all() {
        // An empty policy means no egress. To opt into allow-all
        // the caller must pass an explicit `[AllowedHost::Any]`.
        let req = build_request("http://anything.example.com/path");
        let err = check_allowed_hosts(&req, &[]).unwrap_err();
        assert!(err.to_string().contains("deny-all"), "{}", err.to_string());
    }

    #[test]
    fn explicit_any_permits_anything() {
        let req = build_request("http://anything.example.com/path");
        assert!(check_allowed_hosts(&req, &hosts(&["*"])).is_ok());
    }

    #[test]
    fn exact_match_works() {
        let req = build_request("http://example.com/path");
        assert!(check_allowed_hosts(&req, &hosts(&["example.com"])).is_ok());
    }

    #[test]
    fn exact_match_is_case_insensitive() {
        let req = build_request("http://example.com/path");
        assert!(check_allowed_hosts(&req, &hosts(&["Example.COM"])).is_ok());
    }

    #[test]
    fn wildcard_matches_subdomain() {
        let req = build_request("http://sub.example.com/path");
        assert!(check_allowed_hosts(&req, &hosts(&["*.example.com"])).is_ok());
    }

    #[test]
    fn wildcard_does_not_match_bare_domain() {
        let req = build_request("http://example.com/path");
        assert!(check_allowed_hosts(&req, &hosts(&["*.example.com"])).is_err());
    }

    #[test]
    fn wildcard_is_case_insensitive() {
        let req = build_request("http://sub.example.com/path");
        assert!(check_allowed_hosts(&req, &hosts(&["*.Example.COM"])).is_ok());
    }

    #[test]
    fn non_matching_host_is_rejected() {
        let req = build_request("http://evil.com/path");
        let err = check_allowed_hosts(&req, &hosts(&["example.com"])).unwrap_err();
        assert!(err.to_string().contains("not allowed"));
    }

    #[test]
    fn request_with_no_host_returns_error() {
        let req = build_request("/path-only");
        let err = check_allowed_hosts(&req, &hosts(&["example.com"])).unwrap_err();
        assert!(err.to_string().contains("no host"));
    }

    #[test]
    fn star_any_matches_everything() {
        let req = build_request("http://anything.example.com/path");
        assert!(check_allowed_hosts(&req, &hosts(&["*"])).is_ok());
    }

    #[test]
    fn url_policy_pins_scheme() {
        let req = build_request("http://api.example.com/path");
        assert!(check_allowed_hosts(&req, &hosts(&["https://api.example.com"])).is_err());
    }

    // --- error_response tests ---

    #[test]
    fn error_response_returns_correct_status() {
        assert_eq!(error_response(404).status(), 404);
        assert_eq!(error_response(500).status(), 500);
    }

    // --- split_host_port tests ---

    #[test]
    fn split_host_port_bare_host() {
        assert_eq!(split_host_port("example.com"), ("example.com", None));
    }

    #[test]
    fn split_host_port_host_with_port() {
        assert_eq!(
            split_host_port("example.com:8080"),
            ("example.com", Some(8080))
        );
    }

    #[test]
    fn split_host_port_ipv4_with_port() {
        assert_eq!(split_host_port("10.1.2.80:443"), ("10.1.2.80", Some(443)));
    }

    #[test]
    fn split_host_port_ipv6_with_port() {
        assert_eq!(split_host_port("[::1]:8080"), ("::1", Some(8080)));
    }

    #[test]
    fn split_host_port_ipv6_without_port() {
        assert_eq!(split_host_port("[2001:db8::1]"), ("2001:db8::1", None));
    }

    #[test]
    fn split_host_port_invalid_port_is_dropped() {
        // Non-numeric port can't be parsed; address is still returned.
        assert_eq!(
            split_host_port("example.com:notaport"),
            ("example.com", None)
        );
    }

    // --- OutgoingHandler delegation tests ---

    fn no_io() -> RequestIoFuture {
        Box::new(async { Ok(()) })
    }

    struct SpyHandler {
        called: Arc<std::sync::atomic::AtomicBool>,
    }

    impl OutgoingHandler for SpyHandler {
        fn send_request(
            &self,
            _workload_id: &str,
            _request: hyper::Request<WasiBody>,
            _options: Option<RequestOptions>,
            _fut: RequestIoFuture,
        ) -> SendFuture {
            self.called.store(true, std::sync::atomic::Ordering::SeqCst);
            Box::new(async {
                Err(wasmtime_wasi_http::Error::InternalError(Some(
                    "spy: no real request".to_string(),
                )))
            })
        }
    }

    #[tokio::test]
    async fn custom_outgoing_handler_is_invoked() {
        let called = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let server = Ingress::builder(DevRouter::default(), "127.0.0.1:0".parse().unwrap())
            .outgoing_handler(SpyHandler {
                called: called.clone(),
            })
            .build()
            .await
            .unwrap();
        let request = build_request("http://example.com/");
        // Explicit `[Any]` policy so the deny-all-on-empty default doesn't
        // short-circuit before reaching the spy.
        let allow_any = [AllowedHost::Any];
        let _ = server.outgoing_request("test-workload", request, None, no_io(), &allow_any);
        assert!(called.load(std::sync::atomic::Ordering::SeqCst));
    }

    /// A router that cannot forget a workload.
    struct UnbindFailingRouter;

    #[async_trait::async_trait]
    impl Router for UnbindFailingRouter {
        async fn on_workload_resolved(
            &self,
            _resolved_handle: &ResolvedWorkload,
            _component_id: &str,
        ) -> anyhow::Result<()> {
            Ok(())
        }

        async fn on_workload_unbind(&self, _workload_id: &str) -> anyhow::Result<()> {
            anyhow::bail!("router unavailable")
        }

        fn allow_outgoing_request(
            &self,
            _workload_id: &str,
            _request: &hyper::Request<WasiBody>,
            _options: Option<RequestOptions>,
            _allowed_hosts: &[AllowedHost],
        ) -> anyhow::Result<()> {
            Ok(())
        }

        fn route_incoming_request(
            &self,
            _req: &hyper::Request<hyper::body::Incoming>,
        ) -> Result<String, RouteError> {
            Err(RouteError::MissingHost)
        }
    }

    /// Records the workloads whose egress state it was told to drop.
    #[derive(Clone, Default)]
    struct UnbindSpy {
        unbound: Arc<std::sync::Mutex<Vec<String>>>,
    }

    impl OutgoingHandler for UnbindSpy {
        fn send_request(
            &self,
            _workload_id: &str,
            _request: hyper::Request<WasiBody>,
            _options: Option<RequestOptions>,
            _fut: RequestIoFuture,
        ) -> SendFuture {
            Box::new(async {
                Err(wasmtime_wasi_http::Error::InternalError(Some(
                    "spy: no real request".to_string(),
                )))
            })
        }

        fn on_workload_unbind(&self, workload_id: &str) {
            self.unbound.lock().unwrap().push(workload_id.to_string());
        }
    }

    /// The router failing to forget a workload still reports the failure, but
    /// does not keep the ingress's handlers or egress state for it alive.
    #[tokio::test]
    async fn a_failing_router_unbind_still_releases_the_workload() {
        let spy = UnbindSpy::default();
        let server = Ingress::builder(UnbindFailingRouter, "127.0.0.1:0".parse().unwrap())
            .outgoing_handler(spy.clone())
            .build()
            .await
            .unwrap();
        let (sender, _receiver) = tokio::sync::mpsc::channel(1);
        server
            .on_service_http_resolved("wl", &[], sender)
            .await
            .unwrap();

        assert!(server.on_workload_unbind("wl").await.is_err());
        assert!(server.service_handlers.read().await.is_empty());
        assert_eq!(*spy.unbound.lock().unwrap(), ["wl"]);

        let (sender, _receiver) = tokio::sync::mpsc::channel(1);
        server
            .on_service_http_resolved("wl", &[], sender)
            .await
            .unwrap();
        assert!(server.on_service_http_unbind("wl").await.is_err());
        assert!(server.service_handlers.read().await.is_empty());
    }

    /// A request the policy refuses must reach the guest as
    /// `http-request-denied`, and must not reach the transport at all.
    ///
    /// wasmtime 48 removed the host's ability to trap out of the outgoing-handler
    /// hook, so a `wasi:http` 0.2 guest now receives this as a handleable error
    /// where it used to be killed by a trap — the same semantics 0.3 always had.
    /// Both versions take this path, so the code is pinned here.
    #[tokio::test]
    async fn a_denied_request_reports_denial_and_never_reaches_the_transport() {
        let called = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let server = Ingress::builder(DevRouter::default(), "127.0.0.1:0".parse().unwrap())
            .outgoing_handler(SpyHandler {
                called: called.clone(),
            })
            .build()
            .await
            .unwrap();
        let request = build_request("http://example.com/");
        // An empty policy denies everything.
        let result =
            Box::into_pin(server.outgoing_request("test-workload", request, None, no_io(), &[]))
                .await;
        assert!(
            matches!(result, Err(wasmtime_wasi_http::Error::HttpRequestDenied)),
            "a denied request should report `http-request-denied`"
        );
        assert!(
            !called.load(std::sync::atomic::Ordering::SeqCst),
            "a denied request must not reach the outgoing handler"
        );
    }

    /// The body of a denied request is drained rather than dropped: a guest that
    /// uploads while awaiting the response would otherwise see its stream close
    /// and report that instead of the denial.
    #[tokio::test]
    async fn a_denied_request_drains_its_body() {
        let server = Ingress::builder(DevRouter::default(), "127.0.0.1:0".parse().unwrap())
            .build()
            .await
            .unwrap();
        // A body whose frames are pulled only if someone drains it.
        struct ChannelBody(
            tokio::sync::mpsc::Receiver<
                Result<hyper::body::Frame<bytes::Bytes>, wasmtime_wasi_http::Error>,
            >,
        );
        impl hyper::body::Body for ChannelBody {
            type Data = bytes::Bytes;
            type Error = wasmtime_wasi_http::Error;
            fn poll_frame(
                mut self: std::pin::Pin<&mut Self>,
                cx: &mut std::task::Context<'_>,
            ) -> std::task::Poll<Option<Result<hyper::body::Frame<Self::Data>, Self::Error>>>
            {
                self.0.poll_recv(cx)
            }
        }

        let (tx, rx) = tokio::sync::mpsc::channel(1);
        let body: WasiBody = ChannelBody(rx).boxed_unsync();
        let request = hyper::Request::builder()
            .uri("http://example.com/")
            .body(body)
            .unwrap();

        let denied =
            Box::into_pin(server.outgoing_request("test-workload", request, None, no_io(), &[]))
                .await;
        assert!(matches!(
            denied,
            Err(wasmtime_wasi_http::Error::HttpRequestDenied)
        ));

        // The drain is what keeps this send from failing: nothing else is
        // reading, and the channel has capacity for one frame only.
        for _ in 0..4 {
            tokio::time::timeout(
                Duration::from_secs(5),
                tx.send(Ok(hyper::body::Frame::data(bytes::Bytes::from_static(
                    b"upload",
                )))),
            )
            .await
            .expect("a denied request should keep draining its body")
            .expect("the drain should still be listening");
        }
    }

    /// A request whose body the test uploads by hand, and the sender for it.
    fn upload_request() -> (
        tokio::sync::mpsc::Sender<
            Result<hyper::body::Frame<bytes::Bytes>, wasmtime_wasi_http::Error>,
        >,
        hyper::Request<WasiBody>,
    ) {
        struct ChannelBody(
            tokio::sync::mpsc::Receiver<
                Result<hyper::body::Frame<bytes::Bytes>, wasmtime_wasi_http::Error>,
            >,
        );
        impl hyper::body::Body for ChannelBody {
            type Data = bytes::Bytes;
            type Error = wasmtime_wasi_http::Error;
            fn poll_frame(
                mut self: std::pin::Pin<&mut Self>,
                cx: &mut std::task::Context<'_>,
            ) -> std::task::Poll<Option<Result<hyper::body::Frame<Self::Data>, Self::Error>>>
            {
                self.0.poll_recv(cx)
            }
        }
        let (tx, rx) = tokio::sync::mpsc::channel(1);
        let request = hyper::Request::builder()
            .uri("http://callee.internal/")
            .body(ChannelBody(rx).boxed_unsync())
            .unwrap();
        (tx, request)
    }

    /// An ingress whose guests may hold at most `limit` outbound requests.
    async fn ingress_with_outbound_limit(limit: usize) -> Ingress<DevRouter> {
        Ingress::builder(DevRouter::default(), "127.0.0.1:0".parse().unwrap())
            .quotas(crate::host::quota::QuotaRegistry::new(
                crate::host::quota::QuotaLimits {
                    outbound_http: limit,
                    ..Default::default()
                },
                None,
            ))
            .build()
            .await
            .unwrap()
    }

    /// A co-located service that answers every request without reading its
    /// body, dropping it first.
    fn early_answering_service() -> LocalTarget {
        let (sender, mut jobs) = tokio::sync::mpsc::channel::<ServiceHttpJob>(8);
        tokio::spawn(async move {
            while let Some(job) = jobs.recv().await {
                drop(job.req);
                let body = http_body_util::Empty::new()
                    .map_err(|never| match never {})
                    .boxed_unsync();
                let _ = job.resp_tx.send(Ok(hyper::Response::new(body)));
            }
        });
        LocalTarget::Service(sender)
    }

    async fn upload(
        tx: &tokio::sync::mpsc::Sender<
            Result<hyper::body::Frame<bytes::Bytes>, wasmtime_wasi_http::Error>,
        >,
    ) -> Result<(), &'static str> {
        tokio::time::timeout(
            Duration::from_secs(5),
            tx.send(Ok(hyper::body::Frame::data(bytes::Bytes::from_static(
                b"upload",
            )))),
        )
        .await
        .map_err(|_| "nothing is reading the upload")?
        .map_err(|_| "the upload was closed")
    }

    /// A callee that answers without reading must not close the caller's
    /// upload (the caller would see "connection reset"), and the request's
    /// response timeouts must not close it either: a caller may pause its
    /// upload past them, as it can on the network.
    #[tokio::test]
    async fn a_local_upload_outlives_an_early_response_and_its_timeouts() {
        let server = Ingress::builder(DevRouter::default(), "127.0.0.1:0".parse().unwrap())
            .build()
            .await
            .unwrap();
        let (tx, request) = upload_request();
        let response_timeout = Duration::from_millis(50);
        let options = RequestOptions {
            first_byte_timeout: Some(response_timeout),
            between_bytes_timeout: Some(response_timeout),
            ..Default::default()
        };

        let (response, _io) = Box::into_pin(server.send_local_request(
            "caller",
            "callee".to_string(),
            early_answering_service(),
            request,
            Some(options),
        ))
        .await
        .expect("the early response should arrive");
        assert_eq!(response.status(), 200);
        drop(response);

        tokio::time::sleep(response_timeout * 4).await;
        for _ in 0..4 {
            upload(&tx).await.expect("the upload should stay open");
        }
    }

    /// The upload drain holds the request's outbound slot until the upload
    /// ends, so early responses can't leave more drains open than the quota.
    #[tokio::test]
    async fn local_upload_drains_count_against_the_outbound_quota() {
        let limit = 2;
        let server = ingress_with_outbound_limit(limit).await;
        let send = |request| {
            Box::into_pin(server.send_local_request(
                "caller",
                "callee".to_string(),
                early_answering_service(),
                request,
                None,
            ))
        };

        // Each early response leaves its upload open and its drain running.
        let mut uploads = Vec::new();
        for _ in 0..limit {
            let (tx, request) = upload_request();
            let (response, _io) = send(request).await.expect("within the quota");
            drop(response);
            uploads.push(tx);
        }
        let (_tx, request) = upload_request();
        assert!(
            matches!(
                send(request).await,
                Err(wasmtime_wasi_http::Error::ConnectionLimitReached)
            ),
            "open drains must hold their slots after the responses are gone"
        );

        // Ending one upload ends its drain and frees its slot.
        drop(uploads.pop());
        let freed = tokio::time::timeout(Duration::from_secs(5), async {
            loop {
                let (_tx, request) = upload_request();
                if send(request).await.is_ok() {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(10)).await;
            }
        })
        .await;
        assert!(freed.is_ok(), "an ended upload should free its slot");
    }

    /// A local dispatch that fails leaves nothing to drain for: the upload is
    /// closed, as a failed network send closes its body, and its slot freed.
    #[tokio::test]
    async fn a_failed_local_dispatch_closes_the_upload_and_frees_its_slot() {
        let server = ingress_with_outbound_limit(1).await;
        // A service that drops the body and then the request without answering.
        let (sender, mut jobs) = tokio::sync::mpsc::channel::<ServiceHttpJob>(1);
        tokio::spawn(async move {
            while let Some(job) = jobs.recv().await {
                drop(job.req);
                drop(job.resp_tx);
            }
        });

        let (tx, request) = upload_request();
        let failed = Box::into_pin(server.send_local_request(
            "caller",
            "callee".to_string(),
            LocalTarget::Service(sender),
            request,
            None,
        ))
        .await;
        assert!(failed.is_err(), "the dispatch should fail");
        tokio::time::timeout(Duration::from_secs(5), tx.closed())
            .await
            .expect("a failed dispatch should close the upload");

        let (_tx, request) = upload_request();
        let (_response, _io) = Box::into_pin(server.send_local_request(
            "caller",
            "callee".to_string(),
            early_answering_service(),
            request,
            None,
        ))
        .await
        .expect("the failed dispatch should have freed its slot");
    }

    /// A queued dispatch timeout closes the upload and returns its slot.
    #[tokio::test]
    async fn a_timed_out_queued_dispatch_closes_the_upload_and_releases_its_slot() {
        let server = ingress_with_outbound_limit(1).await;
        // Alive, so the job is accepted, but never polled.
        let (sender, mut queued) = tokio::sync::mpsc::channel::<ServiceHttpJob>(8);
        let options = RequestOptions {
            first_byte_timeout: Some(Duration::from_millis(50)),
            ..Default::default()
        };

        let (tx, request) = upload_request();
        upload(&tx).await.expect("the first frame should fit");
        let timed_out = Box::into_pin(server.send_local_request(
            "caller",
            "callee".to_string(),
            LocalTarget::Service(sender),
            request,
            Some(options),
        ))
        .await;
        assert!(
            matches!(
                timed_out,
                Err(wasmtime_wasi_http::Error::ConnectionReadTimeout)
            ),
            "the queued dispatch should time out"
        );
        tokio::time::timeout(Duration::from_secs(5), tx.closed())
            .await
            .expect("the timeout should close the queued upload");
        assert!(upload(&tx).await.is_err(), "further writes should fail");
        let mut body = queued.recv().await.unwrap().req.into_body();
        assert!(!hyper::body::Body::is_end_stream(&body));
        assert!(matches!(
            body.frame().await,
            Some(Err(wasmtime_wasi_http::Error::ConnectionTerminated))
        ));
        assert!(hyper::body::Body::is_end_stream(&body));
        assert!(body.frame().await.is_none(), "the error should appear once");

        let (_tx, request) = upload_request();
        let (_response, _io) = Box::into_pin(server.send_local_request(
            "caller",
            "callee".to_string(),
            early_answering_service(),
            request,
            None,
        ))
        .await
        .expect("the timed-out dispatch should have released its slot");
    }

    #[tokio::test]
    async fn an_empty_local_upload_finishes_while_the_response_holds_its_slot() {
        let server = ingress_with_outbound_limit(1).await;
        let send = || {
            Box::into_pin(server.send_local_request(
                "caller",
                "callee".to_string(),
                early_answering_service(),
                hyper::Request::new(WasiBody::default()),
                None,
            ))
        };

        let (response, io) = send().await.expect("the response should arrive");
        tokio::time::timeout(Duration::from_secs(5), Box::into_pin(io))
            .await
            .expect("the empty upload should finish before the response is dropped")
            .expect("the empty upload should succeed");
        assert!(matches!(
            send().await,
            Err(wasmtime_wasi_http::Error::ConnectionLimitReached)
        ));
        drop(response);
        let (_response, _io) = send()
            .await
            .expect("dropping the response should free the slot");
    }

    #[tokio::test]
    async fn a_dropped_queued_dispatch_closes_the_upload() {
        let server = Ingress::builder(DevRouter::default(), "127.0.0.1:0".parse().unwrap())
            .build()
            .await
            .unwrap();
        let (sender, mut queued) = tokio::sync::mpsc::channel::<ServiceHttpJob>(1);
        let (tx, request) = upload_request();
        let mut send = Box::into_pin(server.send_local_request(
            "caller",
            "callee".to_string(),
            LocalTarget::Service(sender),
            request,
            None,
        ));
        assert!(futures::poll!(send.as_mut()).is_pending());
        assert_eq!(queued.len(), 1, "the request should still be queued");

        drop(send);
        assert!(tx.is_closed(), "cancellation should close the upload");
        let mut body = queued.recv().await.unwrap().req.into_body();
        assert!(!hyper::body::Body::is_end_stream(&body));
        assert!(matches!(
            body.frame().await,
            Some(Err(wasmtime_wasi_http::Error::ConnectionTerminated))
        ));
        assert!(body.frame().await.is_none(), "the error should appear once");
    }

    #[tokio::test]
    async fn closing_a_local_upload_wakes_a_pending_reader() {
        let (tx, request) = upload_request();
        let (body, _upload) = crate::host::http_client::UploadProbe::new(request.into_body());
        let slot = crate::host::quota::GuestConnectionQuota::new(Default::default(), None)
            .try_acquire_outbound_http()
            .unwrap();
        let closer = LocalRequest::new(slot, body);
        let mut body = DrainOnDrop::new(closer.clone());
        let (started_tx, started_rx) = tokio::sync::oneshot::channel();
        let reader = tokio::spawn(async move {
            let mut frame = Box::pin(body.frame());
            assert!(futures::poll!(frame.as_mut()).is_pending());
            started_tx.send(()).unwrap();
            frame.await
        });
        started_rx.await.unwrap();

        closer.fail();
        let frame = tokio::time::timeout(Duration::from_secs(5), reader)
            .await
            .expect("closing the upload should wake the reader")
            .unwrap();
        assert!(matches!(
            frame,
            Some(Err(wasmtime_wasi_http::Error::ConnectionTerminated))
        ));
        assert!(tx.is_closed(), "closing the body should close its writer");
    }

    #[test]
    fn a_failed_upload_dropped_unread_needs_no_drain() {
        let (_tx, request) = upload_request();
        let (body, _upload) = crate::host::http_client::UploadProbe::new(request.into_body());
        let slot = crate::host::quota::GuestConnectionQuota::new(Default::default(), None)
            .try_acquire_outbound_http()
            .unwrap();
        let request = LocalRequest::new(slot, body);
        assert!(request.needs_drain(), "an open upload should be drained");

        request.fail();
        assert!(
            !request.needs_drain(),
            "a failed upload has nothing to drain"
        );
        assert!(
            request.is_end_stream(),
            "the dropped failure should be released"
        );
    }

    #[tokio::test]
    async fn a_timed_out_partial_upload_errors_at_the_callee() {
        let server = Ingress::builder(DevRouter::default(), "127.0.0.1:0".parse().unwrap())
            .build()
            .await
            .unwrap();
        let (sender, mut jobs) = tokio::sync::mpsc::channel::<ServiceHttpJob>(1);
        let (read_tx, read_rx) = tokio::sync::oneshot::channel();
        tokio::spawn(async move {
            let job = jobs.recv().await.unwrap();
            let mut body = job.req.into_body();
            assert_eq!(
                body.frame().await.unwrap().unwrap().into_data().unwrap(),
                bytes::Bytes::from_static(b"upload")
            );
            let _ = read_tx.send(body.frame().await);
            drop(job.resp_tx);
        });

        let (tx, request) = upload_request();
        upload(&tx).await.expect("the first frame should fit");
        let sent = Box::into_pin(server.send_local_request(
            "caller",
            "callee".to_string(),
            LocalTarget::Service(sender),
            request,
            Some(RequestOptions {
                first_byte_timeout: Some(Duration::from_millis(50)),
                ..Default::default()
            }),
        ))
        .await;
        assert!(matches!(
            sent,
            Err(wasmtime_wasi_http::Error::ConnectionReadTimeout)
        ));
        let read = tokio::time::timeout(Duration::from_secs(5), read_rx)
            .await
            .expect("the callee should see the upload fail")
            .unwrap();
        assert!(matches!(
            read,
            Some(Err(wasmtime_wasi_http::Error::ConnectionTerminated))
        ));
        assert!(tx.is_closed());
    }

    /// A callee that drops the body and then works before answering must not
    /// stall the upload: writes past the channel's capacity complete before
    /// the response exists.
    #[tokio::test]
    async fn a_dropped_local_body_drains_while_the_callee_works() {
        let server = Ingress::builder(DevRouter::default(), "127.0.0.1:0".parse().unwrap())
            .build()
            .await
            .unwrap();
        let (respond_tx, respond_rx) = tokio::sync::oneshot::channel::<()>();
        let (sender, mut jobs) = tokio::sync::mpsc::channel::<ServiceHttpJob>(1);
        tokio::spawn(async move {
            let Some(job) = jobs.recv().await else {
                return;
            };
            drop(job.req);
            let _ = respond_rx.await;
            let body = http_body_util::Empty::new()
                .map_err(|never| match never {})
                .boxed_unsync();
            let _ = job.resp_tx.send(Ok(hyper::Response::new(body)));
        });

        let (tx, request) = upload_request();
        let send = Box::into_pin(server.send_local_request(
            "caller",
            "callee".to_string(),
            LocalTarget::Service(sender),
            request,
            None,
        ));
        let writer = async move {
            // The upload channel holds one frame; the rest need the drain.
            for _ in 0..8 {
                upload(&tx)
                    .await
                    .expect("writes should complete before the response");
            }
            let _ = respond_tx.send(());
            tx
        };
        let (sent, _tx) = tokio::join!(send, writer);
        let (_response, _io) = sent.expect("the response should arrive after the writes");
    }

    #[tokio::test]
    async fn denied_body_drain_stops_at_deadline() {
        use std::sync::atomic::{AtomicBool, Ordering};

        struct PendingBody(Arc<AtomicBool>);
        impl Drop for PendingBody {
            fn drop(&mut self) {
                self.0.store(true, Ordering::SeqCst);
            }
        }
        impl hyper::body::Body for PendingBody {
            type Data = bytes::Bytes;
            type Error = wasmtime_wasi_http::Error;

            fn poll_frame(
                self: std::pin::Pin<&mut Self>,
                _cx: &mut std::task::Context<'_>,
            ) -> std::task::Poll<Option<Result<hyper::body::Frame<Self::Data>, Self::Error>>>
            {
                std::task::Poll::Pending
            }
        }

        let dropped = Arc::new(AtomicBool::new(false));
        drain_denied_body(
            PendingBody(Arc::clone(&dropped)).boxed_unsync(),
            Duration::from_millis(10),
        )
        .await;
        assert!(dropped.load(Ordering::SeqCst));
    }

    /// gRPC requests must bypass the OutgoingHandler and go directly to
    /// send_grpc_request, so the spy must NOT be called.
    #[tokio::test]
    async fn grpc_requests_bypass_outgoing_handler() {
        let called = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let server = Ingress::builder(DevRouter::default(), "127.0.0.1:0".parse().unwrap())
            .outgoing_handler(SpyHandler {
                called: called.clone(),
            })
            .build()
            .await
            .unwrap();
        let request = hyper::Request::builder()
            .uri("http://example.com/")
            .header(hyper::header::CONTENT_TYPE, "application/grpc")
            .body(WasiBody::default())
            .unwrap();
        // `[Any]` lets the policy check pass so the test actually verifies
        // the gRPC dispatch path. With `&[]` (deny-all), the spy would
        // appear "not called" because policy denied — for the wrong reason.
        let allow_any = [AllowedHost::Any];
        let _ = server.outgoing_request("test-workload", request, None, no_io(), &allow_any);
        assert!(!called.load(std::sync::atomic::Ordering::SeqCst));
    }

    /// When the between-bytes timeout fires, [`TimedBody`] must surface
    /// `ConnectionReadTimeout` *and* eagerly drop the inner body so the
    /// underlying connection is released immediately rather than lingering
    /// until the guest drops its body handle.
    #[tokio::test]
    async fn timed_body_releases_inner_on_between_bytes_timeout() {
        use http_body_util::BodyExt;
        use std::sync::atomic::{AtomicBool, Ordering};

        // A body that never yields a frame — guarantees the between-bytes
        // timeout fires. Its `Drop` flips a flag so the test can prove the
        // inner body (and thus its connection) is released.
        struct NeverBody {
            dropped: Arc<AtomicBool>,
        }
        impl Drop for NeverBody {
            fn drop(&mut self) {
                self.dropped.store(true, Ordering::SeqCst);
            }
        }
        impl hyper::body::Body for NeverBody {
            type Data = bytes::Bytes;
            type Error = hyper::Error;
            fn poll_frame(
                self: std::pin::Pin<&mut Self>,
                _cx: &mut std::task::Context<'_>,
            ) -> std::task::Poll<Option<Result<hyper::body::Frame<Self::Data>, Self::Error>>>
            {
                std::task::Poll::Pending
            }
        }

        let dropped = Arc::new(AtomicBool::new(false));
        let mut body = with_body_timeout(
            hyper::Request::new(NeverBody {
                dropped: dropped.clone(),
            }),
            Duration::from_millis(10),
        )
        .into_body();

        // Awaiting the next frame parks on the interval until the timeout
        // elapses, then yields the timeout error.
        match body.frame().await {
            Some(Err(wasmtime_wasi_http::Error::ConnectionReadTimeout)) => {}
            other => panic!("expected ConnectionReadTimeout, got {other:?}"),
        }
        assert!(
            body.inner.is_none(),
            "inner body should be dropped from the wrapper on timeout"
        );
        assert!(
            dropped.load(Ordering::SeqCst),
            "inner body (and its connection) should be released eagerly on timeout"
        );
    }

    /// `MeteredBody` must tally the bytes of data frames (excluding trailers)
    /// and record the total once the body completes.
    #[tokio::test]
    async fn metered_body_counts_data_frame_bytes_excluding_trailers() {
        use http_body_util::BodyExt;

        struct FramesBody {
            frames: std::collections::VecDeque<hyper::body::Frame<bytes::Bytes>>,
        }
        impl hyper::body::Body for FramesBody {
            type Data = bytes::Bytes;
            type Error = wasmtime_wasi_http::Error;
            fn poll_frame(
                mut self: std::pin::Pin<&mut Self>,
                _cx: &mut std::task::Context<'_>,
            ) -> std::task::Poll<Option<Result<hyper::body::Frame<Self::Data>, Self::Error>>>
            {
                std::task::Poll::Ready(self.frames.pop_front().map(Ok))
            }
        }

        let frames = [
            hyper::body::Frame::data(bytes::Bytes::from_static(b"ab")),
            hyper::body::Frame::data(bytes::Bytes::from_static(b"cde")),
            // Trailers carry no body bytes and must not be counted.
            hyper::body::Frame::trailers(hyper::HeaderMap::new()),
        ]
        .into_iter()
        .collect();
        let inner: WasiBody = FramesBody { frames }.boxed_unsync();

        let mut body = MeteredBody::new(inner, tracing::Span::none());
        while body.frame().await.is_some() {}

        assert_eq!(body.bytes, 5, "should count 2 + 3 data bytes, not trailers");
        assert!(
            body.recorded,
            "size should be recorded once the body completes"
        );
    }

    /// NullServer must deny outgoing requests with an internal error.
    #[tokio::test]
    async fn null_server_denies_outgoing_request() {
        let server = NullServer::default();
        let request = build_request("http://example.com/");
        let result =
            Box::into_pin(server.outgoing_request("test", request, None, no_io(), &[])).await;
        // A guest-visible `internal-error`, not a trap: `wasi:http` 0.2 used to
        // trap here, and wasmtime 48's hook has no way to.
        assert!(
            matches!(result, Err(wasmtime_wasi_http::Error::InternalError(Some(msg))) if msg == "http client not available"),
            "NullServer outgoing request should report that no client is available"
        );
    }

    /// A `wasi:http/incoming-handler` interface carrying `host` and, optionally,
    /// a comma-separated `host-aliases` config — mirrors what the wash config
    /// layer injects.
    fn http_iface(host: Option<&str>, aliases: Option<&str>) -> crate::wit::WitInterface {
        let mut config = HashMap::new();
        if let Some(host) = host {
            config.insert("host".to_string(), host.to_string());
        }
        if let Some(aliases) = aliases {
            config.insert("host-aliases".to_string(), aliases.to_string());
        }
        crate::wit::WitInterface {
            namespace: "wasi".to_string(),
            package: "http".to_string(),
            interfaces: ["incoming-handler".to_string()].into_iter().collect(),
            version: Some(semver::Version::parse("0.2.2").unwrap()),
            config,
            name: None,
        }
    }

    #[test]
    fn http_ingress_routes_collect_primary_and_valid_aliases() {
        let ifaces = vec![http_iface(Some("primary.local"), Some("a.local, b.local"))];
        assert_eq!(
            http_ingress_routes(&ifaces).unwrap(),
            vec![
                IngressRoute::ingress("primary.local"),
                IngressRoute::ingress("a.local"),
                IngressRoute::ingress("b.local"),
            ],
        );
    }

    #[test]
    fn http_ingress_routes_filter_invalid_and_empty_entries() {
        // Underscores are not valid RFC 1123 hostname chars, and leading/trailing
        // hyphens are rejected: the bad primary is dropped and only the valid
        // aliases survive.
        let ifaces = vec![http_iface(
            Some("bad_host"),
            Some("ok.local,,-nope-,also_bad,fine.local"),
        )];
        assert_eq!(
            http_ingress_routes(&ifaces).unwrap(),
            vec![
                IngressRoute::ingress("ok.local"),
                IngressRoute::ingress("fine.local"),
            ],
        );
    }

    /// `localRoute` adds same-host-only routes alongside the network-reachable
    /// ones, in both forms: a bare host, and a host with a path prefix.
    #[test]
    fn http_ingress_routes_collect_local_routes_in_both_forms() {
        let mut iface = http_iface(Some("primary.local"), Some("alias.local"));
        iface.config.insert(
            "localRoute".to_string(),
            "svc.internal, other.internal/hello/".to_string(),
        );
        assert_eq!(
            http_ingress_routes(&[iface]).unwrap(),
            vec![
                IngressRoute::ingress("primary.local"),
                IngressRoute::ingress("alias.local"),
                IngressRoute::local("svc.internal", ""),
                IngressRoute::local("other.internal", "/hello"),
            ],
            "a bare localRoute serves every path; a trailing slash is normalized away"
        );
    }

    /// `examples/local-ingress/deploy/workloads.yaml`, read from the manifest
    /// itself. The example's README makes four claims about what this config
    /// does; this asserts all four against the real parser and router so
    /// neither the docs nor the manifest can drift from the behavior.
    #[tokio::test]
    async fn the_local_ingress_example_routes_as_its_readme_claims() {
        const MANIFEST: &str =
            include_str!("../../../../examples/local-ingress/deploy/workloads.yaml");
        // The first value of `key` in the manifest; the callee comes first.
        let value = |key: &str| -> &'static str {
            MANIFEST
                .lines()
                .find_map(|line| line.trim().strip_prefix(key)?.strip_prefix(':'))
                .map(str::trim)
                .unwrap_or_else(|| panic!("workloads.yaml has no `{key}`"))
        };
        let (callee_host, callee_url) = (value("host"), value("CALLEE_URL"));

        let mut iface = http_iface(Some(callee_host), None);
        iface
            .config
            .insert("localRoute".to_string(), value("localRoute").into());

        let router = DynamicRouter::default();
        router.register_routes("callee", &http_ingress_routes(&[iface]).unwrap());

        let local = |uri: &str| {
            router.route_local_egress(&uri.parse::<hyper::Uri>().unwrap(), &mut |_| true)
        };
        let inbound =
            |host: &str, path: &str| router.select_workload(host, path, RouteScope::Ingress);

        // 1. The caller's URL is served in-memory, prefix and below.
        assert_eq!(local(callee_url), Some("callee".into()));
        assert_eq!(
            local("http://functiona.internal/hello/items"),
            Some("callee".into())
        );
        // 2. Outside the prefix, including the segment-boundary case, it is not.
        assert_eq!(local("http://functiona.internal/"), None);
        assert_eq!(local("http://functiona.internal/hello-world"), None);
        // 3. The public hostname still serves every path from the network, and
        //    is *not* short-circuited for a co-located caller.
        assert_eq!(inbound(callee_host, "/anything").unwrap(), "callee");
        assert_eq!(local(&format!("http://{callee_host}/hello")), None);
        // 4. The localRoute name answers nothing arriving over the network.
        assert!(inbound("functiona.internal", "/hello").is_err());
    }

    /// `localRoute` grammar: `host` or `host/path`, authority always a valid
    /// hostname. A bare path is refused — "any authority, this path" would let
    /// one workload intercept a co-located caller's traffic to any destination.
    #[test]
    fn local_route_entries_require_a_valid_authority() {
        assert_eq!(
            parse_local_route("svc.internal"),
            Some(IngressRoute::local("svc.internal", ""))
        );
        assert_eq!(
            parse_local_route("svc.internal/hello"),
            Some(IngressRoute::local("svc.internal", "/hello"))
        );
        assert_eq!(
            parse_local_route("/hello"),
            None,
            "bare path has no authority"
        );
        assert_eq!(parse_local_route("bad_host/hello"), None);
        assert_eq!(parse_local_route(""), None);
    }

    /// The URL grammar decides what an authority is, so the entries a hand
    /// split would have waved through are refused for the reason each is wrong
    /// rather than by accident.
    #[test]
    fn local_route_entries_are_read_by_the_url_grammar() {
        // A port promises a distinction in-memory dispatch cannot honour.
        assert_eq!(parse_local_route("svc.internal:8080"), None);
        assert_eq!(parse_local_route("svc.internal:8080/hello"), None);
        // Credentials, a query and a fragment carry no routing meaning, and
        // accepting them would silently discard whatever they were meant to do.
        assert_eq!(parse_local_route("user@svc.internal/hello"), None);
        assert_eq!(parse_local_route("user:pw@svc.internal"), None);
        assert_eq!(parse_local_route("svc.internal/hello?a=1"), None);
        assert_eq!(parse_local_route("svc.internal/hello#frag"), None);
        // An IPv4 literal is label-valid RFC 1123 and registers like any other
        // name, the same way `host`/`host-aliases` accept one — the table holds
        // one kind of key and both sides agree on it. A bracketed IPv6 literal
        // is not a name and is refused.
        assert_eq!(
            parse_local_route("127.0.0.1/hello"),
            Some(IngressRoute::local("127.0.0.1", "/hello"))
        );
        assert_eq!(parse_local_route("[::1]/hello"), None);
        // The parser tolerates extra leading slashes for a special scheme, so a
        // bare path must not reach it.
        assert_eq!(parse_local_route("//hello"), None);
        // And the ordinary forms still parse, with the path percent-encoded the
        // way a request URI's path is.
        assert_eq!(
            parse_local_route("SVC.Internal/Hello"),
            Some(IngressRoute::local("svc.internal", "/Hello")),
            "the hostname is case-folded, the path is not"
        );
    }

    /// Local dispatch answers with an HTTP handler, so it may only claim a
    /// request that asked for HTTP. A scheme the incoming path cannot speak has
    /// to reach the network, where whatever does speak it lives.
    #[tokio::test]
    async fn only_http_schemes_are_short_circuited() {
        let router = DynamicRouter::default();
        router.register_routes("callee", &[IngressRoute::local("svc.internal", "")]);
        let local = |uri: &str| {
            router.route_local_egress(&uri.parse::<hyper::Uri>().unwrap(), &mut |_| true)
        };

        assert_eq!(local("http://svc.internal/x"), Some("callee".to_string()));
        assert_eq!(local("https://svc.internal/x"), Some("callee".to_string()));
        assert_eq!(local("ws://svc.internal/x"), None);
        assert_eq!(local("wss://svc.internal/x"), None);
        assert_eq!(local("gopher://svc.internal/x"), None);
    }

    /// The order `select_workload` walks is a property of the bucket type, so
    /// pin it there: most specific first, catch-all last.
    #[test]
    fn buckets_sort_most_specific_first() {
        let bucket = |prefix: &str| PathBucket {
            prefix: NormalizedPathPrefix::new(prefix),
            scope: RouteScope::Local,
            workloads: imbl::OrdSet::new(),
        };
        let mut buckets = [
            bucket(""),
            bucket("/a"),
            bucket("/a/b/c"),
            bucket("/a/b"),
            bucket("/z"),
        ];
        buckets.sort();
        let order: Vec<&str> = buckets.iter().map(|b| b.prefix.as_str()).collect();
        assert_eq!(
            order,
            vec!["/a/b/c", "/a/b", "/a", "/z", ""],
            "longest first, ties broken lexicographically, catch-all last so it \
             is a fallback rather than a shadow over every scoped route"
        );
    }

    /// Writing a URL is the likeliest mistake here, and it used to *succeed*:
    /// splitting `http://svc.internal/hello` on `/` yields hostname `http` with
    /// prefix `/svc.internal/hello` — a valid-looking route matching nothing,
    /// registered silently.
    #[test]
    fn a_url_shaped_local_route_is_refused() {
        for entry in [
            "http://svc.internal/hello",
            "https://svc.internal/hello",
            "http://svc.internal",
        ] {
            assert_eq!(parse_local_route(entry), None, "{entry} must be refused");
        }
    }

    /// A local route names no port: dispatch is in-memory, where nothing is
    /// listening, so a port in the declaration promises a distinction that
    /// cannot be honoured.
    #[test]
    fn a_local_route_may_not_name_a_port() {
        assert_eq!(parse_local_route("svc.internal:8080/hello"), None);
        assert_eq!(parse_local_route("svc.internal:8080"), None);
    }

    /// The matching side of the same contract: a request naming a non-default
    /// port is asking for something a portless route cannot promise (a sidecar
    /// on :9187, say), so it egresses rather than being answered locally.
    #[tokio::test]
    async fn a_request_naming_a_non_default_port_is_not_locally_routed() {
        let router = DynamicRouter::default();
        router.register_routes("callee", &[IngressRoute::local("svc.internal", "")]);

        let local = |uri: &str| {
            router.route_local_egress(&uri.parse::<hyper::Uri>().unwrap(), &mut |_| true)
        };

        assert_eq!(local("http://svc.internal/metrics"), Some("callee".into()));
        assert_eq!(
            local("http://svc.internal:9187/metrics"),
            None,
            "an explicit non-default port must egress"
        );
        // The scheme's own default port is the same request either way.
        assert_eq!(local("http://svc.internal:80/x"), Some("callee".into()));
        assert_eq!(local("https://svc.internal:443/x"), Some("callee".into()));
        assert_eq!(
            local("https://svc.internal:80/x"),
            None,
            "80 is not https's default"
        );
    }

    /// An alias carrying a path is the mistake `localRoute` exists to catch. It
    /// must be dropped rather than silently registered as a nonsense hostname.
    #[test]
    fn an_alias_containing_a_path_is_discarded() {
        let iface = http_iface(Some("primary.local"), Some("hello.com/me"));
        assert_eq!(
            http_ingress_routes(&[iface]).unwrap(),
            vec![IngressRoute::ingress("primary.local")],
            "`hello.com/me` is not a hostname; it belongs in localRoute"
        );
    }

    /// A malformed `localRoute` fails the workload rather than being dropped:
    /// dropped, its callers would silently egress for a name meant to stay on
    /// the host.
    #[test]
    fn an_invalid_local_route_is_an_error() {
        let mut iface = http_iface(Some("primary.local"), None);
        iface.config.insert(
            "localRoute".to_string(),
            "ok.internal, http://svc.internal/x".to_string(),
        );
        let err = http_ingress_routes(&[iface]).unwrap_err();
        assert!(err.to_string().contains("http://svc.internal/x"), "{err}");
    }

    #[test]
    fn http_ingress_routes_empty_without_http_interface() {
        let kv = crate::wit::WitInterface {
            namespace: "wasi".to_string(),
            package: "keyvalue".to_string(),
            interfaces: ["store".to_string()].into_iter().collect(),
            version: None,
            config: HashMap::new(),
            name: None,
        };
        assert!(http_ingress_routes(&[kv]).unwrap().is_empty());
    }

    /// A client decides whether to put the port in the Host header, and the
    /// host serves one HTTP port, so routing must not depend on that choice.
    /// Without this an OCI client pushing to `127.0.0.1:5000` 404s against a
    /// workload registered as `127.0.0.1`, which is what forced the e2e
    /// registry onto port 80 (and onto sudo, to bind it).
    #[tokio::test]
    async fn dynamic_router_ignores_the_port_in_the_host_header() {
        let router = DynamicRouter::default();
        router
            .on_service_http_resolved("w0", &[IngressRoute::ingress("registry.local")])
            .await
            .unwrap();

        assert_eq!(
            router
                .select_workload("registry.local", "/", RouteScope::Ingress)
                .unwrap(),
            "w0"
        );
        assert_eq!(
            router
                .select_workload("registry.local:5000", "/", RouteScope::Ingress)
                .unwrap(),
            "w0"
        );
        assert!(
            router
                .select_workload("other.local:5000", "/", RouteScope::Ingress)
                .is_err(),
            "stripping the port must not make unrelated hostnames match"
        );
    }

    /// The two sides have to agree: a hostname registered *with* a port is
    /// still reachable, rather than being keyed under a name no request can
    /// produce.
    #[tokio::test]
    async fn dynamic_router_normalizes_a_registered_host_with_a_port() {
        let router = DynamicRouter::default();
        router
            .on_service_http_resolved("w0", &[IngressRoute::ingress("registry.local:5000")])
            .await
            .unwrap();

        assert_eq!(
            router
                .select_workload("registry.local", "/", RouteScope::Ingress)
                .unwrap(),
            "w0"
        );
        assert_eq!(
            router
                .select_workload("registry.local:5000", "/", RouteScope::Ingress)
                .unwrap(),
            "w0"
        );
    }

    /// Regression guard for the "N replicas serve like one" defect: with several
    /// workloads bound to one hostname, `route_incoming_request` used to pin
    /// every request to a single arbitrary replica (`HashSet::iter().next()`).
    /// Random selection must instead spread load across all of them.
    ///
    /// Selection is a per-thread PRNG, so this asserts a distribution rather than
    /// exact counts. The band around the expected share is ~18σ wide for uniform
    /// selection over these draws, so it cannot flake, yet the old pin-to-one
    /// behavior (one replica takes everything, the rest zero) fails it outright.
    #[tokio::test]
    async fn dynamic_router_spreads_load_across_replicas() {
        let router = DynamicRouter::default();
        let replicas = ["r0", "r1", "r2", "r3"];
        for id in replicas {
            router
                .on_service_http_resolved(id, &[IngressRoute::ingress("svc.local")])
                .await
                .unwrap();
        }

        const DRAWS: usize = 4_000;
        let mut counts: std::collections::BTreeMap<String, usize> =
            std::collections::BTreeMap::new();
        for _ in 0..DRAWS {
            let id = router
                .select_workload("svc.local", "/", RouteScope::Ingress)
                .unwrap();
            *counts.entry(id).or_default() += 1;
        }

        assert_eq!(
            counts.len(),
            replicas.len(),
            "every replica should receive traffic, got {counts:?}"
        );
        let expected = DRAWS / replicas.len();
        for (id, hits) in counts {
            assert!(
                hits > expected / 2 && hits < expected * 2,
                "replica {id} got {hits}, far from the expected ~{expected} — uneven spread"
            );
        }
    }

    /// A service-only workload (defect #1) reaches routing through
    /// `on_service_http_resolved`, not `on_workload_resolved`. The router must
    /// register its hostnames so requests resolve. Previously this was a no-op
    /// and every hostname 404'd.
    #[tokio::test]
    async fn dynamic_router_registers_service_http_hostnames() {
        let router = DynamicRouter::default();
        assert!(
            matches!(
                router.select_workload("svc.local", "/", RouteScope::Ingress),
                Err(RouteError::NoWorkloadForHost(_))
            ),
            "host should not resolve before the service is registered"
        );

        router
            .on_service_http_resolved(
                "svc-1",
                &[
                    IngressRoute::ingress("svc.local"),
                    IngressRoute::ingress("svc.internal"),
                ],
            )
            .await
            .unwrap();

        assert_eq!(
            router
                .select_workload("svc.local", "/", RouteScope::Ingress)
                .unwrap(),
            "svc-1"
        );
        assert_eq!(
            router
                .select_workload("svc.internal", "/", RouteScope::Ingress)
                .unwrap(),
            "svc-1"
        );
    }

    /// A service resolving with no valid hostnames (e.g. under a host-agnostic
    /// deployment) must not register anything or error.
    #[tokio::test]
    async fn dynamic_router_service_http_empty_hostnames_is_noop() {
        let router = DynamicRouter::default();
        router.on_service_http_resolved("svc-1", &[]).await.unwrap();
        assert!(matches!(
            router.select_workload("anything.local", "/", RouteScope::Ingress),
            Err(RouteError::NoWorkloadForHost(_))
        ));
    }

    /// Unbinding one replica drops it from the rotation; the hostname keeps
    /// routing to whoever remains.
    #[tokio::test]
    async fn dynamic_router_unbind_removes_replica_from_rotation() {
        let router = DynamicRouter::default();
        router
            .on_service_http_resolved("r0", &[IngressRoute::ingress("svc.local")])
            .await
            .unwrap();
        router
            .on_service_http_resolved("r1", &[IngressRoute::ingress("svc.local")])
            .await
            .unwrap();

        router.on_workload_unbind("r0").await.unwrap();

        for _ in 0..4 {
            assert_eq!(
                router
                    .select_workload("svc.local", "/", RouteScope::Ingress)
                    .unwrap(),
                "r1",
                "only the surviving replica should be selected after unbind"
            );
        }
    }

    /// Stopping a service-only workload calls `on_service_http_unbind` but not
    /// `on_workload_unbind`. That hook must still drop the router registration,
    /// otherwise a stopped replica lingers in the hostname's replica set and
    /// requests routed onto it 404.
    #[tokio::test]
    async fn service_http_unbind_removes_router_registration() {
        let server = Ingress::builder(DynamicRouter::default(), "127.0.0.1:0".parse().unwrap())
            .build()
            .await
            .unwrap();

        let (tx, _rx) = tokio::sync::mpsc::channel(1);
        server
            .on_service_http_resolved("svc-1", &[IngressRoute::ingress("svc.local")], tx)
            .await
            .unwrap();
        assert_eq!(
            server
                .router
                .select_workload("svc.local", "/", RouteScope::Ingress)
                .unwrap(),
            "svc-1"
        );

        server.on_service_http_unbind("svc-1").await.unwrap();
        assert!(
            matches!(
                server
                    .router
                    .select_workload("svc.local", "/", RouteScope::Ingress),
                Err(RouteError::NoWorkloadForHost(_))
            ),
            "hostname must stop routing once the service unbinds"
        );
    }

    // --- same-host local routing tests ---

    #[tokio::test]
    async fn route_local_egress_matches_a_declared_local_route() {
        let router = DynamicRouter::default();
        router.register_routes("callee", &[IngressRoute::local("callee.internal", "")]);

        let route = |uri: &str| {
            router.route_local_egress(&uri.parse::<hyper::Uri>().unwrap(), &mut |_| true)
        };

        assert_eq!(
            route("http://callee.internal/api/items"),
            Some("callee".to_string()),
            "a bare localRoute serves any path on that hostname"
        );
        assert_eq!(
            route("http://callee.internal:8080/api"),
            None,
            "a non-default port is not something a portless local route serves \
             (see `a_request_naming_a_non_default_port_is_not_locally_routed`)"
        );
        assert_eq!(
            route("http://CALLEE.internal/api"),
            Some("callee".to_string()),
            "authority matching is case-insensitive"
        );
        assert_eq!(
            route("http://elsewhere.example.com/api"),
            None,
            "hostnames this ingress does not serve egress normally"
        );
    }

    #[tokio::test]
    async fn route_local_egress_stops_on_unbind() {
        let router = DynamicRouter::default();
        let uri: hyper::Uri = "http://callee.internal/fn".parse().unwrap();

        router.register_routes("callee", &[IngressRoute::local("callee.internal", "")]);
        assert_eq!(
            router.route_local_egress(&uri, &mut |_| true),
            Some("callee".to_string())
        );

        router.on_workload_unbind("callee").await.unwrap();
        assert_eq!(
            router.route_local_egress(&uri, &mut |_| true),
            None,
            "unbind must drop the workload's local routes too"
        );
    }

    /// Writes edit only what they touch: unbinding one workload leaves every
    /// other workload's routes, on its hostname and on others, as they were,
    /// and unbinding all of them leaves nothing behind.
    #[tokio::test]
    async fn unbind_touches_only_the_unbound_workloads_routes() {
        let router = DynamicRouter::default();
        for i in 0..100 {
            router.register_routes(
                &format!("w{i}"),
                &[IngressRoute::ingress(format!("host{i}.example.com"))],
            );
        }
        router.register_routes("w0-replica", &[IngressRoute::ingress("host0.example.com")]);

        router.on_workload_unbind("w0").await.unwrap();
        assert_eq!(
            router
                .select_workload("host0.example.com", "/", RouteScope::Ingress)
                .ok(),
            Some("w0-replica".to_string()),
            "the remaining replica keeps the hostname"
        );
        assert_eq!(
            router
                .select_workload("host7.example.com", "/", RouteScope::Ingress)
                .ok(),
            Some("w7".to_string())
        );

        router.on_workload_unbind("w0-replica").await.unwrap();
        for i in 1..100 {
            router.on_workload_unbind(&format!("w{i}")).await.unwrap();
        }
        assert!(router.hosts.iter().all(|shard| shard.0.load().is_empty()));
        assert!(router.workload_to_host.lock().unwrap().is_empty());
    }

    /// A request matches against the snapshot it loaded from the table, so a
    /// write landing mid-request neither blocks it nor changes what it sees.
    #[test]
    fn a_held_snapshot_is_unaffected_by_later_writes() {
        let router = DynamicRouter::default();
        router.register_routes("a", &[IngressRoute::ingress("svc.example.com")]);
        let snapshot = router.host_buckets("svc.example.com").unwrap();

        router.register_routes("b", &[IngressRoute::ingress("svc.example.com")]);
        router.unregister_routes("a");

        let held: Vec<_> = snapshot
            .iter()
            .flat_map(|b| b.workloads.iter().cloned())
            .collect();
        assert_eq!(held, ["a"]);
        let now: Vec<_> = router
            .host_buckets("svc.example.com")
            .unwrap()
            .iter()
            .flat_map(|b| b.workloads.iter().cloned())
            .collect();
        assert_eq!(now, ["b"]);
    }

    #[test]
    fn concurrent_route_churn_preserves_shared_replicas_and_held_snapshots() {
        let router = Arc::new(DynamicRouter::default());
        let shared = IngressRoute::ingress("shared.example.com");
        router.register_routes("anchor", std::slice::from_ref(&shared));
        let held = router.host_buckets("shared.example.com").unwrap();
        std::thread::scope(|scope| {
            for worker in 0..4 {
                let router = &router;
                let shared = &shared;
                scope.spawn(move || {
                    for index in 0..1000 {
                        let id = format!("worker-{worker}-{index}");
                        let distinct =
                            IngressRoute::ingress(format!("w{worker}-{index}.example.com"));
                        router.register_routes(&id, &[shared.clone(), distinct.clone()]);
                        assert_eq!(
                            router
                                .select_workload(&distinct.host, "/", RouteScope::Ingress)
                                .unwrap(),
                            id
                        );
                        assert!(
                            router
                                .select_workload(&shared.host, "/", RouteScope::Ingress)
                                .is_ok()
                        );
                        router.unregister_routes(&id);
                    }
                });
            }
        });
        assert_eq!(
            held[0].workloads.iter().cloned().collect::<Vec<_>>(),
            ["anchor"]
        );
        assert_eq!(
            router
                .select_workload(&shared.host, "/", RouteScope::Ingress)
                .unwrap(),
            "anchor"
        );
    }

    #[test]
    #[ignore = "100k-route scaling probe; run explicitly with --ignored --nocapture"]
    fn routing_write_scaling() {
        for replicas in [false, true] {
            let router = DynamicRouter::default();
            let began = std::time::Instant::now();
            for index in 0..100_000 {
                let host = if replicas {
                    "shared.scale.test".to_string()
                } else {
                    format!("w{index}.scale.test")
                };
                router.register_routes(&format!("w{index}"), &[IngressRoute::ingress(host)]);
            }
            let registered = began.elapsed();
            for index in 0..100_000 {
                router.unregister_routes(&format!("w{index}"));
            }
            assert!(lock_routes(router.workload_to_host.lock()).is_empty());
            eprintln!(
                "replicas={replicas}: register={registered:?}, register+remove={:?}",
                began.elapsed()
            );
        }
    }

    /// A body error a local dispatch already produced reaches the guest as
    /// itself: the between-frames clock hands it back unchanged rather than
    /// reclassifying it as a transport failure, which is what keeps a
    /// co-located callee's own error-code intact on the way to its caller.
    #[tokio::test]
    async fn an_already_classified_body_error_is_handed_back_unchanged() {
        use wasmtime_wasi_http::Error;

        struct Failing(Option<Error>);
        impl hyper::body::Body for Failing {
            type Data = bytes::Bytes;
            type Error = Error;
            fn poll_frame(
                mut self: std::pin::Pin<&mut Self>,
                _cx: &mut std::task::Context<'_>,
            ) -> std::task::Poll<Option<Result<hyper::body::Frame<bytes::Bytes>, Error>>>
            {
                std::task::Poll::Ready(self.0.take().map(Err))
            }
        }

        let body = TimedBody::new(
            Failing(Some(Error::HttpRequestBodySize(Some(42)))).boxed_unsync(),
            Duration::from_secs(5),
        );
        let err = BodyExt::collect(body).await.err();
        assert!(
            matches!(err, Some(Error::HttpRequestBodySize(Some(42)))),
            "expected the callee's own error, got {err:?}"
        );
    }

    /// One unready replica must not send callers to the network while a ready
    /// one serves the same route.
    #[tokio::test]
    async fn route_local_egress_skips_replicas_that_cannot_serve() {
        let router = DynamicRouter::default();
        for id in ["ready", "starting"] {
            router.register_routes(id, &[IngressRoute::local("svc.internal", "")]);
        }
        let uri: hyper::Uri = "http://svc.internal/x".parse().unwrap();

        for _ in 0..50 {
            assert_eq!(
                router.route_local_egress(&uri, &mut |id| id == "ready"),
                Some("ready".to_string())
            );
        }
        assert_eq!(
            router.route_local_egress(&uri, &mut |_| false),
            None,
            "with no replica able to serve, the caller egresses"
        );
    }

    /// A route is registered before the handle that serves it: routes go in
    /// first, then `instantiate_pre` is awaited, then the handle is inserted —
    /// and only for a component exporting `wasi:http`. So a matched route may
    /// point at a workload the ingress cannot dispatch to, briefly during start
    /// or permanently for a workload that declared `localRoute` without the
    /// export. Egress must fall back to the network there, not error.
    #[tokio::test]
    async fn a_matched_route_without_a_handle_is_not_dispatchable() {
        let server = Ingress::builder(DynamicRouter::default(), "127.0.0.1:0".parse().unwrap())
            .local_routing(true)
            .build()
            .await
            .unwrap();

        // Register the route the way `on_workload_resolved` does, without ever
        // inserting a handle — exactly the state a non-HTTP workload lands in.
        server
            .router
            .register_routes("unservable", &[IngressRoute::local("svc.internal", "")]);

        assert_eq!(
            server
                .router
                .route_local_egress(&"http://svc.internal/x".parse().unwrap(), &mut |_| true),
            Some("unservable".to_string()),
            "the route matches — this is precisely the trap"
        );
        assert!(
            server.resolve_local_target("unservable").is_none(),
            "with no service handler and no workload handle there is nothing to \
             dispatch to, so the caller must egress instead of getting a \
             local-dispatch error"
        );

        // A registered service handler is what makes it dispatchable.
        let (tx, rx) = tokio::sync::mpsc::channel(1);
        server
            .on_service_http_resolved("unservable", &[IngressRoute::local("svc.internal", "")], tx)
            .await
            .unwrap();
        assert!(
            matches!(
                server.resolve_local_target("unservable"),
                Some(LocalTarget::Service(_))
            ),
            "a registered service handler is the destination local dispatch resolves to"
        );

        drop(rx);
        assert!(
            server.resolve_local_target("unservable").is_none(),
            "a stopped service would take the request body and fail the send, so the \
             caller egresses"
        );
    }

    // --- the Ingress/Local partition ---

    /// The central guarantee of the two-key design: publishing a name to the
    /// network does not make it locally reachable, and declaring a `localRoute`
    /// does not expose it to the network. Anyone inside the cluster can dial the
    /// host's port with a forged `Host` header, so a local-only name leaking
    /// into inbound routing would be a real hole.
    #[tokio::test]
    async fn ingress_and_local_routes_do_not_leak_into_each_other() {
        let router = DynamicRouter::default();
        router.register_routes(
            "callee",
            &[
                IngressRoute::ingress("public.example.com"),
                IngressRoute::local("callee.internal", ""),
            ],
        );

        // The public name is not short-circuited for a co-located caller.
        assert_eq!(
            router.route_local_egress(&"http://public.example.com/x".parse().unwrap(), &mut |_| {
                true
            }),
            None,
            "a host/host-aliases name must not be locally routed"
        );
        // The local-only name is not reachable from the network.
        assert!(
            router
                .select_workload("callee.internal", "/x", RouteScope::Ingress)
                .is_err(),
            "a localRoute name must not answer a forged inbound Host header"
        );

        // Each is reachable at its own scope.
        assert_eq!(
            router
                .select_workload("public.example.com", "/x", RouteScope::Ingress)
                .unwrap(),
            "callee"
        );
        assert_eq!(
            router.route_local_egress(&"http://callee.internal/x".parse().unwrap(), &mut |_| true),
            Some("callee".to_string())
        );
    }

    /// One name may be declared at both scopes, and then it works both ways —
    /// the scopes are a partition of the table, not a restriction on what an
    /// author may say.
    #[tokio::test]
    async fn one_name_may_be_declared_at_both_scopes() {
        let router = DynamicRouter::default();
        router.register_routes(
            "callee",
            &[
                IngressRoute::ingress("both.example.com"),
                IngressRoute::local("both.example.com", ""),
            ],
        );

        assert_eq!(
            router
                .select_workload("both.example.com", "/x", RouteScope::Ingress)
                .unwrap(),
            "callee"
        );
        assert_eq!(
            router.route_local_egress(&"http://both.example.com/x".parse().unwrap(), &mut |_| true),
            Some("callee".to_string())
        );
    }

    // --- path-scoped local routes ---

    /// Prefixes match on `/` segment boundaries, so a route scoped to `/fn`
    /// does not swallow `/fnord`. The empty prefix is the catch-all.
    #[test]
    fn path_prefixes_match_on_segment_boundaries() {
        assert!(NormalizedPathPrefix::new("").matches("/anything"));
        assert!(NormalizedPathPrefix::new("/fn").matches("/fn"));
        assert!(NormalizedPathPrefix::new("/fn").matches("/fn/x"));
        assert!(!NormalizedPathPrefix::new("/fn").matches("/fnord"));
        assert!(!NormalizedPathPrefix::new("/fn").matches("/"));
        assert!(!NormalizedPathPrefix::new("/fn").matches("/other/fn"));
    }

    /// Whatever an author writes, the table stores one canonical form, so the
    /// two sides of a lookup cannot disagree over a slash.
    #[test]
    fn path_prefixes_are_normalized_to_one_form() {
        assert_eq!(NormalizedPathPrefix::new("/api").as_str(), "/api");
        assert_eq!(NormalizedPathPrefix::new("/api/").as_str(), "/api");
        assert_eq!(NormalizedPathPrefix::new(" api ").as_str(), "/api");
        assert_eq!(NormalizedPathPrefix::new("/").as_str(), "");
        assert_eq!(NormalizedPathPrefix::new("").as_str(), "");
    }

    /// Two workloads declaring the same local hostname under different prefixes
    /// must resolve independently. Keyed on the hostname alone they landed in
    /// one replica set and a caller got whichever the random pick returned.
    #[tokio::test]
    async fn path_scoped_local_routes_resolve_independently_on_one_hostname() {
        let router = DynamicRouter::default();
        router.register_routes("api", &[IngressRoute::local("svc.internal", "/api")]);
        router.register_routes("web", &[IngressRoute::local("svc.internal", "/web")]);

        let local = |uri: &str| {
            router.route_local_egress(&uri.parse::<hyper::Uri>().unwrap(), &mut |_| true)
        };

        assert_eq!(local("http://svc.internal/api"), Some("api".into()));
        assert_eq!(local("http://svc.internal/api/items"), Some("api".into()));
        assert_eq!(local("http://svc.internal/web"), Some("web".into()));
        assert_eq!(
            local("http://svc.internal/other"),
            None,
            "a path no local route claims egresses to the network instead of guessing"
        );
    }

    /// A hostname served only under a narrower prefix must report the path as
    /// the reason, not pretend the hostname is unknown — the two are different
    /// configuration mistakes.
    #[tokio::test]
    async fn a_path_outside_every_prefix_is_reported_as_such() {
        let router = DynamicRouter::default();
        router.register_routes("api", &[IngressRoute::local("svc.internal", "/api")]);

        let err = router
            .select_workload("svc.internal", "/other", RouteScope::Local)
            .unwrap_err();
        assert!(
            matches!(err, RouteError::NoWorkloadForPath { .. }),
            "expected NoWorkloadForPath, got {err:?}"
        );
        assert_eq!(err.status(), 404);

        let err = router
            .select_workload("nope.internal", "/api", RouteScope::Local)
            .unwrap_err();
        assert!(
            matches!(err, RouteError::NoWorkloadForHost(_)),
            "an unserved hostname is a different failure, got {err:?}"
        );
    }

    /// The most specific prefix wins, and a bare `localRoute` registered
    /// alongside scoped ones is a fallback rather than a shadow over them.
    #[tokio::test]
    async fn the_longest_matching_prefix_wins_over_a_catch_all() {
        let router = DynamicRouter::default();
        router.register_routes("root", &[IngressRoute::local("svc.internal", "")]);
        router.register_routes("api", &[IngressRoute::local("svc.internal", "/api")]);
        router.register_routes("v2", &[IngressRoute::local("svc.internal", "/api/v2")]);

        let local = |uri: &str| {
            router.route_local_egress(&uri.parse::<hyper::Uri>().unwrap(), &mut |_| true)
        };

        assert_eq!(local("http://svc.internal/api/v2/items"), Some("v2".into()));
        assert_eq!(local("http://svc.internal/api/v1"), Some("api".into()));
        assert_eq!(
            local("http://svc.internal/elsewhere"),
            Some("root".into()),
            "the bare localRoute still serves paths no scoped route claims"
        );
    }

    /// Unbinding one path-scoped workload must leave its neighbours on the same
    /// hostname untouched, and must not leave an empty bucket that a later
    /// lookup would match and find nothing in.
    #[tokio::test]
    async fn unbinding_one_path_route_leaves_its_neighbours_serving() {
        let router = DynamicRouter::default();
        router.register_routes("api", &[IngressRoute::local("svc.internal", "/api")]);
        router.register_routes("web", &[IngressRoute::local("svc.internal", "/web")]);

        router.on_workload_unbind("api").await.unwrap();

        assert_eq!(
            router
                .select_workload("svc.internal", "/web", RouteScope::Local)
                .unwrap(),
            "web"
        );
        let err = router
            .select_workload("svc.internal", "/api", RouteScope::Local)
            .unwrap_err();
        assert!(
            matches!(err, RouteError::NoWorkloadForPath { .. }),
            "the vacated prefix must stop resolving, got {err:?}"
        );

        router.on_workload_unbind("web").await.unwrap();
        let err = router
            .select_workload("svc.internal", "/web", RouteScope::Local)
            .unwrap_err();
        assert!(
            matches!(err, RouteError::NoWorkloadForHost(_)),
            "the last route leaving must drop the hostname entirely, got {err:?}"
        );
    }

    /// Unbinding must clear a workload's routes at *both* scopes. Keying bucket
    /// removal on the prefix alone would strand whichever of the two shared it.
    #[tokio::test]
    async fn unbind_clears_both_scopes_for_one_name() {
        let router = DynamicRouter::default();
        router.register_routes(
            "callee",
            &[
                IngressRoute::ingress("both.example.com"),
                IngressRoute::local("both.example.com", ""),
            ],
        );

        router.on_workload_unbind("callee").await.unwrap();

        assert!(
            router
                .select_workload("both.example.com", "/", RouteScope::Ingress)
                .is_err(),
            "the ingress route must be gone"
        );
        assert_eq!(
            router.route_local_egress(&"http://both.example.com/".parse().unwrap(), &mut |_| true),
            None,
            "the local route must be gone too"
        );
    }

    /// Replicas of one workload share a `(hostname, prefix, scope)` bucket, so
    /// path-scoping must not cost the random spread across them.
    #[tokio::test]
    async fn replicas_of_a_path_scoped_route_share_one_bucket() {
        let router = DynamicRouter::default();
        for id in ["r0", "r1"] {
            router.register_routes(id, &[IngressRoute::local("svc.internal", "/api")]);
        }

        let mut seen = BTreeSet::new();
        for _ in 0..200 {
            seen.insert(
                router
                    .select_workload("svc.internal", "/api", RouteScope::Local)
                    .unwrap(),
            );
        }
        assert_eq!(
            seen,
            BTreeSet::from(["r0".to_string(), "r1".to_string()]),
            "both replicas must be selected"
        );
    }

    /// Hostnames are case-insensitive per RFC 1123, and both scopes must agree
    /// on that — previously registration preserved case while only the egress
    /// lookup folded it, so a mixed-case registration was unreachable.
    #[tokio::test]
    async fn hostname_matching_is_case_insensitive_at_both_scopes() {
        let router = DynamicRouter::default();
        router.register_routes(
            "callee",
            &[
                IngressRoute::ingress("Callee.Public"),
                IngressRoute::local("Callee.Internal", "/Hello"),
            ],
        );

        assert_eq!(
            router
                .select_workload("CALLEE.PUBLIC", "/", RouteScope::Ingress)
                .unwrap(),
            "callee"
        );
        assert_eq!(
            router.route_local_egress(
                &"http://CALLEE.INTERNAL/Hello".parse().unwrap(),
                &mut |_| true
            ),
            Some("callee".to_string()),
        );
        assert_eq!(
            router.route_local_egress(
                &"http://callee.internal/hello".parse().unwrap(),
                &mut |_| true
            ),
            None,
            "paths are case-sensitive even though hostnames are not"
        );
    }
}
